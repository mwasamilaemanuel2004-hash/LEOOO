/**
 * AIBrain.jsx — ESTRADE v8 GODMODE — AI Brain Control Center
 * Live RL stats, strategy evolution, genome viewer, risk analytics
 */
import { useState, useEffect } from "react";
import { api } from "../utils/supabase.js";

const Section = ({ title, icon, children, color="#6366f1" }) => (
  <div className="card" style={{ marginBottom:16 }}>
    <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:14,
                 paddingBottom:10, borderBottom:"1px solid #1e293b" }}>
      <span style={{ fontSize:20 }}>{icon}</span>
      <h3 style={{ fontSize:14, fontWeight:800, color:"#f1f5f9" }}>{title}</h3>
    </div>
    {children}
  </div>
);

const Stat = ({ label, value, color="#e2e8f0", sub }) => (
  <div style={{ textAlign:"center", padding:"10px 8px" }}>
    <div style={{ fontSize:20, fontWeight:900, color }}>{value ?? "—"}</div>
    <div style={{ fontSize:11, color:"#475569", marginTop:2 }}>{label}</div>
    {sub && <div style={{ fontSize:10, color:"#334155", marginTop:1 }}>{sub}</div>}
  </div>
);

export default function AIBrain() {
  const [rl,       setRl]       = useState({});
  const [evolver,  setEvolver]  = useState({});
  const [risk,     setRisk]     = useState({});
  const [genome,   setGenome]   = useState({});
  const [circuits, setCircuits] = useState({});
  const [busy,     setBusy]     = useState({});
  const [tab,      setTab]      = useState("rl");

  const load = async () => {
    const [r, e, ri, g, c] = await Promise.allSettled([
      api.get("/rl/stats"),
      api.get("/strategy/stats"),
      api.get("/risk/stats"),
      api.get("/strategy/best"),
      api.get("/risk/circuits"),
    ]);
    if (r.status==="fulfilled") setRl(r.value||{});
    if (e.status==="fulfilled") setEvolver(e.value||{});
    if (ri.status==="fulfilled") setRisk(ri.value||{});
    if (g.status==="fulfilled") setGenome(g.value||{});
    if (c.status==="fulfilled") setCircuits(c.value||{});
  };

  useEffect(() => { load(); const iv = setInterval(load, 5000); return () => clearInterval(iv); }, []);

  const doEvolve = async () => {
    setBusy(b=>({...b,evolve:true}));
    try {
      const r = await api.post("/backtest/evolve",{});
      if (r.success) { alert(`✅ Evolution complete! Gen ${r.generation} — Fitness: ${r.best?.fitness?.toFixed(3)}`); load(); }
    } catch(e) { alert("Evolution failed: "+e.message); }
    setBusy(b=>({...b,evolve:false}));
  };

  const resetCircuit = async (circuit) => {
    await api.post(`/risk/circuits/${circuit}/reset`,{});
    load();
  };

  const TABS = [
    { id:"rl",       label:"🧠 RL Engine" },
    { id:"strategy", label:"🧬 Strategy DNA" },
    { id:"risk",     label:"🛡️ Risk AI" },
    { id:"circuits", label:"⚡ Circuits" },
  ];

  return (
    <div style={{ padding:24, maxWidth:1400 }}>
      <div style={{ marginBottom:20 }}>
        <h1 style={{ fontSize:24, fontWeight:900, color:"#f1f5f9" }}>🧠 AI Brain Center</h1>
        <p style={{ fontSize:13, color:"#475569", marginTop:4 }}>
          Reinforcement Learning · Strategy Evolution · Risk Intelligence · Circuit Breakers
        </p>
      </div>

      {/* Tab nav */}
      <div style={{ display:"flex", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            style={{
              padding:"8px 16px", borderRadius:10, fontWeight:700, fontSize:13,
              border:"none", cursor:"pointer",
              background: tab===t.id ? "linear-gradient(135deg,#4f46e5,#7c3aed)" : "#0f172a",
              color: tab===t.id ? "#fff" : "#475569",
            }}>
            {t.label}
          </button>
        ))}
        <button className="btn btn-success" onClick={load} style={{ marginLeft:"auto" }}>🔄 Refresh</button>
      </div>

      {/* RL Engine Tab */}
      {tab === "rl" && (
        <>
          <Section title="Reinforcement Learning — Triple Brain (PPO + DQN + A3C)" icon="🧠">
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(140px,1fr))", gap:8 }}>
              <Stat label="Total Trades" value={rl.total_trades?.toLocaleString()} color="#6366f1"/>
              <Stat label="Win Rate" value={`${((rl.win_rate||0)*100).toFixed(1)}%`}
                color={(rl.win_rate||0)>0.55?"#22c55e":"#ef4444"}/>
              <Stat label="Total PnL" value={`${(rl.total_pnl||0).toFixed(2)}%`}
                color={(rl.total_pnl||0)>=0?"#22c55e":"#ef4444"}/>
              <Stat label="Sharpe Ratio" value={(rl.sharpe||0).toFixed(3)} color="#f59e0b"/>
              <Stat label="Max Drawdown" value={`${(rl.max_drawdown||0).toFixed(2)}%`} color="#ef4444"/>
              <Stat label="PPO Updates" value={rl.ppo_updates?.toLocaleString()} color="#a78bfa"/>
              <Stat label="DQN Updates" value={rl.dqn_updates?.toLocaleString()} color="#60a5fa"/>
              <Stat label="Replay Buffer" value={rl.replay_buffer?.toLocaleString()} color="#34d399"/>
            </div>

            {/* PPO vs DQN weight bar */}
            <div style={{ marginTop:14 }}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
                <span style={{ fontSize:11, color:"#a78bfa", fontWeight:700 }}>
                  PPO {((rl.ppo_weight||0.6)*100).toFixed(0)}%
                </span>
                <span style={{ fontSize:11, color:"#60a5fa", fontWeight:700 }}>
                  DQN {((rl.dqn_weight||0.4)*100).toFixed(0)}%
                </span>
              </div>
              <div style={{ height:8, background:"#1e293b", borderRadius:4, overflow:"hidden" }}>
                <div style={{ height:"100%", display:"flex" }}>
                  <div style={{ width:`${(rl.ppo_weight||0.6)*100}%`, background:"#7c3aed" }}/>
                  <div style={{ flex:1, background:"#3b82f6" }}/>
                </div>
              </div>
              <div style={{ fontSize:10, color:"#475569", marginTop:4 }}>
                A3C Meta-Controller dynamically adjusts weights per market regime
              </div>
            </div>

            {/* DQN Epsilon */}
            <div style={{ marginTop:12 }}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
                <span style={{ fontSize:11, color:"#94a3b8" }}>DQN Exploration (ε)</span>
                <span style={{ fontSize:11, color:"#f59e0b", fontWeight:700 }}>
                  {((rl.dqn_epsilon||0)*100).toFixed(1)}%
                </span>
              </div>
              <div style={{ height:6, background:"#1e293b", borderRadius:3, overflow:"hidden" }}>
                <div style={{ height:"100%", width:`${(rl.dqn_epsilon||0)*100}%`,
                             background:"linear-gradient(90deg,#f59e0b,#ef4444)" }}/>
              </div>
            </div>
          </Section>

          <Section title="Action Space — What the RL chose" icon="🎯">
            <div style={{ display:"grid", gridTemplateColumns:"repeat(7,1fr)", gap:4 }}>
              {[
                {id:0,label:"STRONG SELL",c:"#7f1d1d"},
                {id:1,label:"SELL",c:"#ef4444"},
                {id:2,label:"WEAK SELL",c:"#f97316"},
                {id:3,label:"HOLD",c:"#475569"},
                {id:4,label:"WEAK BUY",c:"#4ade80"},
                {id:5,label:"BUY",c:"#22c55e"},
                {id:6,label:"STRONG BUY",c:"#166534"},
              ].map(a => (
                <div key={a.id} style={{ textAlign:"center", padding:"8px 4px",
                                        background:"#0f172a", borderRadius:8,
                                        border:`1px solid ${a.c}44` }}>
                  <div style={{ fontSize:11, fontWeight:700, color:a.c }}>{a.label}</div>
                  <div style={{ fontSize:10, color:"#475569", marginTop:2 }}>×{a.id<3?2-Math.floor(a.id/2):a.id>3?(a.id-3)*0.5:0}sz</div>
                </div>
              ))}
            </div>
          </Section>
        </>
      )}

      {/* Strategy DNA Tab */}
      {tab === "strategy" && (
        <>
          <Section title="Strategy Evolution Engine — Genetic Algorithm" icon="🧬">
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(140px,1fr))", gap:8, marginBottom:14 }}>
              <Stat label="Generation" value={evolver.generation} color="#6366f1"/>
              <Stat label="Evolutions" value={evolver.evolutions} color="#a78bfa"/>
              <Stat label="Population" value={evolver.population_size} color="#60a5fa"/>
              <Stat label="Hall of Fame" value={evolver.hall_of_fame} color="#f59e0b"/>
              <Stat label="Best Fitness" value={(evolver.best_fitness||0).toFixed(3)} color="#22c55e"/>
              <Stat label="Best Sharpe" value={(evolver.best_sharpe||0).toFixed(3)} color="#34d399"/>
              <Stat label="Best Win Rate" value={`${((evolver.best_win_rate||0)*100).toFixed(1)}%`} color="#4ade80"/>
            </div>
            <button className="btn btn-primary" onClick={doEvolve} disabled={busy.evolve}>
              {busy.evolve ? "🧬 Evolving..." : "🚀 Run Evolution Now"}
            </button>
            <div style={{ fontSize:11, color:"#475569", marginTop:8 }}>
              Fitness trend: {(evolver.fitness_trend||[]).map(f=>f.toFixed(2)).join(" → ")}
            </div>
          </Section>

          <Section title="Best Genome (Current Active Strategy DNA)" icon="🔬">
            {genome.genome_id ? (
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))", gap:8 }}>
                {[
                  ["Genome ID", genome.genome_id, "#6366f1"],
                  ["EMA Fast/Slow", `${genome.ema_fast}/${genome.ema_slow}`, "#60a5fa"],
                  ["RSI OB/OS", `${genome.rsi_ob}/${genome.rsi_os}`, "#f59e0b"],
                  ["ATR SL×", genome.atr_sl_mult?.toFixed(2), "#ef4444"],
                  ["ATR TP×", genome.atr_tp_mult?.toFixed(2), "#22c55e"],
                  ["Min Confidence", `${genome.min_confidence?.toFixed(0)}%`, "#a78bfa"],
                  ["Min R:R", genome.min_rr?.toFixed(2), "#34d399"],
                  ["Session Mask", genome.session_mask, "#f97316"],
                  ["Max Trades/Day", genome.max_trades_day, "#fb923c"],
                  ["Use SMC", genome.use_smc ? "Yes" : "No", "#6366f1"],
                  ["Fitness", genome.fitness?.toFixed(4), "#22c55e"],
                  ["Generation", genome.generation, "#475569"],
                ].map(([label, val, color]) => (
                  <div key={label} style={{ background:"#0f172a", borderRadius:8, padding:"8px 12px" }}>
                    <div style={{ fontSize:10, color:"#475569", marginBottom:3 }}>{label}</div>
                    <div style={{ fontSize:14, fontWeight:800, color }}>{val ?? "—"}</div>
                  </div>
                ))}
              </div>
            ) : (
              <p style={{ color:"#475569" }}>No genome loaded yet. Run the evolution engine first.</p>
            )}
          </Section>
        </>
      )}

      {/* Risk AI Tab */}
      {tab === "risk" && (
        <>
          <Section title="Risk AI Engine — Portfolio Protection" icon="🛡️">
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(150px,1fr))", gap:8 }}>
              <Stat label="Evaluated" value={risk.total_evaluated?.toLocaleString()} color="#6366f1"/>
              <Stat label="Halted" value={risk.halted_trades?.toLocaleString()} color="#ef4444"/>
              <Stat label="Halt Rate" value={`${((risk.halt_rate||0)*100).toFixed(1)}%`} color="#f97316"/>
              <Stat label="Open Positions" value={risk.open_positions} color="#22c55e"/>
              <Stat label="Open Risk" value={`${risk.total_open_risk?.toFixed(2)}%`} color="#f59e0b"/>
              <Stat label="VaR 95%" value={`${risk.var_95?.toFixed(2)}%`} color="#ef4444"/>
              <Stat label="VaR 99%" value={`${risk.var_99?.toFixed(2)}%`} color="#dc2626"/>
            </div>
          </Section>

          <Section title="Drawdown Defense — 5-Level System" icon="📉">
            <div style={{ display:"grid", gridTemplateColumns:"repeat(5,1fr)", gap:8 }}>
              {[
                {level:0,label:"Normal",range:"0-3%",color:"#22c55e",size:"100%"},
                {level:1,label:"Alert",range:"3-5%",color:"#84cc16",size:"80%"},
                {level:2,label:"Caution",range:"5-8%",color:"#f59e0b",size:"60%"},
                {level:3,label:"Crisis",range:"8-12%",color:"#f97316",size:"40%"},
                {level:4,label:"Emergency",range:"12-15%",color:"#ef4444",size:"20%"},
              ].map(l => (
                <div key={l.level} style={{
                  textAlign:"center", padding:"10px 6px",
                  background:"#0f172a", borderRadius:10,
                  border:`1px solid ${l.color}44`,
                }}>
                  <div style={{ fontSize:18, fontWeight:900, color:l.color }}>L{l.level}</div>
                  <div style={{ fontSize:11, fontWeight:700, color:"#e2e8f0", marginTop:2 }}>{l.label}</div>
                  <div style={{ fontSize:10, color:"#475569" }}>{l.range} DD</div>
                  <div style={{ fontSize:10, color:l.color, fontWeight:700, marginTop:4 }}>
                    Size: {l.size}
                  </div>
                </div>
              ))}
            </div>
            <div style={{ marginTop:12, padding:10, background:"#0f172a", borderRadius:8,
                         fontSize:11, color:"#475569" }}>
              ⚡ Level 5 (>15% DD) = FULL HALT — All trading stops immediately, notifications sent
            </div>
          </Section>
        </>
      )}

      {/* Circuits Tab */}
      {tab === "circuits" && (
        <Section title="Circuit Breaker Network" icon="⚡">
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))", gap:12 }}>
            {Object.entries(circuits).map(([name, c]) => (
              <div key={name} style={{
                background:"#0f172a", borderRadius:10, padding:14,
                border:`1px solid ${c.open ? "#ef444444" : "#1e293b"}`,
              }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div>
                    <div style={{ fontSize:13, fontWeight:700, color:"#e2e8f0" }}>
                      {name.replace(/_/g," ").toUpperCase()}
                    </div>
                    <div style={{ fontSize:11, color:"#475569", marginTop:2 }}>
                      Trips: {c.trip_count || 0}
                    </div>
                    {c.reason && <div style={{ fontSize:10, color:"#ef4444", marginTop:3 }}>{c.reason}</div>}
                  </div>
                  <div style={{ display:"flex", flexDirection:"column", gap:6, alignItems:"flex-end" }}>
                    <span style={{
                      padding:"3px 8px", borderRadius:6, fontSize:11, fontWeight:700,
                      background: c.open ? "#7f1d1d" : "#14532d",
                      color: c.open ? "#fca5a5" : "#86efac",
                    }}>
                      {c.open ? "⚡ TRIPPED" : "✅ OK"}
                    </span>
                    {c.open && (
                      <button className="btn btn-ghost" style={{ fontSize:10, padding:"3px 8px" }}
                        onClick={() => resetCircuit(name)}>
                        Reset
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}
    </div>
  );
}
