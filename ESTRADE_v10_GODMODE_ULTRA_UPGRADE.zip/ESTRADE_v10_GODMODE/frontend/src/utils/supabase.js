import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL  = import.meta.env.VITE_SUPABASE_URL  || ''
const SUPABASE_ANON = import.meta.env.VITE_SUPABASE_ANON_KEY || ''
const API_URL       = import.meta.env.VITE_API_URL || 'http://localhost:8000/api'

export const supabase = SUPABASE_URL
  ? createClient(SUPABASE_URL, SUPABASE_ANON)
  : null

// REST API helper
const getToken = () => localStorage.getItem('estrade_token') || ''

export const api = {
  get: async (path) => {
    const r = await fetch(`${API_URL}${path}`, {
      headers: { Authorization: `Bearer ${getToken()}`, 'Content-Type': 'application/json' }
    })
    if (!r.ok) { const e = await r.json().catch(()=>({})); throw new Error(e.detail || e.error || r.statusText) }
    return r.json()
  },
  post: async (path, body) => {
    const r = await fetch(`${API_URL}${path}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${getToken()}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    })
    if (!r.ok) { const e = await r.json().catch(()=>({})); throw new Error(e.detail || e.error || r.statusText) }
    return r.json()
  },
  put: async (path, body) => {
    const r = await fetch(`${API_URL}${path}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${getToken()}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    })
    if (!r.ok) { const e = await r.json().catch(()=>({})); throw new Error(e.detail || e.error || r.statusText) }
    return r.json()
  },
  delete: async (path) => {
    const r = await fetch(`${API_URL}${path}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${getToken()}`, 'Content-Type': 'application/json' }
    })
    if (!r.ok) { const e = await r.json().catch(()=>({})); throw new Error(e.detail || e.error || r.statusText) }
    return r.json()
  }
}

export const realtime = {
  subscribe: (table, cb) => {
    if (!supabase) return () => {}
    const sub = supabase.channel(table)
      .on('postgres_changes', { event: '*', schema: 'public', table }, cb)
      .subscribe()
    return () => supabase.removeChannel(sub)
  }
}
