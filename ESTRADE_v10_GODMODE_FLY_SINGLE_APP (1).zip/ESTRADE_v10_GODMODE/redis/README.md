# Redis Deployment Guide

## Railway (Recommended)
1. Create new Railway project
2. Add Redis plugin → copy REDIS_URL
3. Set REDIS_URL in Backend + Workers .env

## DigitalOcean Managed Redis
1. Databases → Create → Redis 7.x
2. Copy connection string → set as REDIS_URL
3. Enable SSL: REDIS_URL=rediss://...

## Docker (local dev)
```bash
docker run -d -p 6379:6379 --name estrade-redis redis:7-alpine redis-server --requirepass YOUR_PASSWORD
```

## Environment Variable
```
REDIS_URL=redis://:password@host:6379/0
```
