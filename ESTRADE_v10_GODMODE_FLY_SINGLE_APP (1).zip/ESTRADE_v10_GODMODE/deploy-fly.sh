#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# estrading.machine v10 — Single-App Fly.io Deploy
# Usage: bash deploy-fly.sh
# Requires: flyctl (curl -L https://fly.io/install.sh | sh) + `fly auth login`
# ═══════════════════════════════════════════════════════════════
set -e
GREEN='\033[0;32m' YELLOW='\033[1;33m' BLUE='\033[0;34m' NC='\033[0m'
log()  { echo -e "${GREEN}✅ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
info() { echo -e "${BLUE}ℹ️  $1${NC}"; }

command -v flyctl >/dev/null 2>&1 || { warn "flyctl not found. Install: curl -L https://fly.io/install.sh | sh"; exit 1; }

info "Checking for an existing Fly app matching fly.toml..."
APP_NAME=$(grep -m1 '^app' fly.toml | sed -E 's/app *= *"(.*)"/\1/')

if ! fly apps list 2>/dev/null | grep -q "$APP_NAME"; then
  info "Creating Fly app '$APP_NAME' (no deploy yet)..."
  fly launch --no-deploy --copy-config --name "$APP_NAME" --yes
else
  info "App '$APP_NAME' already exists — reusing it."
fi

echo ""
info "Enter secrets (press Enter to skip any you've already set):"
read -p "SUPABASE_URL: " SUPABASE_URL
read -p "SUPABASE_SERVICE_KEY: " SUPABASE_KEY
read -p "STRIPE_SECRET_KEY (optional): " STRIPE_KEY
read -p "TELEGRAM_BOT_TOKEN (optional): " TELEGRAM_TOKEN
read -p "SENTRY_DSN (optional): " SENTRY_DSN

SECRETS=""
[ -n "$SUPABASE_URL" ]    && SECRETS="$SECRETS SUPABASE_URL=$SUPABASE_URL"
[ -n "$SUPABASE_KEY" ]    && SECRETS="$SECRETS SUPABASE_SERVICE_KEY=$SUPABASE_KEY"
[ -n "$STRIPE_KEY" ]      && SECRETS="$SECRETS STRIPE_SECRET_KEY=$STRIPE_KEY"
[ -n "$TELEGRAM_TOKEN" ]  && SECRETS="$SECRETS TELEGRAM_BOT_TOKEN=$TELEGRAM_TOKEN"
[ -n "$SENTRY_DSN" ]      && SECRETS="$SECRETS SENTRY_DSN=$SENTRY_DSN"
SECRETS="$SECRETS SECRET_KEY=$(openssl rand -hex 32)"

if [ -n "$SECRETS" ]; then
  info "Setting Fly secrets..."
  # shellcheck disable=SC2086
  fly secrets set $SECRETS --app "$APP_NAME"
fi

info "Deploying (builds frontend + backend + workers into one image)..."
fly deploy --app "$APP_NAME"

log "Deployed. Process groups: app (http), worker, beat, redis."
info "Scale a group with: fly scale count <N> --process-group worker --app $APP_NAME"
info "Tail logs with:     fly logs --app $APP_NAME"
info "SSH into a machine: fly ssh console --app $APP_NAME --process-group app"
