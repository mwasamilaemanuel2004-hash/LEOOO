"""
sentry/sentry_config.py — ESTRADE v6 Sentry Error Monitoring Setup
Add this to backend/main.py startup
"""
import sentry_sdk
from sentry_sdk.integrations.fastapi import FastApiIntegration
from sentry_sdk.integrations.redis import RedisIntegration
from sentry_sdk.integrations.celery import CeleryIntegration
import os

def init_sentry():
    dsn = os.getenv("SENTRY_DSN", "")
    if not dsn:
        return
    sentry_sdk.init(
        dsn=dsn,
        integrations=[FastApiIntegration(), RedisIntegration(), CeleryIntegration()],
        traces_sample_rate=0.1,      # 10% of transactions
        profiles_sample_rate=0.05,
        environment=os.getenv("ENVIRONMENT", "production"),
        release=f"estrade@{os.getenv('APP_VERSION','6.0.0')}",
        before_send=_before_send,
    )

def _before_send(event, hint):
    """Filter out non-critical errors before sending to Sentry."""
    if "exc_info" in hint:
        exc_type, _, _ = hint["exc_info"]
        # Skip common non-critical errors
        skip = ["ConnectionResetError", "BrokenPipeError", "CancelledError"]
        if exc_type.__name__ in skip:
            return None
    return event
