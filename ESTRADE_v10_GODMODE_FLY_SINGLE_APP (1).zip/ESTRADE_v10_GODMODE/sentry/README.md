# Sentry Error Monitoring Setup

## 1. Create Sentry Project
- Go to https://sentry.io → New Project → Python (FastAPI)
- Copy DSN

## 2. Set Environment Variable
```
SENTRY_DSN=https://xxxx@oXXXX.ingest.sentry.io/XXXX
```

## 3. Alerts to Configure
- New Error → Notify immediately
- Error Rate > 5% → High priority alert
- P99 response > 3s → Performance alert
- Bot crash → Notify on-call

## 4. Integrations
- Slack: Connect Sentry → #estrade-errors channel
- PagerDuty: For critical P0 issues
- GitHub: Link errors to commits
