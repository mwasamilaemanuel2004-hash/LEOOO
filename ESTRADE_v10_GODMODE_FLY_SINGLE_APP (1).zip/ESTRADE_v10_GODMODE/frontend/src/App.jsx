import{Routes,Route,Navigate,NavLink,useLocation}from"react-router-dom";
import{useState,useEffect,Suspense,lazy}from"react";
import{applyTheme,THEMES,setTheme as saveTheme}from"./utils/themes.js";
import{HexagonLoader,AnimationStyles}from"./components/UIEngine.jsx";
import Login from"./pages/Login.jsx";

const Dashboard=lazy(()=>import("./pages/Dashboard.jsx"));
const TradingPanel=lazy(()=>import("./pages/TradingPanel.jsx"));
const Bots=lazy(()=>import("./pages/Bots.jsx"));
const AIBrain=lazy(()=>import("./pages/AIBrain.jsx"));
const Backtester=lazy(()=>import("./pages/Backtester.jsx"));
const Portfolio=lazy(()=>import("./pages/Portfolio.jsx"));
const Security=lazy(()=>import("./pages/Security.jsx"));
const Settings=lazy(()=>import("./pages/Settings.jsx"));
const StrategyBuilder=lazy(()=>import("./pages/StrategyBuilder.jsx"));
const DevMode=lazy(()=>import("./pages/DevMode.jsx"));
const Signals=lazy(()=>import("./pages/Signals.jsx"));
const Reinvest=lazy(()=>import("./pages/Reinvest.jsx"));

const NAV=[
  {to:"/",label:"Dashboard",icon:"📊"},
  {to:"/trade",label:"Live Trade",icon:"⚡"},
  {to:"/bots",label:"43 Bots",icon:"🤖"},
  {to:"/signals",label:"Signals",icon:"📡"},
  {to:"/reinvest",label:"Reinvest",icon:"💰"},
  {to:"/ai-brain",label:"AI Brain",icon:"🧠"},
  {to:"/strategy",label:"Strategy",icon:"🔧"},
  {to:"/backtest",label:"Backtest",icon:"📈"},
  {to:"/portfolio",label:"Portfolio",icon:"💼"},
  {to:"/security",label:"Security",icon:"🛡️"},
  {to:"/dev",label:"Dev Mode",icon:"🛠️"},
  {to:"/settings",label:"Settings",icon:"⚙️"},
];

function ThemeModal({onClose}){
  const[current,setCurrent]=useState(parseInt(localStorage.getItem("estrade_theme")||"1"));
  return(
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.85)",zIndex:1000,display:"flex",alignItems:"center",justifyContent:"center",backdropFilter:"blur(6px)"}}>
      <div style={{background:"var(--bg2)",border:"1px solid var(--border2)",borderRadius:20,padding:28,width:580,maxWidth:"95vw",maxHeight:"85vh",overflowY:"auto"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
          <div style={{fontSize:18,fontWeight:900,color:"var(--text)"}}>🎨 Color Themes</div>
          <button onClick={onClose} style={{background:"none",border:"none",cursor:"pointer",color:"var(--text3)",fontSize:20}}>✕</button>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {Object.entries(THEMES).map(([id,t])=>(
            <div key={id} onClick={()=>{setCurrent(+id);saveTheme(+id);}} style={{display:"flex",alignItems:"center",gap:14,padding:14,borderRadius:14,border:`2px solid ${current===+id?t.primary:"var(--border2)"}`,background:current===+id?t.primary+"15":"var(--bg4)",cursor:"pointer",transition:"all .15s"}}>
              <div style={{width:48,height:48,borderRadius:10,background:`linear-gradient(135deg,${t.bg},${t.primary},${t.secondary})`,flexShrink:0,boxShadow:`0 0 20px ${t.primary}60`}}/>
              <div style={{flex:1}}>
                <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:3}}>
                  <span style={{fontSize:14}}>{t.icon}</span>
                  <span style={{fontWeight:800,fontSize:13,color:current===+id?t.primary:"var(--text)"}}>{t.name}</span>
                  {t.recommended&&<span style={{padding:"1px 7px",borderRadius:5,fontSize:9,fontWeight:800,background:"rgba(0,255,179,.2)",color:"#00ffb3"}}>RECOMMENDED</span>}
                  {current===+id&&<span style={{padding:"1px 7px",borderRadius:5,fontSize:9,fontWeight:800,background:t.primary+"30",color:t.primary}}>ACTIVE</span>}
                </div>
                <div style={{display:"flex",gap:6}}>
                  {[t.primary,t.secondary,t.green,t.gold].map((c,i)=>(
                    <div key={i} style={{width:20,height:10,borderRadius:3,background:c}}/>
                  ))}
                  <div style={{width:60,height:10,borderRadius:3,background:t.metalGold}}/>
                  <span style={{fontSize:9,color:"var(--text3)",marginLeft:4}}>+ Metallic Gold</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function PriceTicker(){
  const[P,setP]=useState({BTC:0,ETH:0,SOL:0});
  useEffect(()=>{
    let ws;
    try{
      ws=new WebSocket("wss://stream.binance.com:9443/stream?streams=btcusdt@miniTicker/ethusdt@miniTicker/solusdt@miniTicker");
      ws.onmessage=e=>{const d=JSON.parse(e.data).data;if(!d)return;const p=parseFloat(d.c);if(d.s==="BTCUSDT")setP(v=>({...v,BTC:p}));if(d.s==="ETHUSDT")setP(v=>({...v,ETH:p}));if(d.s==="SOLUSDT")setP(v=>({...v,SOL:p}));};
      ws.onerror=ws.onclose=()=>setTimeout(()=>{},3000);
    }catch(e){}
    return()=>ws?.close();
  },[]);
  const f=(v,d=0)=>v>0?"$"+v.toLocaleString(undefined,{maximumFractionDigits:d}):"--";
  return(
    <div style={{display:"flex",gap:8,alignItems:"center"}}>
      {[["BTC",P.BTC,0],["ETH",P.ETH,0],["SOL",P.SOL,2]].map(([s,v,d])=>(
        <div key={s} style={{display:"flex",gap:5,padding:"3px 8px",background:"var(--bg3)",borderRadius:7,border:"1px solid var(--border2)"}}>
          <span style={{fontSize:9,color:"var(--text3)",fontWeight:700}}>{s}</span>
          <span style={{fontSize:11,color:"var(--green)",fontWeight:700,fontFamily:"monospace"}}>{f(v,d)}</span>
        </div>
      ))}
    </div>
  );
}

function Sidebar({collapsed,toggle,user,onLogout,onTheme}){
  return(
    <aside style={{width:collapsed?52:200,flexShrink:0,background:"var(--bg2)",borderRight:"1px solid var(--border)",display:"flex",flexDirection:"column",height:"100vh",position:"sticky",top:0,overflow:"hidden",transition:"width .2s",zIndex:100}}>
      <div style={{padding:collapsed?"12px 8px":"16px 14px",borderBottom:"1px solid var(--border)",display:"flex",alignItems:"center",gap:8}}>
        <span style={{fontSize:20,flexShrink:0}}>⚡</span>
        {!collapsed&&<div>
          <div style={{fontWeight:900,fontSize:15,color:"var(--text)",letterSpacing:-1}}><span style={{color:"var(--primary)"}}>estrading</span>.machine</div>
          <div style={{fontSize:9,color:"var(--text3)",fontFamily:"monospace"}}>v10 GODMODE</div>
        </div>}
      </div>
      <nav style={{flex:1,padding:"8px 5px",overflowY:"auto"}}>
        {NAV.map(({to,label,icon})=>(
          <NavLink key={to} to={to} end={to==="/"} style={({isActive})=>({display:"flex",alignItems:"center",gap:9,textDecoration:"none",padding:collapsed?"9px 0":"8px 10px",justifyContent:collapsed?"center":"flex-start",borderRadius:9,marginBottom:2,fontWeight:600,fontSize:12,background:isActive?"var(--bg4)":"transparent",color:isActive?"var(--text)":"var(--text3)",borderLeft:isActive?"2.5px solid var(--primary)":"2.5px solid transparent",transition:"all .12s"})}>
            <span style={{fontSize:15,flexShrink:0}}>{icon}</span>
            {!collapsed&&<span>{label}</span>}
          </NavLink>
        ))}
      </nav>
      <div style={{padding:"8px 5px",borderTop:"1px solid var(--border)"}}>
        <button onClick={onTheme} style={{display:"flex",alignItems:"center",gap:8,width:"100%",padding:collapsed?"9px 0":"7px 10px",justifyContent:collapsed?"center":"flex-start",background:"none",border:"none",cursor:"pointer",color:"var(--text3)",fontSize:12,borderRadius:8,fontFamily:"inherit"}} title="Change Theme">
          <span style={{fontSize:15}}>🎨</span>{!collapsed&&<span>Themes</span>}
        </button>
        <button onClick={onLogout} style={{display:"flex",alignItems:"center",gap:8,width:"100%",padding:collapsed?"9px 0":"7px 10px",justifyContent:collapsed?"center":"flex-start",background:"none",border:"none",cursor:"pointer",color:"var(--text3)",fontSize:12,borderRadius:8,fontFamily:"inherit"}} title="Logout">
          <span style={{fontSize:15}}>🚪</span>{!collapsed&&<span>{user?.role==="admin"?"Admin Logout":"Logout"}</span>}
        </button>
        <button onClick={toggle} style={{display:"flex",alignItems:"center",gap:8,width:"100%",padding:collapsed?"9px 0":"7px 10px",justifyContent:collapsed?"center":"flex-start",background:"none",border:"none",cursor:"pointer",color:"var(--text3)",fontSize:12,borderRadius:8,fontFamily:"inherit"}}>
          <span style={{fontSize:13}}>{collapsed?"→":"←"}</span>
          {!collapsed&&<span>Collapse</span>}
        </button>
      </div>
      {!collapsed&&(
        <div style={{padding:"8px 12px 12px",borderTop:"1px solid var(--border)",fontSize:9,color:"var(--text3)",fontFamily:"monospace",lineHeight:1.9}}>
          <div>📞 +255653712466</div>
          <div>✉️ estradingmachine@gmail.com</div>
          <div style={{marginTop:4,padding:"4px 8px",background:"rgba(0,255,179,.06)",borderRadius:6}}>
            🟢 v10 Online · 43 Bots · 9 AI
          </div>
        </div>
      )}
    </aside>
  );
}

function TopBar({onTheme}){
  const[time,setTime]=useState(new Date());
  useEffect(()=>{const iv=setInterval(()=>setTime(new Date()),1000);return()=>clearInterval(iv);},[]);
  const h=time.getUTCHours();
  const sess=h<8?"ASIA":h<12?"LONDON":h<17?"NEW YORK":h<21?"NY CLOSE":"OVERNIGHT";
  return(
    <header style={{height:44,background:"var(--bg2)",borderBottom:"1px solid var(--border)",display:"flex",alignItems:"center",padding:"0 16px",gap:10,position:"sticky",top:0,zIndex:99,flexShrink:0,backdropFilter:"blur(12px)"}}>
      <PriceTicker/>
      <div style={{display:"flex",alignItems:"center",gap:5,padding:"2px 8px",background:"rgba(0,255,179,.1)",borderRadius:6,border:"1px solid rgba(0,255,179,.25)"}}>
        <span style={{width:5,height:5,borderRadius:"50%",background:"#00ffb3",animation:"blink 1.5s infinite",display:"inline-block"}}/>
        <span style={{fontSize:9,color:"#00ffb3",fontWeight:700}}>LIVE</span>
      </div>
      <div style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:8}}>
        <div style={{padding:"3px 10px",background:"var(--bg4)",border:"1px solid var(--secondary)",borderRadius:6,fontSize:9,fontWeight:700,color:"var(--secondary)"}}>{sess} SESSION</div>
        <div style={{fontSize:10,color:"var(--text3)",fontFamily:"monospace"}}>{time.toUTCString().slice(17,25)} UTC</div>
        <button onClick={onTheme} style={{background:"var(--bg4)",border:"1px solid var(--border2)",borderRadius:7,padding:"4px 8px",cursor:"pointer",color:"var(--text3)",fontSize:11}}>🎨</button>
      </div>
    </header>
  );
}

export default function App(){
  const[user,setUser]=useState(null);
  const[booting,setBooting]=useState(true);
  const[collapsed,setCollapsed]=useState(false);
  const[showTheme,setShowTheme]=useState(false);

  useEffect(()=>{
    // Apply saved theme
    const tid=parseInt(localStorage.getItem("estrade_theme")||"1");
    applyTheme(THEMES[tid]);
    // Check existing session
    const token=localStorage.getItem("estrade_token");
    const savedUser=localStorage.getItem("estrade_user");
    if(token&&savedUser){try{setUser(JSON.parse(savedUser));}catch(e){}}
    setTimeout(()=>setBooting(false),1500);
  },[]);

  const handleLogin=(u)=>{
    setUser(u);
    localStorage.setItem("estrade_user",JSON.stringify(u));
  };
  const handleLogout=()=>{
    setUser(null);
    localStorage.removeItem("estrade_token");
    localStorage.removeItem("estrade_user");
  };

  if(booting) return<HexagonLoader size={160} text="Initializing v10 GODMODE..."/>;
  if(!user) return<Login onLogin={handleLogin}/>;

  return(
    <>
      <AnimationStyles/>
      <style>{`*{box-sizing:border-box;margin:0;padding:0}html{background:var(--bg,#050816);color:var(--text,#f8fafc);font-family:var(--font,'IBM Plex Sans',sans-serif)}::-webkit-scrollbar{width:3px}::-webkit-scrollbar-thumb{background:var(--border2,#334155);border-radius:2px}@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      {showTheme&&<ThemeModal onClose={()=>setShowTheme(false)}/>}
      <div style={{display:"flex",minHeight:"100vh",background:"var(--bg)"}}>
        <Sidebar collapsed={collapsed} toggle={()=>setCollapsed(c=>!c)} user={user} onLogout={handleLogout} onTheme={()=>setShowTheme(true)}/>
        <div style={{flex:1,display:"flex",flexDirection:"column",minWidth:0}}>
          <TopBar onTheme={()=>setShowTheme(true)}/>
          <main style={{flex:1,overflow:"auto",background:"var(--bg)"}}>
            <Suspense fallback={<div style={{display:"flex",justifyContent:"center",padding:60}}><HexagonLoader text="Loading..."/></div>}>
              <Routes>
                <Route path="/" element={<Dashboard/>}/>
                <Route path="/trade" element={<TradingPanel/>}/>
                <Route path="/bots" element={<Bots/>}/>
                <Route path="/signals" element={<Signals/>}/>
                <Route path="/reinvest" element={<Reinvest/>}/>
                <Route path="/ai-brain" element={<AIBrain/>}/>
                <Route path="/strategy" element={<StrategyBuilder/>}/>
                <Route path="/backtest" element={<Backtester/>}/>
                <Route path="/portfolio" element={<Portfolio/>}/>
                <Route path="/security" element={<Security/>}/>
                <Route path="/dev" element={<DevMode/>}/>
                <Route path="/settings" element={<Settings/>}/>
                <Route path="*" element={<Navigate to="/" replace/>}/>
              </Routes>
            </Suspense>
          </main>
        </div>
      </div>
    </>
  );
}
