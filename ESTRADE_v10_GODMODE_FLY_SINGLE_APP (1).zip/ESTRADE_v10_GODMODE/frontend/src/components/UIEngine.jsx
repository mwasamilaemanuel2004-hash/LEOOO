/**
 * components/UIEngine.jsx — estrading.machine v9 GODMODE
 * ══════════════════════════════════════════════════════════════════
 * Item #26: High-End Animation Engine
 * Item #27: Hexagon-Based ES MADE Loading System
 * Item #28: Dynamic Color Band System (adaptive UI themes)
 * Item #29: Wave Touch Interaction System (gesture-enabled UI)
 * ══════════════════════════════════════════════════════════════════
 */
import { useState, useEffect, useRef, useCallback } from "react";

// ══════════════════════════════════════════════════════════════
// #28: DYNAMIC COLOR BAND SYSTEM
// Adapts colors based on: market regime, bot performance, time
// ══════════════════════════════════════════════════════════════

export const COLOR_BANDS = {
  bull_strong:  { primary:"#00e5a0", secondary:"#00b87c", bg:"#031a10", glow:"0 0 30px #00e5a040", label:"BULL STRONG" },
  bull_normal:  { primary:"#22c55e", secondary:"#16a34a", bg:"#021409", glow:"0 0 20px #22c55e30", label:"BULLISH" },
  neutral:      { primary:"#6366f1", secondary:"#4f46e5", bg:"#06050f", glow:"0 0 20px #6366f130", label:"NEUTRAL" },
  bear_mild:    { primary:"#f97316", secondary:"#ea580c", bg:"#110900", glow:"0 0 20px #f9731630", label:"BEARISH" },
  bear_strong:  { primary:"#ef4444", secondary:"#dc2626", bg:"#110202", glow:"0 0 30px #ef444440", label:"BEAR STRONG" },
  high_vol:     { primary:"#f0a500", secondary:"#d97706", bg:"#100900", glow:"0 0 30px #f0a50040", label:"HIGH VOL" },
  crash:        { primary:"#dc2626", secondary:"#7f1d1d", bg:"#0f0000", glow:"0 0 40px #dc262650", label:"CRASH MODE" },
  breakout:     { primary:"#a78bfa", secondary:"#7c3aed", bg:"#0a0517", glow:"0 0 30px #a78bfa40", label:"BREAKOUT" },
};

export function useColorBand(regime = "neutral") {
  const [band, setBand] = useState(COLOR_BANDS.neutral);
  const [prevBand, setPrevBand] = useState(null);
  const [transitioning, setTransitioning] = useState(false);

  useEffect(() => {
    const newBand = COLOR_BANDS[regime] || COLOR_BANDS.neutral;
    if (newBand.primary !== band.primary) {
      setPrevBand(band);
      setTransitioning(true);
      setTimeout(() => {
        setBand(newBand);
        setTransitioning(false);
      }, 600);
    }
  }, [regime]);

  return { band, transitioning };
}

export function ColorBandOverlay({ regime }) {
  const { band, transitioning } = useColorBand(regime);
  return (
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0, height: 3,
      background: `linear-gradient(90deg, transparent, ${band.primary}, ${band.secondary}, ${band.primary}, transparent)`,
      opacity: transitioning ? 0.3 : 1,
      transition: "all 0.6s ease",
      zIndex: 9999,
      boxShadow: band.glow,
    }}/>
  );
}

// ══════════════════════════════════════════════════════════════
// #27: HEXAGON-BASED ES MADE LOADING SYSTEM
// Custom loader with ES + hexagon pattern
// ══════════════════════════════════════════════════════════════

export function HexagonLoader({ size = 120, text = "Loading AI..." }) {
  const [frame, setFrame] = useState(0);
  useEffect(() => {
    const iv = setInterval(() => setFrame(f => (f + 1) % 60), 50);
    return () => clearInterval(iv);
  }, []);

  // Hexagon polygon points
  const hex = (cx, cy, r) => {
    return Array.from({ length: 6 }, (_, i) => {
      const angle = (Math.PI / 3) * i - Math.PI / 6;
      return `${cx + r * Math.cos(angle)},${cy + r * Math.sin(angle)}`;
    }).join(" ");
  };

  const cx = size / 2, cy = size / 2, r = size * 0.38;
  const innerR = r * 0.55;
  const progress = (frame / 60) * 360;

  // Rotating ring segments
  const segments = 6;
  const segColors = ["#6366f1","#7c3aed","#a78bfa","#6366f1","#4f46e5","#818cf8"];

  return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:16 }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <defs>
          <filter id="hglow">
            <feGaussianBlur stdDeviation="3" result="blur"/>
            <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
          <linearGradient id="hgrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#6366f1"/>
            <stop offset="100%" stopColor="#00e5a0"/>
          </linearGradient>
        </defs>

        {/* Outer rotating hexagons */}
        {[0,1,2].map(i => (
          <polygon key={i}
            points={hex(cx, cy, r + i * 6)}
            fill="none"
            stroke={`rgba(99,102,241,${0.15 - i * 0.04})`}
            strokeWidth={1}
            style={{
              transform: `rotate(${progress + i * 20}deg)`,
              transformOrigin: `${cx}px ${cy}px`,
              transition: "transform 0.05s linear",
            }}
          />
        ))}

        {/* Main hexagon */}
        <polygon
          points={hex(cx, cy, r)}
          fill="rgba(99,102,241,0.08)"
          stroke="url(#hgrad)"
          strokeWidth={2}
          filter="url(#hglow)"
        />

        {/* Inner hexagon — pulse */}
        <polygon
          points={hex(cx, cy, innerR)}
          fill={`rgba(99,102,241,${0.12 + Math.sin(frame/5)*0.08})`}
          stroke="#6366f1"
          strokeWidth={1.5}
          style={{
            transform: `rotate(${-progress * 0.5}deg)`,
            transformOrigin: `${cx}px ${cy}px`,
          }}
        />

        {/* ES text center */}
        <text x={cx} y={cy - 4} textAnchor="middle" dominantBaseline="middle"
              fontSize={size * 0.16} fontWeight="900" fill="url(#hgrad)"
              fontFamily="Space Grotesk,sans-serif" letterSpacing="-1">
          ES
        </text>
        <text x={cx} y={cy + size * 0.13} textAnchor="middle" dominantBaseline="middle"
              fontSize={size * 0.07} fontWeight="700" fill="#475569"
              fontFamily="Space Grotesk,sans-serif">
          MADE
        </text>

        {/* Orbiting dots */}
        {[0,1,2,3,4,5].map(i => {
          const angle = ((progress + i * 60) * Math.PI) / 180;
          const orbitR = r + 14;
          const dx = cx + orbitR * Math.cos(angle);
          const dy = cy + orbitR * Math.sin(angle);
          return (
            <circle key={i} cx={dx} cy={dy} r={i === 0 ? 4 : 2.5}
                    fill={segColors[i]} opacity={i === 0 ? 1 : 0.5}
                    filter="url(#hglow)"/>
          );
        })}

        {/* Progress arc */}
        {(() => {
          const arcR = r + 22;
          const circumference = 2 * Math.PI * arcR;
          const offset = circumference - (progress / 360) * circumference;
          return (
            <circle cx={cx} cy={cy} r={arcR} fill="none"
                    stroke="url(#hgrad)" strokeWidth={2}
                    strokeDasharray={circumference}
                    strokeDashoffset={offset}
                    strokeLinecap="round"
                    style={{ transform: "rotate(-90deg)", transformOrigin: `${cx}px ${cy}px` }}/>
          );
        })()}
      </svg>
      <div style={{ fontSize:12, color:"#475569", fontWeight:600, letterSpacing:"0.1em", textTransform:"uppercase" }}>
        {text}
      </div>
    </div>
  );
}

export function FullScreenLoader({ text = "Initializing AI Systems..." }) {
  return (
    <div style={{
      position:"fixed", inset:0, background:"#020917",
      display:"flex", flexDirection:"column",
      alignItems:"center", justifyContent:"center", gap:24,
      zIndex:10000,
    }}>
      <HexagonLoader size={160} text={text}/>
      <div style={{ color:"#1e293b", fontSize:11, fontFamily:"monospace" }}>
        v9 GODMODE ULTRA — 43 BOTS — 7 AI MODELS
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
// #29: WAVE TOUCH INTERACTION SYSTEM
// Ripple effects on click/touch, smooth gesture feedback
// ══════════════════════════════════════════════════════════════

export function useWaveTouch() {
  const [waves, setWaves] = useState([]);
  const idRef = useRef(0);

  const createWave = useCallback((e, color = "#6366f1") => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX || (e.touches?.[0]?.clientX)) - rect.left;
    const y = (e.clientY || (e.touches?.[0]?.clientY)) - rect.top;
    const id = ++idRef.current;
    setWaves(w => [...w, { id, x, y, color }]);
    setTimeout(() => setWaves(w => w.filter(wave => wave.id !== id)), 700);
  }, []);

  return { waves, createWave };
}

export function WaveButton({ children, onClick, color = "#6366f1", style = {}, className = "", ...props }) {
  const { waves, createWave } = useWaveTouch();
  const [pressed, setPressed] = useState(false);

  const handleClick = (e) => {
    createWave(e, color);
    setPressed(true);
    setTimeout(() => setPressed(false), 150);
    onClick && onClick(e);
  };

  return (
    <button
      {...props}
      className={className}
      onClick={handleClick}
      style={{
        position: "relative",
        overflow: "hidden",
        transform: pressed ? "scale(0.97)" : "scale(1)",
        transition: "transform 0.1s ease",
        ...style,
      }}
    >
      {waves.map(w => (
        <span key={w.id} style={{
          position: "absolute",
          left: w.x, top: w.y,
          width: 0, height: 0,
          borderRadius: "50%",
          background: w.color,
          opacity: 0.35,
          transform: "translate(-50%,-50%)",
          animation: "wave-expand 0.7s ease-out forwards",
          pointerEvents: "none",
        }}/>
      ))}
      {children}
    </button>
  );
}

// ══════════════════════════════════════════════════════════════
// #26: HIGH-END ANIMATION ENGINE
// Smooth transitions, particle effects, data pulse animations
// ══════════════════════════════════════════════════════════════

export function PulsingOrb({ color = "#6366f1", size = 12, speed = 2 }) {
  return (
    <span style={{
      display: "inline-block", width: size, height: size,
      borderRadius: "50%", background: color,
      boxShadow: `0 0 ${size}px ${color}`,
      animation: `pulse-orb ${speed}s ease-in-out infinite`,
    }}/>
  );
}

export function GlowText({ children, color = "#6366f1", intensity = 1 }) {
  return (
    <span style={{
      color,
      textShadow: `0 0 ${10 * intensity}px ${color}, 0 0 ${20 * intensity}px ${color}40`,
    }}>
      {children}
    </span>
  );
}

export function AnimatedCounter({ value, duration = 1000, prefix = "", suffix = "", color = "#e2e8f0" }) {
  const [display, setDisplay] = useState(0);
  const startRef = useRef(null);
  const prevRef  = useRef(0);

  useEffect(() => {
    const start = performance.now();
    const from  = prevRef.current;
    const to    = value;
    prevRef.current = value;

    const step = (now) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased    = 1 - Math.pow(1 - progress, 3); // ease-out cubic
      setDisplay(from + (to - from) * eased);
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [value, duration]);

  const formatted = typeof value === "number" && value > 1000
    ? Math.round(display).toLocaleString()
    : display.toFixed(typeof value === "number" && value % 1 !== 0 ? 2 : 0);

  return <span style={{ color, fontWeight: 800, fontVariantNumeric: "tabular-nums" }}>
    {prefix}{formatted}{suffix}
  </span>;
}

export function DataFlowLine({ active = true, color = "#6366f1" }) {
  return (
    <div style={{
      height: 1, background: `linear-gradient(90deg, transparent, ${color}, transparent)`,
      opacity: active ? 1 : 0.2,
      animation: active ? "data-flow 2s linear infinite" : "none",
    }}/>
  );
}

export function FloatingParticles({ count = 20, color = "#6366f1" }) {
  const particles = Array.from({ length: count }, (_, i) => ({
    id: i,
    x:  Math.random() * 100,
    y:  Math.random() * 100,
    size: Math.random() * 3 + 1,
    dur:  Math.random() * 10 + 5,
    delay: Math.random() * 5,
  }));

  return (
    <div style={{ position:"absolute", inset:0, overflow:"hidden", pointerEvents:"none", zIndex:0 }}>
      {particles.map(p => (
        <div key={p.id} style={{
          position:"absolute", left:`${p.x}%`, top:`${p.y}%`,
          width: p.size, height: p.size, borderRadius:"50%",
          background: color, opacity: 0.15,
          animation: `float-particle ${p.dur}s ${p.delay}s ease-in-out infinite alternate`,
        }}/>
      ))}
    </div>
  );
}

export function GlassCard({ children, style = {}, glow = false, color = "#6366f1" }) {
  return (
    <div style={{
      background: "rgba(15,23,42,0.85)",
      backdropFilter: "blur(20px)",
      WebkitBackdropFilter: "blur(20px)",
      border: `1px solid ${glow ? color + "44" : "#1e293b"}`,
      borderRadius: 16,
      padding: 20,
      boxShadow: glow ? `0 0 32px ${color}22, 0 4px 24px rgba(0,0,0,0.4)` : "0 4px 24px rgba(0,0,0,0.3)",
      transition: "all 0.3s ease",
      ...style,
    }}>
      {children}
    </div>
  );
}

export function ProgressRing({ value, max = 100, size = 60, strokeWidth = 4, color = "#6366f1" }) {
  const r   = (size - strokeWidth) / 2;
  const circ= 2 * Math.PI * r;
  const pct = Math.min(value / max, 1);
  const off = circ * (1 - pct);

  return (
    <svg width={size} height={size} style={{ transform:"rotate(-90deg)" }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none"
              stroke="rgba(255,255,255,0.05)" strokeWidth={strokeWidth}/>
      <circle cx={size/2} cy={size/2} r={r} fill="none"
              stroke={color} strokeWidth={strokeWidth}
              strokeDasharray={circ} strokeDashoffset={off}
              strokeLinecap="round"
              style={{ transition:"stroke-dashoffset 0.5s ease" }}/>
    </svg>
  );
}

export function SignalStrengthBar({ value, max = 100, label = "" }) {
  const pct  = Math.round((value / max) * 100);
  const color= pct >= 80 ? "#00e5a0" : pct >= 60 ? "#22c55e" : pct >= 40 ? "#f59e0b" : "#ef4444";
  const bars = 5;

  return (
    <div style={{ display:"flex", alignItems:"center", gap:6 }}>
      {label && <span style={{ fontSize:10, color:"#475569", minWidth:32 }}>{label}</span>}
      <div style={{ display:"flex", gap:2 }}>
        {Array.from({ length: bars }, (_, i) => (
          <div key={i} style={{
            width: 4, height: 12 + i * 2,
            borderRadius: 2,
            background: i < Math.round(pct / (100/bars)) ? color : "#1e293b",
            transition: "background 0.3s",
          }}/>
        ))}
      </div>
      <span style={{ fontSize:10, color, fontWeight:700, fontFamily:"monospace" }}>
        {pct}%
      </span>
    </div>
  );
}

// Typewriter effect for AI-generated text
export function TypewriterText({ text = "", speed = 30, color = "#e2e8f0" }) {
  const [shown, setShown] = useState("");
  useEffect(() => {
    setShown("");
    let i = 0;
    const iv = setInterval(() => {
      if (i < text.length) {
        setShown(t => t + text[i]);
        i++;
      } else {
        clearInterval(iv);
      }
    }, speed);
    return () => clearInterval(iv);
  }, [text, speed]);

  return (
    <span style={{ color, fontFamily:"monospace", fontSize:13 }}>
      {shown}
      <span style={{ animation:"blink 1s infinite" }}>|</span>
    </span>
  );
}

// ══════════════════════════════════════════════════════════════
// ANIMATION CSS (inject into DOM)
// ══════════════════════════════════════════════════════════════
export function AnimationStyles() {
  return (
    <style>{`
      @keyframes wave-expand {
        from { width:0;height:0;opacity:.35 }
        to   { width:200px;height:200px;opacity:0 }
      }
      @keyframes pulse-orb {
        0%,100% { opacity:1; transform:scale(1) }
        50%      { opacity:.4; transform:scale(0.85) }
      }
      @keyframes data-flow {
        0%   { background-position:-200% 0 }
        100% { background-position:200% 0 }
      }
      @keyframes float-particle {
        0%   { transform:translateY(0) translateX(0) }
        100% { transform:translateY(-20px) translateX(10px) }
      }
      @keyframes blink {
        0%,49%  { opacity:1 }
        50%,100% { opacity:0 }
      }
      @keyframes glow-pulse {
        0%,100% { box-shadow:0 0 12px rgba(99,102,241,.3) }
        50%     { box-shadow:0 0 32px rgba(99,102,241,.6) }
      }
      @keyframes slide-up {
        from { opacity:0; transform:translateY(12px) }
        to   { opacity:1; transform:translateY(0) }
      }
      @keyframes scale-in {
        from { opacity:0; transform:scale(.95) }
        to   { opacity:1; transform:scale(1) }
      }
      .animate-slide-up  { animation: slide-up .3s ease-out }
      .animate-scale-in  { animation: scale-in .25s ease-out }
      .animate-glow      { animation: glow-pulse 3s infinite }
    `}</style>
  );
}
