/** Security.jsx */
import { useState, useEffect } from "react";
import { api } from "../utils/supabase.js";

export default function Security() {
  const [sec, setSec] = useState({});
  const load = () => api.get("/security/dashboard").then(setSec).catch(()=>{});
  useEffect(() => { load(); const iv=setInterval(load,10000); return ()=>clearInterval(iv); }, []);

  const StatusBadge = ({ status }) => (
    <span style={{
      padding:"3px 10px", borderRadius:6, fontSize:11, fontWeight:800,
      background: status==="SECURE"?"#14532d":status==="WARNING"?"#78350f":"#7f1d1d",
      color: status==="SECURE"?"#86efac":status==="WARNING"?"#fcd34d":"#fca5a5",
    }}>{status||"UNKNOWN"}</span>
  );

  return (
    <div style={{ padding:24, maxWidth:1000 }}>
      <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:20 }}>
        <h1 style={{ fontSize:24, fontWeight:900, color:"#f1f5f9" }}>🛡️ Security</h1>
        <StatusBadge status={sec.status}/>
      </div>

      {/* Security metrics */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))", gap:12, marginBottom:20 }}>
        {[
          { label:"Threat Level",   v: sec.threat_level || "LOW",    c:"#22c55e" },
          { label:"Failed Logins",  v: sec.failed_logins_24h || 0,   c:"#f97316" },
          { label:"Suspicious IPs", v: sec.suspicious_ips?.length||0,c:"#ef4444" },
          { label:"API Calls Today",v: sec.api_calls_today || 0,     c:"#6366f1" },
          { label:"Last Audit",     v: sec.last_audit_at ? new Date(sec.last_audit_at).toLocaleTimeString() : "—", c:"#94a3b8" },
          { label:"2FA Users",      v: sec.two_fa_users || 0,        c:"#22c55e" },
        ].map(s=>(
          <div key={s.label} className="card" style={{ textAlign:"center" }}>
            <div style={{ fontSize:20, fontWeight:900, color:s.c }}>{s.v}</div>
            <div style={{ fontSize:11, color:"#475569", marginTop:4 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Security rules */}
      <div className="card" style={{ marginBottom:16 }}>
        <h3 style={{ fontSize:14, fontWeight:700, color:"#e2e8f0", marginBottom:12 }}>🔒 Security Rules</h3>
        {[
          { rule:"API keys encrypted with Fernet symmetric encryption", ok:true },
          { rule:"Withdrawal permission disabled on all exchange connections", ok:true },
          { rule:"Rate limiting: 100 req/min per IP", ok:true },
          { rule:"JWT token expiry: 7 days", ok:true },
          { rule:"Row Level Security (RLS) on all Supabase tables", ok:true },
          { rule:"Cloudflare Worker CORS proxy — keys never touch servers", ok:true },
          { rule:"Emergency stop available on all bots", ok:true },
          { rule:"Suspicious IP auto-block after 5 failed attempts", ok:true },
        ].map((s,i)=>(
          <div key={i} style={{ display:"flex", alignItems:"center", gap:10, padding:"6px 0",
                               borderBottom:"1px solid #0f172a" }}>
            <span style={{ color:s.ok?"#22c55e":"#ef4444", flexShrink:0 }}>{s.ok?"✅":"❌"}</span>
            <span style={{ fontSize:13, color:s.ok?"#e2e8f0":"#94a3b8" }}>{s.rule}</span>
          </div>
        ))}
      </div>

      {/* Security events */}
      {sec.recent_events?.length > 0 && (
        <div className="card">
          <h3 style={{ fontSize:14, fontWeight:700, color:"#e2e8f0", marginBottom:12 }}>📋 Recent Events</h3>
          {sec.recent_events.slice(0,10).map((e,i)=>(
            <div key={i} style={{ display:"flex", gap:12, padding:"6px 0", borderBottom:"1px solid #0f172a",
                                 fontSize:12 }}>
              <span style={{ color:"#475569", flexShrink:0 }}>
                {new Date(e.created_at).toLocaleTimeString()}
              </span>
              <span style={{ color: e.severity==="HIGH"?"#ef4444":e.severity==="MEDIUM"?"#f97316":"#94a3b8",
                            fontWeight:700 }}>{e.type}</span>
              <span style={{ color:"#64748b" }}>{JSON.stringify(e.data||{})}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
