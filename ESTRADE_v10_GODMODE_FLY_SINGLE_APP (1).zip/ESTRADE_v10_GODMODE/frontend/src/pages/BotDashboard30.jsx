import { useState, useEffect, useCallback, useRef } from "react";

// ── Data ─────────────────────────────────────────────────────
const CATS = {
  hybrid:       { label:"Hybrid",             color:"#22c55e", icon:"🟢", risk:"Low" },
  high_profit:  { label:"High Profit Low Risk",color:"#f59e0b", icon:"🟡", risk:"Low-Med" },
  medium:       { label:"Medium Balanced",     color:"#f97316", icon:"🟠", risk:"Medium" },
  crypto_scalp: { label:"Crypto Scalping AI",  color:"#6366f1", icon:"🔵", risk:"Med-High" },
  forex:        { label:"Forex Bots",          color:"#ef4444", icon:"🔴", risk:"Med-High" },
};

const TIERS = {
  silver:   { label:"Silver",   icon:"🥈", color:"#94a3b8", ml:false, dl:false },
  gold:     { label:"Gold",     icon:"🥇", color:"#f59e0b", ml:true,  dl:false },
  platinum: { label:"Platinum", icon:"💎", color:"#e2e8f0", ml:true,  dl:true  },
};

const MODES = {
  safe:                 { label:"Risk Control",   icon:"🛡️", color:"#22c55e" },
  hybrid:               { label:"Hybrid AI",      icon:"⚡", color:"#f59e0b" },
  aggressive:           { label:"High Risk",      icon:"🔥", color:"#ef4444" },
  aggressive_protected: { label:"Risk + Guard",   icon:"💥", color:"#a855f7" },
};

const BOTS = [
  // HYBRID (6)
  {id:"hybrid_alpha",    name:"Hybrid Alpha",        cat:"hybrid",      icon:"🌐", color:"#22c55e",  tier:"gold",    special:"BTC/EUR correlation Z-score hedge"},
  {id:"hybrid_pro",      name:"Hybrid Pro",           cat:"hybrid",      icon:"⚡", color:"#06b6d4",  tier:"gold",    special:"3-strategy ensemble majority vote"},
  {id:"smart_balance",   name:"Smart Balance Bot",    cat:"hybrid",      icon:"⚖️", color:"#a855f7",  tier:"silver",  special:"Hourly Sharpe-weighted rebalancing"},
  {id:"stable_hybrid",   name:"Stable Hybrid AI",     cat:"hybrid",      icon:"🛡️", color:"#10b981",  tier:"silver",  special:"Enters only in low-vol environments"},
  {id:"adaptive_hybrid", name:"Adaptive Hybrid Bot",  cat:"hybrid",      icon:"🔄", color:"#f59e0b",  tier:"gold",    special:"Auto regime-switching strategy"},
  {id:"precision_hybrid",name:"Precision Hybrid",     cat:"hybrid",      icon:"🎯", color:"#6366f1",  tier:"gold",    special:"Fibonacci 61.8% + pivot confluence"},
  // HIGH PROFIT (6)
  {id:"safe_profit",     name:"Safe Profit Bot",      cat:"high_profit", icon:"💰", color:"#22c55e",  tier:"silver",  special:"RSI-gated Smart DCA, 5 layers max"},
  {id:"capital_guard",   name:"Capital Guard Bot",     cat:"high_profit", icon:"🛡️", color:"#06b6d4",  tier:"gold",    special:"Hard 5% daily loss circuit-breaker"},
  {id:"smart_entry",     name:"Smart Entry Bot",       cat:"high_profit", icon:"🎯", color:"#f59e0b",  tier:"gold",    special:"4/5 indicator alignment required"},
  {id:"elite_low_risk",  name:"Elite Low Risk Bot",    cat:"high_profit", icon:"💎", color:"#a855f7",  tier:"platinum",special:"AI confidence ≥92% gate — platinum only"},
  {id:"precision_safe",  name:"Precision Safe Trader", cat:"high_profit", icon:"🔬", color:"#ec4899",  tier:"gold",    special:"S/R bounce with candle confirmation"},
  {id:"risk_shield",     name:"Risk Shield AI",        cat:"high_profit", icon:"🔒", color:"#10b981",  tier:"gold",    special:"Auto-hedge on opposite pair entry"},
  // MEDIUM (6)
  {id:"balanced_trader", name:"Balanced Trader",       cat:"medium",      icon:"⚡", color:"#f59e0b",  tier:"silver",  special:"ADX-guided trend/mean-rev rotation"},
  {id:"swing_ai",        name:"Swing AI Bot",          cat:"medium",      icon:"🌊", color:"#6366f1",  tier:"gold",    special:"Ichimoku + MACD divergence swing"},
  {id:"momentum_balance",name:"Momentum Balance Bot",  cat:"medium",      icon:"🚀", color:"#f97316",  tier:"gold",    special:"RSI + volume + Keltner burst detect"},
  {id:"smart_growth",    name:"Smart Growth Bot",      cat:"medium",      icon:"📈", color:"#22c55e",  tier:"silver",  special:"Win-streak compounding, auto-reset"},
  {id:"multi_strategy",  name:"Multi Strategy AI",     cat:"medium",      icon:"🧠", color:"#a855f7",  tier:"gold",    special:"5 simultaneous strategies, best wins"},
  {id:"dynamic_trader",  name:"Dynamic Trader",        cat:"medium",      icon:"🔄", color:"#06b6d4",  tier:"gold",    special:"Real-time volatility position scaling"},
  // CRYPTO SCALP (6)
  {id:"crypto_scalper_alpha",name:"Crypto Scalper Alpha",cat:"crypto_scalp",icon:"⚡", color:"#f97316",  tier:"silver",  special:"EMA 3/8 micro-cross — tier-adaptive AI"},
  {id:"btc_sniper",      name:"BTC Sniper",            cat:"crypto_scalp",icon:"🎯", color:"#f59e0b",  tier:"gold",    special:"Breakout + whale accumulation detect"},
  {id:"eth_flash",       name:"ETH Flash Bot",         cat:"crypto_scalp",icon:"⚡", color:"#6366f1",  tier:"gold",    special:"Liquidity zones + stop-hunt fade"},
  {id:"volatility_sniper",name:"Volatility Sniper",    cat:"crypto_scalp",icon:"💥", color:"#ec4899",  tier:"gold",    special:"BB squeeze → burst candle entry"},
  {id:"order_flow",      name:"Order Flow Bot",        cat:"crypto_scalp",icon:"📊", color:"#10b981",  tier:"gold",    special:"Candle anatomy OFI + CVD pressure"},
  {id:"beta_scalping_bot",name:"BETA AI Scalping",     cat:"crypto_scalp",icon:"🌌", color:"#a855f7",  tier:"platinum",special:"8 conditions, 500 patterns, 10000× compound"},
  // FOREX (6)
  {id:"forex_trend",     name:"Forex Trend Master",    cat:"forex",       icon:"📈", color:"#22c55e",  tier:"gold",    special:"EMA 50/200 + macro institutional trend"},
  {id:"forex_scalper_pro",name:"Forex Scalper Pro",    cat:"forex",       icon:"⚡", color:"#f59e0b",  tier:"gold",    special:"M1/M5 EMA8/21 + RSI 40-60 band"},
  {id:"fx_swing",        name:"FX Swing AI",           cat:"forex",       icon:"🌊", color:"#6366f1",  tier:"gold",    special:"Ichimoku + Fibonacci 61.8 + news filter"},
  {id:"news_forex",      name:"News Forex Bot",        cat:"forex",       icon:"📰", color:"#ec4899",  tier:"gold",    special:"High-impact news 5min window entry"},
  {id:"fx_institutional",name:"FX Institutional Bot",  cat:"forex",       icon:"🏛️", color:"#06b6d4",  tier:"platinum",special:"SMC: Order Blocks + FVG + BOS"},
  {id:"gramma_ai_bot",   name:"GRAMMA AI",             cat:"forex",       icon:"🌐", color:"#10b981",  tier:"platinum",special:"Crypto/Forex Z-score divergence hedge"},
];

// ── Hooks ─────────────────────────────────────────────────────
function useRuntime(botId, running) {
  const [pnl, setPnl] = useState(()=>(Math.random()-.38)*420);
  const [conf, setConf] = useState(()=>Math.round(55+Math.random()*40));
  const [action, setAction] = useState("WAIT");
  useEffect(()=>{
    if(!running) return;
    const t = setInterval(()=>{
      setPnl(p => p+(Math.random()-.46)*(botId.includes("scalp")||botId.includes("sniper")?1.4:0.7));
      const c = Math.round(48+Math.random()*48);
      setConf(c);
      setAction(c>68?"BUY":c<44?"SELL":"WAIT");
    }, 2000+Math.random()*2000);
    return ()=>clearInterval(t);
  },[running,botId]);
  return {pnl,conf,action};
}

// ── Mini Spark ────────────────────────────────────────────────
function Spark({data,color,h=22,w=80}){
  if(!data||data.length<2) return null;
  const mn=Math.min(...data),mx=Math.max(...data),rng=mx-mn||1;
  const pts=data.map((v,i)=>`${i/(data.length-1)*w},${h-((v-mn)/rng)*h}`).join(" ");
  const fp=pts+` ${w},${h} 0,${h}`;
  const id="s"+color.replace("#","");
  return <svg width={w} height={h}><defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity="0.3"/><stop offset="100%" stopColor={color} stopOpacity="0"/></linearGradient></defs><polygon points={fp} fill={`url(#${id})`}/><polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round"/></svg>;
}

// ── AI Ring ───────────────────────────────────────────────────
function AIRing({val,action,size=44}){
  const r=size*.36,circ=2*Math.PI*r,off=circ-(val/100)*circ;
  const col=action==="BUY"?"#22c55e":action==="SELL"?"#ef4444":"#475569";
  return(
    <div style={{position:"relative",width:size,height:size,flexShrink:0}}>
      <svg width={size} height={size} style={{transform:"rotate(-90deg)"}}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="3.5"/>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={col} strokeWidth="3.5"
          strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={off}
          style={{transition:"all 0.8s ease"}}/>
      </svg>
      <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
        <div style={{fontSize:8,fontWeight:800,color:col,fontFamily:"monospace"}}>{val}%</div>
        <div style={{fontSize:6,color:col,letterSpacing:.5}}>{action}</div>
      </div>
    </div>
  );
}

// ── Tier Badge ────────────────────────────────────────────────
function TierBadge({tier,small}){
  const t=TIERS[tier]||TIERS.silver;
  return(
    <span style={{
      fontSize:small?7:8, padding:small?"1px 5px":"2px 7px", borderRadius:4,
      background:`${t.color}18`, border:`1px solid ${t.color}30`,
      color:t.color, fontFamily:"monospace", fontWeight:700, letterSpacing:.5,
      whiteSpace:"nowrap",
    }}>{t.icon} {t.label.toUpperCase()}</span>
  );
}

// ── Capital Mode Settings ──────────────────────────────────────
function ModePanel({botId, currentMode, onSelect}){
  return(
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6,marginBottom:10}}>
      {Object.entries(MODES).map(([k,m])=>{
        const sel=currentMode===k;
        return(
          <button key={k} onClick={()=>onSelect(k)} style={{
            padding:"8px 10px",borderRadius:8,cursor:"pointer",textAlign:"left",
            border:`1px solid ${sel?m.color:"rgba(255,255,255,0.05)"}`,
            background:sel?`${m.color}12`:"rgba(255,255,255,0.02)",
            color:sel?m.color:"#64748b",transition:"all 0.18s",
            boxShadow:sel?`0 2px 12px ${m.color}18`:"none",
          }}>
            <div style={{fontSize:14,marginBottom:3}}>{m.icon}</div>
            <div style={{fontSize:8.5,fontWeight:700,fontFamily:"monospace"}}>{m.label}</div>
          </button>
        );
      })}
    </div>
  );
}

// ── AI Analyst Mini Panel ──────────────────────────────────────
function AnalystPanel({bot, action, conf, pnl}){
  const riskLvl = conf < 60?"CRITICAL":conf < 70?"HIGH":conf < 80?"MEDIUM":"LOW";
  const riskCol = {CRITICAL:"#ef4444",HIGH:"#f97316",MEDIUM:"#f59e0b",LOW:"#22c55e"}[riskLvl];
  const winProb = Math.min(92, conf*.7 + 8);
  return(
    <div style={{
      padding:"10px 12px",borderRadius:8,marginBottom:10,
      background:"rgba(255,255,255,0.025)",border:"1px solid rgba(255,255,255,0.05)",
      animation:"fadeIn 0.3s ease",
    }}>
      <div style={{fontSize:7.5,color:"#64748b",fontFamily:"monospace",letterSpacing:2,marginBottom:8}}>
        ⬡ AI ANALYST
      </div>
      {/* Headline */}
      <div style={{fontSize:9,fontWeight:700,color:"#e2e8f0",marginBottom:6,lineHeight:1.4}}>
        {action==="BUY"?"📈 Bullish signal detected on "+bot.name:
         action==="SELL"?"📉 Bearish pressure on "+bot.name:
         "⏸ Waiting for confirmation signal"}
      </div>
      {/* Risk row */}
      <div style={{display:"flex",gap:6,alignItems:"center",marginBottom:6}}>
        <span style={{fontSize:7.5,padding:"2px 7px",borderRadius:4,fontFamily:"monospace",
          background:`${riskCol}18`,border:`1px solid ${riskCol}28`,color:riskCol}}>
          {riskLvl} RISK
        </span>
        <span style={{fontSize:7.5,color:"#475569"}}>Win prob: {winProb.toFixed(0)}%</span>
        <span style={{fontSize:7.5,color:pnl>=0?"#22c55e":"#ef4444",marginLeft:"auto",fontFamily:"monospace"}}>
          P&L: {pnl>=0?"+":""}{pnl.toFixed(2)}
        </span>
      </div>
      {/* Reasoning */}
      <div style={{fontSize:8,color:"#475569",lineHeight:1.5}}>
        {action==="BUY"?
          `${bot.special}. AI confidence ${conf}% — ${conf>75?"high conviction entry":"moderate setup, monitor closely"}.`:
          action==="SELL"?
          `Bearish momentum detected. ${bot.special}. SL recommended at 2× ATR.`:
          `Waiting for ${bot.special.toLowerCase()} conditions to align.`
        }
      </div>
    </div>
  );
}

// ── Bot Card ──────────────────────────────────────────────────
function BotCard({bot}){
  const [open, setOpen]   = useState(false);
  const [run, setRun]     = useState(false);
  const [tier, setTier]   = useState(bot.tier);
  const [mode, setMode]   = useState("safe");
  const [showAnalyst, setShowAnalyst] = useState(false);
  const {pnl, conf, action} = useRuntime(bot.id, run);
  const [spark] = useState(()=>Array.from({length:20},(_,i)=>900+i*9+(Math.random()-.46)*22));
  const cat    = CATS[bot.category]||CATS.hybrid;
  const pos    = pnl >= 0;

  return(
    <div style={{
      background:"rgba(8,14,28,0.92)",backdropFilter:"blur(14px)",
      border:`1px solid ${open||run?bot.color+"40":"rgba(255,255,255,0.05)"}`,
      borderRadius:12,overflow:"hidden",
      boxShadow:run?`0 0 0 1px ${bot.color}15,0 6px 24px ${bot.color}0a`:"none",
      transition:"border-color .25s,box-shadow .25s",
    }}>
      {/* Active strip */}
      {run&&<div style={{height:1.5,background:`linear-gradient(90deg,transparent,${bot.color},transparent)`,
        animation:"pulse 2s ease infinite"}}/>}

      <div style={{padding:"12px 14px"}}>
        {/* Row 1: icon + names + ring + toggle */}
        <div style={{display:"flex",alignItems:"center",gap:9,marginBottom:9}}>
          <div style={{width:34,height:34,borderRadius:8,flexShrink:0,
            background:`${bot.color}14`,border:`1px solid ${bot.color}22`,
            display:"flex",alignItems:"center",justifyContent:"center",fontSize:15}}>
            {bot.icon}
          </div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:11,fontWeight:700,color:"#e2e8f0",overflow:"hidden",
              textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{bot.name}</div>
            <div style={{display:"flex",gap:5,alignItems:"center",marginTop:2,flexWrap:"wrap"}}>
              <span style={{fontSize:7,padding:"1px 5px",borderRadius:3,
                background:`${cat.color}15`,color:cat.color,fontFamily:"monospace"}}>
                {cat.icon} {cat.label}
              </span>
              <TierBadge tier={tier} small/>
            </div>
          </div>
          <AIRing val={run?conf:0} action={run?action:"WAIT"}/>
          {/* Run toggle */}
          <button onClick={()=>setRun(v=>!v)} style={{
            width:34,height:18,borderRadius:9,border:"none",cursor:"pointer",flexShrink:0,
            background:run?bot.color:"rgba(255,255,255,0.07)",position:"relative",transition:"background .2s",
          }}>
            <div style={{width:12,height:12,borderRadius:6,background:"#fff",
              position:"absolute",top:3,left:run?18:2,transition:"left .2s"}}/>
          </button>
        </div>

        {/* Row 2: PnL + spark */}
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:8}}>
          <div>
            <div style={{fontSize:7.5,color:"#334155",fontFamily:"monospace",letterSpacing:1,marginBottom:2}}>P&L</div>
            <div style={{fontSize:17,fontWeight:800,fontFamily:"monospace",lineHeight:1,
              color:pos?"#22c55e":"#ef4444"}}>
              {pos?"+":""}{pnl.toFixed(2)}
              <span style={{fontSize:7.5,fontWeight:400,marginLeft:2}}>USDT</span>
            </div>
            {run&&<div style={{fontSize:7.5,fontFamily:"monospace",marginTop:2,
              color:"#334155",animation:"pulse 2s ease infinite"}}>● LIVE</div>}
          </div>
          <Spark data={spark} color={pos?"#22c55e":"#ef4444"}/>
        </div>

        {/* Row 3: special feature */}
        <div style={{fontSize:7.5,color:"#334155",marginBottom:8,lineHeight:1.4,
          fontStyle:"italic",borderLeft:`2px solid ${bot.color}40`,paddingLeft:6}}>
          {bot.special}
        </div>

        {/* Buttons row */}
        <div style={{display:"flex",gap:6}}>
          <button onClick={()=>setOpen(v=>!v)} style={{
            flex:1,padding:"7px",borderRadius:7,cursor:"pointer",
            border:`1px solid ${open?bot.color+"60":"rgba(255,255,255,0.07)"}`,
            background:open?`${bot.color}10`:"rgba(255,255,255,0.03)",
            color:open?bot.color:"#475569",
            fontSize:8,fontFamily:"monospace",letterSpacing:1.5,fontWeight:700,
            display:"flex",alignItems:"center",justifyContent:"center",gap:4,
            transition:"all .2s",
          }}>
            <span style={{transform:open?"rotate(180deg)":"none",transition:"transform .22s",display:"inline-block"}}>▼</span>
            {open?"CLOSE":"SETTINGS"}
          </button>
          <button onClick={()=>setShowAnalyst(v=>!v)} style={{
            padding:"7px 10px",borderRadius:7,cursor:"pointer",
            border:`1px solid ${showAnalyst?"#06b6d4":"rgba(255,255,255,0.07)"}`,
            background:showAnalyst?"rgba(6,182,212,0.1)":"rgba(255,255,255,0.03)",
            color:showAnalyst?"#06b6d4":"#475569",
            fontSize:8,fontFamily:"monospace",transition:"all .2s",
          }}>🧠</button>
        </div>
      </div>

      {/* Analyst panel */}
      {showAnalyst&&(
        <div style={{padding:"0 14px 2px",animation:"slideDown .22s ease"}}>
          <AnalystPanel bot={bot} action={run?action:"WAIT"} conf={run?conf:0} pnl={pnl}/>
        </div>
      )}

      {/* Settings accordion */}
      {open&&(
        <div style={{borderTop:"1px solid rgba(255,255,255,0.04)",padding:"14px 14px 16px",
          animation:"slideDown .25s cubic-bezier(.4,0,.2,1)"}}>

          {/* Capital Mode */}
          <div style={{fontSize:7.5,color:"#334155",fontFamily:"monospace",letterSpacing:2,marginBottom:8}}>
            CAPITAL MODE
          </div>
          <ModePanel botId={bot.id} currentMode={mode} onSelect={setMode}/>

          {/* AI Tier upgrade */}
          <div style={{fontSize:7.5,color:"#334155",fontFamily:"monospace",letterSpacing:2,marginBottom:8}}>
            AI TIER — UPGRADE
          </div>
          <div style={{display:"flex",gap:6,marginBottom:12}}>
            {Object.entries(TIERS).map(([k,t])=>{
              const sel=tier===k;
              const avail = k==="platinum"?bot.tier==="platinum"||true:true;
              return(
                <button key={k} onClick={()=>avail&&setTier(k)} style={{
                  flex:1,padding:"7px 4px",borderRadius:7,cursor:avail?"pointer":"not-allowed",
                  border:`1px solid ${sel?t.color:"rgba(255,255,255,0.05)"}`,
                  background:sel?`${t.color}12`:"rgba(255,255,255,0.02)",
                  color:sel?t.color:"#475569",transition:"all .18s",
                  boxShadow:sel?`0 2px 10px ${t.color}15`:"none",
                  opacity:avail?1:0.4,
                }}>
                  <div style={{fontSize:14}}>{t.icon}</div>
                  <div style={{fontSize:7.5,fontWeight:700,fontFamily:"monospace",marginTop:2}}>{k.toUpperCase()}</div>
                  {k!=="silver"&&<div style={{fontSize:6.5,color:"#334155",marginTop:1}}>
                    {k==="gold"?"$19.99":"$49.99"}
                  </div>}
                </button>
              );
            })}
          </div>

          {/* Mode warning */}
          {mode==="aggressive"&&(
            <div style={{padding:"7px 10px",borderRadius:7,marginBottom:10,
              background:"rgba(239,68,68,0.08)",border:"1px solid rgba(239,68,68,0.2)",
              fontSize:8,color:"#ef4444",animation:"pulse 2s ease infinite"}}>
              ⚠️ High Risk Mode – Possible FULL capital loss
            </div>
          )}

          {/* Equity mini chart */}
          <div style={{padding:"8px 10px",borderRadius:7,marginBottom:10,
            background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.04)"}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
              <span style={{fontSize:7,color:"#334155",fontFamily:"monospace",letterSpacing:1}}>
                EQUITY ({MODES[mode]?.label})
              </span>
              <span style={{fontSize:8,fontWeight:700,fontFamily:"monospace",
                color:mode==="safe"?"#22c55e":mode==="hybrid"?"#f59e0b":"#ef4444"}}>
                {mode==="safe"?"+14.2%":mode==="hybrid"?"+28.7%":mode==="aggressive_protected"?"+52.1%":"+81.4%"}
              </span>
            </div>
            <Spark w={200} h={36}
              data={Array.from({length:30},(_,i)=>
                mode==="safe"?1000+i*5+(Math.random()-.3)*10:
                mode==="hybrid"?1000+i*9+(Math.random()-.38)*22:
                mode==="aggressive_protected"?1000+i*17+(Math.random()-.46)*55:
                1000+i*27+(Math.random()-.49)*90
              )}
              color={MODES[mode]?.color||"#22c55e"}/>
          </div>

          {/* Stats grid */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:5}}>
            {[
              {l:"Regime",v:"Trending",c:"#f59e0b"},
              {l:"Win Rate",v:tier==="platinum"?"71%":tier==="gold"?"63%":"55%",c:"#22c55e"},
              {l:"AI Conf",v:`${TIERS[tier]?.label||"Silver"}`,c:TIERS[tier]?.color||"#94a3b8"},
            ].map(({l,v,c})=>(
              <div key={l} style={{textAlign:"center",padding:"7px 4px",
                background:"rgba(255,255,255,0.02)",borderRadius:6}}>
                <div style={{fontSize:11,fontWeight:800,fontFamily:"monospace",color:c}}>{v}</div>
                <div style={{fontSize:6.5,color:"#334155",marginTop:1,letterSpacing:.5}}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Category Section ──────────────────────────────────────────
function CategorySection({catKey, bots}){
  const [collapsed, setCollapsed] = useState(false);
  const cat = CATS[catKey];
  const count = bots.length;
  return(
    <div style={{marginBottom:24}}>
      <button onClick={()=>setCollapsed(v=>!v)} style={{
        display:"flex",alignItems:"center",gap:10,
        width:"100%",background:"none",border:"none",cursor:"pointer",
        padding:"10px 0",marginBottom:collapsed?0:14,textAlign:"left",
      }}>
        <span style={{fontSize:16}}>{cat.icon}</span>
        <div>
          <div style={{fontSize:12,fontWeight:800,color:cat.color,letterSpacing:.5}}>{cat.label}</div>
          <div style={{fontSize:8,color:"#334155",fontFamily:"monospace",marginTop:1}}>
            {count} bots · Risk: {cat.risk}
          </div>
        </div>
        <div style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:8}}>
          <span style={{fontSize:8,padding:"2px 8px",borderRadius:4,
            background:`${cat.color}15`,color:cat.color,fontFamily:"monospace"}}>
            {count} BOTS
          </span>
          <span style={{color:"#334155",fontSize:10,transform:collapsed?"rotate(-90deg)":"none",
            transition:"transform .22s",display:"inline-block"}}>▼</span>
        </div>
      </button>
      {!collapsed&&(
        <div style={{
          display:"grid",
          gridTemplateColumns:"repeat(auto-fill,minmax(290px,1fr))",
          gap:12,
        }}>
          {bots.map(b=><BotCard key={b.id} bot={b}/>)}
        </div>
      )}
    </div>
  );
}

// ── Global Header ─────────────────────────────────────────────
function Header(){
  const [total, setTotal] = useState(18247.33);
  useEffect(()=>{
    const t=setInterval(()=>setTotal(v=>v+(Math.random()-.42)*8),3000);
    return()=>clearInterval(t);
  },[]);
  const pos = total >= 18000;
  return(
    <div style={{marginBottom:22}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",
        marginBottom:16,flexWrap:"wrap",gap:12}}>
        <div>
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:3}}>
            <span style={{fontSize:22,fontWeight:900,letterSpacing:2,fontFamily:"monospace",
              background:"linear-gradient(135deg,#06b6d4 20%,#22c55e 80%)",
              WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>
              ESTRADE v6
            </span>
            <span style={{fontSize:8,padding:"3px 10px",borderRadius:20,
              background:"rgba(6,182,212,0.1)",border:"1px solid rgba(6,182,212,0.2)",
              color:"#06b6d4",fontFamily:"monospace",letterSpacing:1}}>30 BOTS · AI ENTERPRISE</span>
          </div>
          <div style={{fontSize:8,color:"#1e293b",fontFamily:"monospace",letterSpacing:2}}>
            INSTITUTIONAL GRADE · TIERED AI · MULTI-BROKER · ANALYST SYSTEM
          </div>
        </div>
        <div style={{textAlign:"right"}}>
          <div style={{fontSize:8,color:"#334155",fontFamily:"monospace",letterSpacing:1}}>PORTFOLIO VALUE</div>
          <div style={{fontSize:22,fontWeight:900,fontFamily:"monospace",
            color:pos?"#22c55e":"#ef4444"}}>
            ${total.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}
          </div>
        </div>
      </div>
      {/* Stats */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:10}}>
        {[
          {l:"Total Bots",  v:"30",    c:"#06b6d4", s:"5 categories"},
          {l:"Running",     v:"18",    c:"#22c55e", s:"Active now"},
          {l:"Win Rate",    v:"68.2%", c:"#f59e0b", s:"Last 30 days"},
          {l:"Platinum Bots",v:"6",   c:"#e2e8f0", s:"Elite AI"},
          {l:"AI Analyst",  v:"ON",   c:"#a855f7", s:"All trades explained"},
        ].map(({l,v,c,s})=>(
          <div key={l} style={{padding:"11px 14px",borderRadius:10,
            background:"rgba(8,14,28,0.9)",backdropFilter:"blur(8px)",
            border:"1px solid rgba(255,255,255,0.04)"}}>
            <div style={{fontSize:7.5,color:"#1e293b",fontFamily:"monospace",letterSpacing:1,marginBottom:5}}>{l}</div>
            <div style={{fontSize:17,fontWeight:800,color:c,fontFamily:"monospace",lineHeight:1}}>{v}</div>
            <div style={{fontSize:7.5,color:"#0f172a",marginTop:3}}>{s}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────
export default function App(){
  const grouped = {};
  BOTS.forEach(b=>{ if(!grouped[b.cat]) grouped[b.cat]=[]; grouped[b.cat].push(b); });
  const catOrder = ["hybrid","high_profit","medium","crypto_scalp","forex"];

  return(
    <div style={{
      minHeight:"100vh",
      fontFamily:"'Exo 2','Segoe UI',system-ui,sans-serif",
      background:"linear-gradient(135deg,#020510 0%,#06101e 50%,#020510 100%)",
      color:"#e2e8f0",
    }}>
      <style>{`
        @keyframes slideDown{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:translateY(0)}}
        @keyframes fadeIn{from{opacity:0}to{opacity:1}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.55}}
        ::-webkit-scrollbar{width:4px;height:4px}
        ::-webkit-scrollbar-track{background:transparent}
        ::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.07);border-radius:4px}
      `}</style>
      <div style={{maxWidth:1440,margin:"0 auto",padding:"20px 18px"}}>
        <Header/>
        {catOrder.map(k=>(
          <CategorySection key={k} catKey={k} bots={grouped[k]||[]}/>
        ))}
        <div style={{textAlign:"center",marginTop:16,fontSize:7.5,color:"#0f172a",
          fontFamily:"monospace",letterSpacing:2}}>
          ESTRADE v6 · 30 BOTS · 57 FILES · 10 MIGRATIONS · FULLY AUDITED
        </div>
      </div>
    </div>
  );
}
