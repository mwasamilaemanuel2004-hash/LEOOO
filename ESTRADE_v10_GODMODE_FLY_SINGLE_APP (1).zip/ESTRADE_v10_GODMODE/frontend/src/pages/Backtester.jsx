/** Backtester.jsx — ESTRADE v8 GODMODE */
import { useState } from "react";
import { api } from "../utils/supabase.js";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const PAIRS  = ["BTCUSDT","ETHUSDT","SOLUSDT","BNBUSDT","XRPUSDT","DOGEUSDT","ADAUSDT","EURUSD","XAUUSD"];
const TFS    = ["1m","5m","15m","30m","1h","4h","1d"];

export default function Backtester() {
  const [symbol,    setSymbol]    = useState("BTCUSDT");
  const [tf,        setTf]        = useState("1h");
  const [balance,   setBalance]   = useState(10000);
  const [result,    setResult]    = useState(null);
  const [genome,    setGenome]    = useState(null);
  const [running,   setRunning]   = useState(false);
  const [evolving,  setEvolving]  = useState(false);
  const [history,   setHistory]   = useState([]);

  const run = async () => {
    setRunning(true);
    setResult(null);
    try {
      const r = await api.post("/backtest/run", {
        symbol, timeframe: tf, initial_balance: parseFloat(balance), use_best_genome: true,
      });
      setResult(r.result);
      setGenome(r.genome);
      const entry = { symbol, tf, ...r.result, ts: new Date().toLocaleTimeString() };
      setHistory(h=>[entry,...h.slice(0,9)]);
    } catch(e) { alert("Backtest failed: "+e.message); }
    setRunning(false);
  };

  const evolve = async () => {
    setEvolving(true);
    try {
      const r = await api.post("/backtest/evolve",{});
      if (r.success) alert(`✅ Evolution complete! Gen ${r.generation} — Best fitness: ${r.best?.fitness?.toFixed(3)}`);
    } catch(e) { alert("Evolution failed"); }
    setEvolving(false);
  };

  const metric = (label, value, color="#e2e8f0", fmt=v=>v) => (
    <div style={{ textAlign:"center", background:"#0f172a", borderRadius:10, padding:14 }}>
      <div style={{ fontSize:22, fontWeight:900, color }}>{fmt(value)}</div>
      <div style={{ fontSize:11, color:"#475569", marginTop:4 }}>{label}</div>
    </div>
  );

  return (
    <div style={{ padding:24, maxWidth:1200 }}>
      <h1 style={{ fontSize:24, fontWeight:900, color:"#f1f5f9", marginBottom:6 }}>📈 Strategy Backtester</h1>
      <p style={{ fontSize:13, color:"#475569", marginBottom:20 }}>
        Walk-forward backtest with no lookahead bias. Tests the current best evolved strategy genome.
      </p>

      {/* Controls */}
      <div className="card" style={{ marginBottom:20 }}>
        <div style={{ display:"flex", gap:12, flexWrap:"wrap", alignItems:"flex-end" }}>
          <div>
            <label style={{ fontSize:11, color:"#94a3b8", display:"block", marginBottom:4 }}>Symbol</label>
            <select className="select" value={symbol} onChange={e=>setSymbol(e.target.value)} style={{ width:140 }}>
              {PAIRS.map(p=><option key={p}>{p}</option>)}
            </select>
          </div>
          <div>
            <label style={{ fontSize:11, color:"#94a3b8", display:"block", marginBottom:4 }}>Timeframe</label>
            <select className="select" value={tf} onChange={e=>setTf(e.target.value)} style={{ width:100 }}>
              {TFS.map(t=><option key={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label style={{ fontSize:11, color:"#94a3b8", display:"block", marginBottom:4 }}>Starting Balance ($)</label>
            <input className="input" type="number" value={balance} onChange={e=>setBalance(e.target.value)} style={{ width:130 }}/>
          </div>
          <button className="btn btn-primary" onClick={run} disabled={running} style={{ height:40 }}>
            {running ? "⏳ Running..." : "▶ Run Backtest"}
          </button>
          <button className="btn" onClick={evolve} disabled={evolving}
            style={{ height:40, background:"linear-gradient(135deg,#7c3aed,#6366f1)", color:"#fff", fontWeight:800 }}>
            {evolving ? "🧬 Evolving..." : "🧬 Evolve Strategy"}
          </button>
        </div>
      </div>

      {/* Results */}
      {result && (
        <>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))", gap:10, marginBottom:20 }}>
            {metric("Total Return", result.total_return, result.total_return>=0?"#22c55e":"#ef4444", v=>`${v?.toFixed(2)}%`)}
            {metric("Sharpe Ratio", result.sharpe, result.sharpe>=1?"#22c55e":result.sharpe>=0?"#f59e0b":"#ef4444", v=>v?.toFixed(3))}
            {metric("Win Rate", result.win_rate, result.win_rate>=0.55?"#22c55e":"#f97316", v=>`${((v||0)*100).toFixed(1)}%`)}
            {metric("Profit Factor", result.profit_factor, result.profit_factor>=1.5?"#22c55e":"#f97316", v=>v?.toFixed(2))}
            {metric("Max Drawdown", result.max_drawdown, "#ef4444", v=>`${v?.toFixed(2)}%`)}
            {metric("Total Trades", result.total_trades, "#6366f1")}
            {metric("Final Balance", result.final_balance, "#22c55e", v=>`$${v?.toFixed(2)}`)}
          </div>

          {/* Rating */}
          <div className="card" style={{ marginBottom:20 }}>
            <div style={{ display:"flex", gap:16, alignItems:"center" }}>
              <div style={{ fontSize:40 }}>
                {result.sharpe>=2 && result.win_rate>=0.6 ? "🏆" :
                 result.sharpe>=1 && result.win_rate>=0.5 ? "✅" :
                 result.sharpe>=0 ? "⚠️" : "❌"}
              </div>
              <div>
                <div style={{ fontSize:16, fontWeight:900, color:"#f1f5f9" }}>
                  {result.sharpe>=2 && result.win_rate>=0.6 ? "EXCELLENT — Deploy Now" :
                   result.sharpe>=1 && result.win_rate>=0.5 ? "GOOD — Consider deploying" :
                   result.sharpe>=0 ? "MARGINAL — Keep evolving" : "POOR — Do not deploy"}
                </div>
                <div style={{ fontSize:12, color:"#475569", marginTop:4 }}>
                  Fitness score: {result.fitness?.toFixed(4) || "N/A"}
                </div>
              </div>
            </div>
          </div>

          {/* Genome */}
          {genome && (
            <div className="card" style={{ marginBottom:20 }}>
              <h3 style={{ fontSize:13, fontWeight:700, color:"#94a3b8", marginBottom:10 }}>🔬 Strategy Parameters</h3>
              <div style={{ display:"flex", flexWrap:"wrap", gap:8 }}>
                {Object.entries(genome).map(([k,v])=>(
                  <div key={k} style={{ background:"#0f172a", padding:"4px 10px", borderRadius:6,
                                       fontSize:11, color:"#94a3b8" }}>
                    <span style={{ color:"#475569" }}>{k}: </span>
                    <strong style={{ color:"#e2e8f0" }}>{typeof v==="number"?v.toFixed?.(2):v}</strong>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {/* History */}
      {history.length > 0 && (
        <div className="card">
          <h3 style={{ fontSize:13, fontWeight:700, color:"#94a3b8", marginBottom:12 }}>📋 Backtest History</h3>
          <table style={{ width:"100%", fontSize:12, borderCollapse:"collapse" }}>
            <thead>
              <tr style={{ borderBottom:"1px solid #1e293b" }}>
                {["Time","Symbol","TF","Return","Sharpe","WinRate","Trades"].map(h=>(
                  <th key={h} style={{ padding:"4px 8px", textAlign:"left", color:"#475569" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {history.map((h,i)=>(
                <tr key={i} style={{ borderBottom:"1px solid #0f172a" }}>
                  <td style={{ padding:"4px 8px", color:"#475569" }}>{h.ts}</td>
                  <td style={{ padding:"4px 8px", color:"#e2e8f0", fontWeight:700 }}>{h.symbol}</td>
                  <td style={{ padding:"4px 8px", color:"#64748b" }}>{h.tf}</td>
                  <td style={{ padding:"4px 8px", color:(h.total_return||0)>=0?"#22c55e":"#ef4444", fontWeight:700 }}>
                    {(h.total_return||0).toFixed(2)}%
                  </td>
                  <td style={{ padding:"4px 8px", color:"#f59e0b" }}>{(h.sharpe||0).toFixed(3)}</td>
                  <td style={{ padding:"4px 8px", color:"#a78bfa" }}>{((h.win_rate||0)*100).toFixed(1)}%</td>
                  <td style={{ padding:"4px 8px", color:"#64748b" }}>{h.total_trades}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
