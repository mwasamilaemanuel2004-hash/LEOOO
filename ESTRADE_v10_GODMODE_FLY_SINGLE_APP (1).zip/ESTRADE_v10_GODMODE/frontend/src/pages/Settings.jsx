/** Settings.jsx — API connections, preferences, Deriv token */
import { useState, useEffect } from "react";
import { api, auth } from "../utils/supabase.js";

const InputRow = ({ label, value, onChange, type="text", placeholder="" }) => (
  <div style={{ marginBottom:12 }}>
    <label style={{ fontSize:12, color:"#94a3b8", display:"block", marginBottom:4 }}>{label}</label>
    <input className="input" type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}/>
  </div>
);

export default function Settings() {
  const [tab,      setTab]      = useState("connections");
  const [binance,  setBinance]  = useState({ key:"", secret:"", label:"My Binance" });
  const [mt5,      setMt5]      = useState({ login:"", password:"", server:"", url:"", broker:"" });
  const [deriv,    setDeriv]    = useState({ token:"", app_id:"" });
  const [bybit,    setBybit]    = useState({ key:"", secret:"" });
  const [oanda,    setOanda]    = useState({ account:"", token:"" });
  const [conns,    setConns]    = useState([]);
  const [saving,   setSaving]   = useState({});
  const [msg,      setMsg]      = useState("");

  useEffect(() => {
    api.get("/exchange/connections").then(r=>setConns(r.connections||[])).catch(()=>{});
  }, []);

  const save = async (type, data) => {
    setSaving(s=>({...s,[type]:true}));
    setMsg("");
    try {
      if (type === "binance" || type === "bybit") {
        await api.post("/exchange/connect", {
          exchange: type,
          api_key: data.key,
          api_secret: data.secret,
          label: data.label || `My ${type}`,
        });
        setMsg(`✅ ${type} connected successfully!`);
      } else if (type === "mt5") {
        await api.post("/exchange/connect-mt5", data);
        setMsg("✅ MT5 connected!");
      } else if (type === "deriv") {
        localStorage.setItem("estrade_deriv_token", data.token);
        localStorage.setItem("estrade_deriv_app_id", data.app_id);
        setMsg("✅ Deriv token saved locally (secure)");
      } else if (type === "oanda") {
        await api.post("/exchange/connect", {
          exchange: "oanda", api_key: data.account,
          api_secret: data.token, label: "My OANDA",
        });
        setMsg("✅ OANDA connected!");
      }
      const r = await api.get("/exchange/connections");
      setConns(r.connections||[]);
    } catch(e) {
      setMsg(`❌ Error: ${e.message || "Connection failed"}`);
    }
    setSaving(s=>({...s,[type]:false}));
  };

  const TABS = [
    { id:"connections", label:"🔌 Connections" },
    { id:"deriv",       label:"📊 Deriv" },
    { id:"security",    label:"🔒 Security" },
    { id:"account",     label:"👤 Account" },
  ];

  return (
    <div style={{ padding:24, maxWidth:800 }}>
      <h1 style={{ fontSize:24, fontWeight:900, color:"#f1f5f9", marginBottom:20 }}>⚙️ Settings</h1>

      {msg && (
        <div style={{ padding:12, background: msg.startsWith("✅")?"#052e16":"#450a0a",
                     border:`1px solid ${msg.startsWith("✅")?"#22c55e44":"#ef444444"}`,
                     borderRadius:10, marginBottom:16, fontSize:13, color: msg.startsWith("✅")?"#86efac":"#fca5a5" }}>
          {msg}
        </div>
      )}

      {/* Tabs */}
      <div style={{ display:"flex", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        {TABS.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)}
            style={{
              padding:"8px 14px", borderRadius:10, fontWeight:700, fontSize:13,
              border:"none", cursor:"pointer",
              background: tab===t.id?"linear-gradient(135deg,#4f46e5,#7c3aed)":"#0f172a",
              color: tab===t.id?"#fff":"#475569",
            }}>{t.label}</button>
        ))}
      </div>

      {/* Connections tab */}
      {tab === "connections" && (
        <div>
          {/* Active connections */}
          {conns.length > 0 && (
            <div className="card" style={{ marginBottom:16 }}>
              <h3 style={{ fontSize:14, fontWeight:700, color:"#e2e8f0", marginBottom:10 }}>
                🔌 Active Connections
              </h3>
              {conns.map((c,i)=>(
                <div key={i} style={{ display:"flex", justifyContent:"space-between",
                                     padding:"8px 0", borderBottom:"1px solid #0f172a", fontSize:12 }}>
                  <div>
                    <span style={{ color:"#e2e8f0", fontWeight:700 }}>{c.exchange?.toUpperCase()}</span>
                    <span style={{ color:"#475569", marginLeft:8 }}>{c.label}</span>
                  </div>
                  <span style={{ color:c.status==="active"?"#22c55e":"#f97316", fontWeight:700 }}>
                    {c.status || "connected"}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Binance */}
          <div className="card" style={{ marginBottom:16 }}>
            <h3 style={{ fontSize:14, fontWeight:700, color:"#f0b90b", marginBottom:14 }}>
              🅱 Binance
            </h3>
            <InputRow label="API Key" value={binance.key} onChange={v=>setBinance(b=>({...b,key:v}))} placeholder="Paste API key..."/>
            <InputRow label="Secret Key" value={binance.secret} onChange={v=>setBinance(b=>({...b,secret:v}))} type="password" placeholder="Paste secret..."/>
            <InputRow label="Label" value={binance.label} onChange={v=>setBinance(b=>({...b,label:v}))}/>
            <div style={{ background:"#0f172a", borderRadius:8, padding:10, marginBottom:12, fontSize:11, color:"#475569" }}>
              🔒 Keys are encrypted with AES-256 before storage. Withdrawal permission must be DISABLED.
            </div>
            <button className="btn btn-primary" onClick={()=>save("binance",binance)} disabled={saving.binance}>
              {saving.binance?"Connecting...":"Connect Binance"}
            </button>
          </div>

          {/* Bybit */}
          <div className="card" style={{ marginBottom:16 }}>
            <h3 style={{ fontSize:14, fontWeight:700, color:"#f7a600", marginBottom:14 }}>🔶 Bybit</h3>
            <InputRow label="API Key" value={bybit.key} onChange={v=>setBybit(b=>({...b,key:v}))} placeholder="Bybit API key..."/>
            <InputRow label="Secret" value={bybit.secret} onChange={v=>setBybit(b=>({...b,secret:v}))} type="password"/>
            <button className="btn btn-primary" onClick={()=>save("bybit",bybit)} disabled={saving.bybit}>
              {saving.bybit?"Connecting...":"Connect Bybit"}
            </button>
          </div>

          {/* MT5 */}
          <div className="card" style={{ marginBottom:16 }}>
            <h3 style={{ fontSize:14, fontWeight:700, color:"#2563eb", marginBottom:14 }}>📊 MetaTrader 5</h3>
            <InputRow label="Login" value={mt5.login} onChange={v=>setMt5(m=>({...m,login:v}))}/>
            <InputRow label="Password" value={mt5.password} onChange={v=>setMt5(m=>({...m,password:v}))} type="password"/>
            <InputRow label="Server" value={mt5.server} onChange={v=>setMt5(m=>({...m,server:v}))} placeholder="e.g. ICMarkets-Live01"/>
            <InputRow label="Broker REST URL" value={mt5.url} onChange={v=>setMt5(m=>({...m,url:v}))} placeholder="https://your-broker.com/api"/>
            <button className="btn btn-primary" onClick={()=>save("mt5",mt5)} disabled={saving.mt5}>
              {saving.mt5?"Connecting...":"Connect MT5"}
            </button>
          </div>

          {/* OANDA */}
          <div className="card">
            <h3 style={{ fontSize:14, fontWeight:700, color:"#ea580c", marginBottom:14 }}>🟠 OANDA</h3>
            <InputRow label="Account ID" value={oanda.account} onChange={v=>setOanda(o=>({...o,account:v}))}/>
            <InputRow label="API Token" value={oanda.token} onChange={v=>setOanda(o=>({...o,token:v}))} type="password"/>
            <button className="btn btn-primary" onClick={()=>save("oanda",oanda)} disabled={saving.oanda}>
              {saving.oanda?"Connecting...":"Connect OANDA"}
            </button>
          </div>
        </div>
      )}

      {/* Deriv tab */}
      {tab === "deriv" && (
        <div className="card">
          <h3 style={{ fontSize:14, fontWeight:700, color:"#a78bfa", marginBottom:6 }}>
            📊 Deriv API Token
          </h3>
          <p style={{ fontSize:12, color:"#64748b", marginBottom:14, lineHeight:1.6 }}>
            Get your API token from <strong style={{color:"#a78bfa"}}>app.deriv.com/account/api-token</strong>.<br/>
            Required scopes: <code style={{background:"#0f172a",padding:"1px 4px",borderRadius:3}}>Read, Trade, Payments</code><br/>
            Token is stored locally in your browser — never sent to ESTRADE servers.
          </p>
          <InputRow label="API Token" value={deriv.token} onChange={v=>setDeriv(d=>({...d,token:v}))} placeholder="AAAA..."/>
          <InputRow label="App ID (optional)" value={deriv.app_id} onChange={v=>setDeriv(d=>({...d,app_id:v}))} placeholder="36544"/>
          <div style={{ background:"#1a0d2e", borderRadius:10, padding:12, marginBottom:12,
                       fontSize:11, color:"#a78bfa", border:"1px solid #7c3aed44" }}>
            ⚠️ Deriv Synthetic Indices are available 24/7 on simulated markets.
            Volatility indices do NOT correlate with real asset prices.
            Only enable if you understand the risks.
          </div>
          <button className="btn" onClick={()=>save("deriv",deriv)} disabled={saving.deriv}
            style={{ background:"linear-gradient(135deg,#7c3aed,#6366f1)", color:"#fff", fontWeight:800 }}>
            ✅ {saving.deriv?"Saving...":"Save Deriv Token"}
          </button>
        </div>
      )}

      {/* Security tab */}
      {tab === "security" && (
        <div>
          <div className="card" style={{ marginBottom:16 }}>
            <h3 style={{ fontSize:14, fontWeight:700, color:"#e2e8f0", marginBottom:12 }}>🔒 Security Settings</h3>
            {[
              "Enable 2-Factor Authentication",
              "Email alerts for new logins",
              "Telegram trade notifications",
              "IP whitelist for API access",
            ].map((s,i)=>(
              <div key={i} style={{ display:"flex", justifyContent:"space-between", alignItems:"center",
                                   padding:"10px 0", borderBottom:"1px solid #0f172a" }}>
                <span style={{ fontSize:13, color:"#e2e8f0" }}>{s}</span>
                <button style={{ width:42, height:24, borderRadius:12, cursor:"pointer", border:"none",
                                background:"#1e293b" }}>
                  <span style={{ width:18, height:18, borderRadius:"50%", background:"#475569",
                                position:"relative", top:3, left:3 }}/>
                </button>
              </div>
            ))}
          </div>
          <button className="btn btn-danger" onClick={()=>{ if(confirm("Log out of all sessions?")) auth.logout(); }}>
            🚪 Logout All Sessions
          </button>
        </div>
      )}

      {/* Account tab */}
      {tab === "account" && (
        <div className="card">
          <h3 style={{ fontSize:14, fontWeight:700, color:"#e2e8f0", marginBottom:12 }}>👤 Account</h3>
          <div style={{ fontSize:12, color:"#475569", marginBottom:16 }}>
            Manage your ESTRADE account settings and subscription.
          </div>
          <div style={{ display:"grid", gap:12 }}>
            {[
              { label:"Silver Plan", desc:"Basic AI + all bots", price:"Free", color:"#94a3b8" },
              { label:"Gold Plan",   desc:"Advanced AI + priority signals", price:"$29/mo", color:"#f59e0b" },
              { label:"Platinum",    desc:"Full AI + DL models + dedicated support", price:"$99/mo", color:"#7c3aed" },
            ].map(plan=>(
              <div key={plan.label} style={{
                padding:14, borderRadius:12,
                border:`1px solid ${plan.color}44`,
                background:`${plan.color}08`,
                display:"flex", justifyContent:"space-between", alignItems:"center",
              }}>
                <div>
                  <div style={{ fontWeight:800, color:plan.color }}>{plan.label}</div>
                  <div style={{ fontSize:12, color:"#475569", marginTop:2 }}>{plan.desc}</div>
                </div>
                <div style={{ textAlign:"right" }}>
                  <div style={{ fontWeight:900, color:plan.color }}>{plan.price}</div>
                  <button className="btn-primary btn" style={{ fontSize:11, padding:"4px 12px", marginTop:6 }}>
                    Upgrade
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
