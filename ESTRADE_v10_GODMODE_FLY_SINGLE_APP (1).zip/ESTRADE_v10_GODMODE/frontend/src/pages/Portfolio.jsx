/**
 * Portfolio.jsx — ESTRADE v8 GODMODE
 */
import { useState, useEffect } from "react";
import { api, subscribeTrades } from "../utils/supabase.js";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";

export default function Portfolio() {
  const [portfolio, setPortfolio] = useState({});
  const [trades,    setTrades]    = useState([]);
  const [full,      setFull]      = useState({});
  const [tab,       setTab]       = useState("overview");

  const load = async () => {
    const [p, t, f] = await Promise.allSettled([
      api.get("/portfolio"),
      api.get("/trades?limit=100"),
      api.get("/portfolio/full"),
    ]);
    if (p.status==="fulfilled") setPortfolio(p.value||{});
    if (t.status==="fulfilled") setTrades(t.value?.trades||[]);
    if (f.status==="fulfilled") setFull(f.value||{});
  };

  useEffect(() => {
    load();
    const iv = setInterval(load, 15000);
    return () => clearInterval(iv);
  }, []);

  // Build equity curve from trades
  const equity = trades.filter(t=>t.status==="closed").reduce((acc, t) => {
    const last = acc[acc.length-1]?.equity || 10000;
    acc.push({ time: new Date(t.created_at||Date.now()).toLocaleDateString(),
               equity: last + (t.pnl||0) });
    return acc;
  }, [{ time:"Start", equity:10000 }]).slice(-50);

  const closed = trades.filter(t=>t.status==="closed");
  const wins   = closed.filter(t=>(t.pnl||0)>0);
  const totalPnl = closed.reduce((a,t)=>a+(t.pnl||0),0);

  return (
    <div style={{ padding:24, maxWidth:1400 }}>
      <h1 style={{ fontSize:24, fontWeight:900, color:"#f1f5f9", marginBottom:20 }}>💼 Portfolio</h1>

      {/* Stats grid */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(160px,1fr))", gap:12, marginBottom:24 }}>
        {[
          { label:"Balance",     v:`$${(portfolio.balance||0).toLocaleString(undefined,{minimumFractionDigits:2})}`, c:"#22c55e" },
          { label:"Total Profit",v:`$${totalPnl.toFixed(2)}`, c: totalPnl>=0?"#22c55e":"#ef4444" },
          { label:"Today PnL",   v:`${(portfolio.pnl_pct||0)>=0?"+":""}${(portfolio.pnl_pct||0).toFixed(2)}%`, c: (portfolio.pnl_pct||0)>=0?"#22c55e":"#ef4444" },
          { label:"Total Trades",v:closed.length, c:"#6366f1" },
          { label:"Win Rate",    v:`${(wins.length/Math.max(closed.length,1)*100).toFixed(1)}%`, c:"#f59e0b" },
          { label:"Open Trades", v:portfolio.open_trades||0, c:"#3b82f6" },
        ].map(s=>(
          <div key={s.label} className="card" style={{ textAlign:"center" }}>
            <div style={{ fontSize:22, fontWeight:900, color:s.c }}>{s.v}</div>
            <div style={{ fontSize:11, color:"#475569", marginTop:4 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Equity Curve */}
      <div className="card" style={{ marginBottom:20 }}>
        <h3 style={{ fontSize:14, fontWeight:700, color:"#e2e8f0", marginBottom:12 }}>📈 Equity Curve</h3>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={equity}>
            <defs>
              <linearGradient id="eqGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis dataKey="time" tick={{ fill:"#475569", fontSize:10 }} axisLine={false} tickLine={false}/>
            <YAxis tick={{ fill:"#475569", fontSize:10 }} axisLine={false} tickLine={false}/>
            <Tooltip contentStyle={{ background:"#0f172a", border:"1px solid #1e293b", borderRadius:8 }}
                     formatter={v=>[`$${v.toFixed(2)}`, "Equity"]}/>
            <Area type="monotone" dataKey="equity" stroke="#6366f1" fill="url(#eqGrad)" strokeWidth={2}/>
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Trade History */}
      <div className="card">
        <h3 style={{ fontSize:14, fontWeight:700, color:"#e2e8f0", marginBottom:12 }}>
          📋 Trade History ({closed.length} trades)
        </h3>
        <div style={{ overflowX:"auto" }}>
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12 }}>
            <thead>
              <tr style={{ borderBottom:"1px solid #1e293b" }}>
                {["Time","Symbol","Direction","Size","Entry","PnL","Status"].map(h=>(
                  <th key={h} style={{ padding:"6px 10px", textAlign:"left", color:"#475569", fontWeight:600 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {trades.slice(0,50).map((t,i)=>{
                const pnl = t.pnl||0;
                return (
                  <tr key={i} style={{ borderBottom:"1px solid #0f172a" }}>
                    <td style={{ padding:"6px 10px", color:"#475569" }}>
                      {new Date(t.created_at||Date.now()).toLocaleString()}
                    </td>
                    <td style={{ padding:"6px 10px", color:"#e2e8f0", fontWeight:700 }}>{t.symbol||"—"}</td>
                    <td style={{ padding:"6px 10px" }}>
                      <span style={{ color: t.direction==="buy"?"#22c55e":"#ef4444",
                                    fontWeight:700, textTransform:"uppercase" }}>
                        {t.direction||"—"}
                      </span>
                    </td>
                    <td style={{ padding:"6px 10px", color:"#94a3b8" }}>
                      ${(t.size_usd||0).toFixed(2)}
                    </td>
                    <td style={{ padding:"6px 10px", color:"#94a3b8" }}>
                      {(t.entry_price||0).toFixed(4)}
                    </td>
                    <td style={{ padding:"6px 10px", fontWeight:700,
                                color: pnl>=0?"#22c55e":"#ef4444" }}>
                      {pnl>=0?"+":""}{pnl.toFixed(2)} ({(t.pnl_pct||0).toFixed(2)}%)
                    </td>
                    <td style={{ padding:"6px 10px" }}>
                      <span style={{
                        padding:"2px 8px", borderRadius:4, fontSize:10, fontWeight:700,
                        background: t.status==="closed" ? "#14532d" : t.status==="open" ? "#1e3a5f" : "#1e293b",
                        color: t.status==="closed" ? "#86efac" : t.status==="open" ? "#93c5fd" : "#94a3b8",
                      }}>{t.status||"—"}</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
