import { useState } from "react";
import { api } from "../utils/supabase.js";
import { HexagonLoader } from "../components/UIEngine.jsx";

export default function Login({ onLogin }) {
  const [tab,  setTab]  = useState("login");
  const [email, setEmail] = useState("");
  const [pass,  setPass]  = useState("");
  const [name,  setName]  = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (!email || !pass) { setError("Email and password required"); return; }
    setLoading(true); setError("");
    try {
      if (tab === "login") {
        const r = await api.post("/auth/login", { email, password: pass });
        if (r.token) { localStorage.setItem("estrade_token", r.token); onLogin(r.user); }
      } else {
        if (!name) { setError("Full name required"); setLoading(false); return; }
        await api.post("/auth/register", { email, password: pass, full_name: name });
        setTab("login"); setError("✅ Registered! Please login.");
      }
    } catch(e) { setError(e.detail || e.message || "Authentication failed"); }
    setLoading(false);
  };

  const S = {
    wrap:{ position:"fixed",inset:0,background:"#020917",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'IBM Plex Sans',sans-serif" },
    box:{ width:400,background:"#060f1e",border:"1px solid #1a3052",borderRadius:20,padding:36,boxShadow:"0 32px 80px rgba(0,0,0,.8)" },
    logo:{ textAlign:"center",marginBottom:28 },
    logoT:{ fontSize:26,fontWeight:900,color:"#f0f4ff",letterSpacing:-1 },
    logoS:{ color:"#00ffb3" },
    logoV:{ fontSize:10,color:"#334155",fontFamily:"monospace",marginTop:2 },
    tabs:{ display:"flex",marginBottom:24,background:"#0a1628",borderRadius:10,padding:4,gap:4 },
    tab:{ flex:1,padding:"8px 0",borderRadius:8,border:"none",cursor:"pointer",fontWeight:700,fontSize:13,fontFamily:"inherit",transition:"all .15s" },
    inp:{ width:"100%",background:"#0a1628",border:"1px solid #1a3052",borderRadius:10,padding:"10px 14px",color:"#f0f4ff",fontSize:13,fontFamily:"inherit",outline:"none",marginBottom:10 },
    lbl:{ fontSize:10,fontWeight:700,color:"#475569",display:"block",marginBottom:4,textTransform:"uppercase",letterSpacing:".06em" },
    btn:{ width:"100%",padding:12,borderRadius:10,border:"none",cursor:"pointer",fontWeight:800,fontSize:14,fontFamily:"inherit",transition:"all .15s",marginTop:6 },
    err:{ padding:"10px 14px",background:"rgba(255,59,92,.12)",border:"1px solid rgba(255,59,92,.3)",borderRadius:9,fontSize:12,color:"#ff3b5c",marginBottom:12,textAlign:"center" },
    ok:{ padding:"10px 14px",background:"rgba(0,255,179,.08)",border:"1px solid rgba(0,255,179,.25)",borderRadius:9,fontSize:12,color:"#00ffb3",marginBottom:12,textAlign:"center" },
  };

  if (loading) return <div style={S.wrap}><HexagonLoader size={120} text="Authenticating..."/></div>;

  return (
    <div style={S.wrap}>
      <div style={S.box}>
        <div style={S.logo}>
          <div style={S.logoT}>⚡ <span style={S.logoS}>estrading</span>.machine</div>
          <div style={S.logoV}>v10 GODMODE — AI Trading System</div>
        </div>
        <div style={S.tabs}>
          {["login","register"].map(t => (
            <button key={t} onClick={() => { setTab(t); setError(""); }}
              style={{...S.tab, background:tab===t?"linear-gradient(135deg,#4f46e5,#7c3aed)":"transparent", color:tab===t?"#fff":"#475569" }}>
              {t==="login" ? "🔐 Login" : "✨ Register"}
            </button>
          ))}
        </div>
        {error && <div style={error.startsWith("✅") ? S.ok : S.err}>{error}</div>}
        {tab === "register" && <>
          <label style={S.lbl}>Full Name</label>
          <input style={S.inp} placeholder="Your full name" value={name} onChange={e=>setName(e.target.value)}/>
        </>}
        <label style={S.lbl}>Email</label>
        <input style={S.inp} type="email" placeholder="you@example.com" value={email} onChange={e=>setEmail(e.target.value)}/>
        <label style={S.lbl}>Password</label>
        <input style={S.inp} type="password" placeholder="••••••••" value={pass} onChange={e=>setPass(e.target.value)} onKeyDown={e=>e.key==="Enter"&&submit()}/>
        <button style={{...S.btn, background:"linear-gradient(135deg,#00c98a,#00ffb3)", color:"#002810"}} onClick={submit}>
          {tab==="login" ? "🚀 Login to estrading.machine" : "✨ Create Account"}
        </button>
        <div style={{textAlign:"center",marginTop:16,fontSize:11,color:"#334155"}}>
          Demo: admin@estrading.machine / EstradingV10Admin!2026
        </div>
        <div style={{marginTop:16,padding:"12px",background:"rgba(99,102,241,.06)",borderRadius:10,fontSize:10,color:"#334155",lineHeight:1.7}}>
          🔒 AES-256 encrypted · JWT auth · Rate limited · RLS protected
        </div>
      </div>
    </div>
  );
}
