/**
 * Bots.jsx — ESTRADE v8 GODMODE — All 39 Bots + Deriv Indices
 * Deriv Synthetic Indices locked behind ✅ ALLOW button for compliance
 */
import { useState, useEffect, useCallback } from "react";
import { api, supabase, subscribeBots } from "../utils/supabase.js";

// ── Profit options ──────────────────────────────────────────
const PROFIT_OPTS = [2,3,4,5,6,7,8,10,12,15];
const PROFIT_CFG = {
  2:{c:"#22c55e",b:"SAFE"},3:{c:"#4ade80",b:"MOD"},4:{c:"#a3e635",b:"BAL"},
  5:{c:"#facc15",b:"ACT"},6:{c:"#fb923c",b:"GROW"},7:{c:"#f97316",b:"HIGH"},
  8:{c:"#ef4444",b:"BOLD"},10:{c:"#dc2626",b:"AGG"},12:{c:"#b91c1c",b:"ULTRA"},
  15:{c:"#7f1d1d",b:"MAX"},
};

// ── Deriv Synthetic Indices ────────────────────────────────
const DERIV_INDICES = [
  { id:"V10_1S",  name:"Volatility 10 (1s)",  desc:"Low vol, 24/7, 1s candles" },
  { id:"V25_1S",  name:"Volatility 25 (1s)",  desc:"Medium vol, 24/7" },
  { id:"V50_1S",  name:"Volatility 50 (1s)",  desc:"Balanced vol, 24/7" },
  { id:"V75_1S",  name:"Volatility 75 (1s)",  desc:"High vol, best for scalping" },
  { id:"V100_1S", name:"Volatility 100 (1s)", desc:"Ultra-high vol, max profits" },
  { id:"BOOM500",  name:"Boom 500",            desc:"Spike up every 500 ticks" },
  { id:"BOOM1000", name:"Boom 1000",           desc:"Spike up every 1000 ticks" },
  { id:"CRASH500", name:"Crash 500",           desc:"Spike down every 500 ticks" },
  { id:"CRASH1000",name:"Crash 1000",          desc:"Spike down every 1000 ticks" },
  { id:"RRANGE100",name:"Range Break 100",     desc:"Breakout-based index" },
  { id:"RRANGE200",name:"Range Break 200",     desc:"Wide range breakout" },
  { id:"JD10",    name:"Jump 10",              desc:"Random jump 10% intensity" },
  { id:"JD25",    name:"Jump 25",              desc:"Random jump 25% intensity" },
  { id:"JD50",    name:"Jump 50",              desc:"Random jump 50% intensity" },
  { id:"JD75",    name:"Jump 75",              desc:"Random jump 75% intensity" },
  { id:"JD100",   name:"Jump 100",             desc:"Random jump 100% intensity" },
  { id:"STPFALL",  name:"Step Index",          desc:"Step-wise movements, v low spread" },
];

// ── Category metadata ──────────────────────────────────────
const CATS = {
  hybrid:       { label:"Hybrid",       icon:"🌐", color:"#22c55e" },
  high_profit:  { label:"High Profit",  icon:"💰", color:"#f59e0b" },
  medium:       { label:"Medium",       icon:"⚡", color:"#f97316" },
  crypto_scalp: { label:"AI Scalp",    icon:"🔥", color:"#6366f1" },
  forex:        { label:"Forex",        icon:"📈", color:"#3b82f6" },
  commodities:  { label:"Gold/Silver",  icon:"🥇", color:"#f59e0b" },
  forex_hybrid: { label:"FX Hybrid",   icon:"🔷", color:"#60a5fa" },
  capital_max:  { label:"Capital Max",  icon:"🚀", color:"#f97316" },
  deriv:        { label:"Deriv Index",  icon:"📊", color:"#a855f7" },
};

// ── Bot Card ────────────────────────────────────────────────
function BotCard({ bot, onStart, onStop, onToggle2Pct, onSetRange, onUpgrade }) {
  const [exp, setExp]           = useState(false);
  const [profitT, setProfitT]   = useState(bot.profit_range_target || 5);
  const [profitM, setProfitM]   = useState(bot.profit_range_mode || "per_session");
  const [busy, setBusy]         = useState(false);
  const isRunning = bot.status === "running";
  const cfg       = PROFIT_CFG[profitT] || PROFIT_CFG[5];
  const pnlPos    = (bot.daily_pnl_pct || 0) >= 0;

  const act = async (fn) => { setBusy(true); try { await fn(); } finally { setBusy(false); } };

  return (
    <div style={{
      background:"#0a1628", border:`1px solid ${isRunning ? "#22c55e44" : "#1e293b"}`,
      borderRadius:14, overflow:"hidden",
      boxShadow: isRunning ? "0 0 16px #22c55e22" : "none",
      transition:"all 0.2s",
    }}>
      {/* Header */}
      <div style={{ padding:"14px 16px", display:"flex", alignItems:"flex-start", gap:10 }}>
        <span style={{ fontSize:28, lineHeight:1 }}>{bot.icon || "🤖"}</span>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:"flex", alignItems:"center", gap:6, flexWrap:"wrap" }}>
            <span style={{ fontWeight:800, fontSize:14, color:"#f1f5f9" }}>{bot.name}</span>
            {bot.ribbon && (
              <span style={{ background:"#ef4444", color:"#fff", fontSize:9, fontWeight:800,
                             padding:"2px 6px", borderRadius:4 }}>{bot.ribbon}</span>
            )}
            {bot.badge && (
              <span style={{ background:"#1e3a5f", color:"#60a5fa", fontSize:9,
                             padding:"2px 6px", borderRadius:4, fontWeight:700 }}>{bot.badge}</span>
            )}
          </div>
          <div style={{ fontSize:11, color:"#475569", marginTop:2 }}>{bot.description || ""}</div>

          {/* Stats row */}
          <div style={{ display:"flex", gap:12, marginTop:8, flexWrap:"wrap" }}>
            <div style={{ display:"flex", alignItems:"center", gap:4 }}>
              <span style={{ width:8, height:8, borderRadius:"50%",
                             background: isRunning ? "#22c55e" : "#475569",
                             animation: isRunning ? "pulse-live 2s infinite" : "none",
                             display:"inline-block" }}/>
              <span style={{ fontSize:11, color: isRunning ? "#22c55e" : "#475569",
                             fontWeight:700 }}>
                {isRunning ? "RUNNING" : "STOPPED"}
              </span>
            </div>
            <span style={{ fontSize:11, color: pnlPos ? "#22c55e" : "#ef4444" }}>
              {pnlPos?"+":""}{(bot.daily_pnl_pct||0).toFixed(2)}% today
            </span>
            <span style={{ fontSize:11, color:"#64748b" }}>
              {bot.total_trades||0} trades · {bot.win_trades||0}W
            </span>
            <span style={{ fontSize:11, color:"#64748b" }}>
              ${(bot.allocated_capital||0).toLocaleString()}
            </span>
          </div>

          {/* Progress bar */}
          {isRunning && profitT > 0 && (
            <div style={{ marginTop:8 }}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:3 }}>
                <span style={{ fontSize:10, color:"#64748b" }}>Session progress</span>
                <span style={{ fontSize:10, color:cfg.c, fontWeight:700 }}>
                  {Math.min(100, ((bot.daily_pnl_pct||0)/profitT*100)).toFixed(0)}% of {profitT}%
                </span>
              </div>
              <div style={{ height:4, background:"#1e293b", borderRadius:4, overflow:"hidden" }}>
                <div style={{
                  height:"100%", width:`${Math.min(100,((bot.daily_pnl_pct||0)/profitT*100))}%`,
                  background:cfg.c, borderRadius:4, transition:"width 0.5s",
                }}/>
              </div>
            </div>
          )}
        </div>

        {/* Control buttons */}
        <div style={{ display:"flex", flexDirection:"column", gap:6, flexShrink:0 }}>
          {isRunning ? (
            <button className="btn btn-danger" style={{ padding:"6px 12px", fontSize:12 }}
              onClick={() => act(() => onStop(bot.id))} disabled={busy}>
              {busy ? "⏳" : "⏹ Stop"}
            </button>
          ) : (
            <button className="btn btn-success" style={{ padding:"6px 12px", fontSize:12 }}
              onClick={() => act(() => onStart(bot.id))} disabled={busy}>
              {busy ? "⏳" : "▶ Start"}
            </button>
          )}
          <button className="btn btn-ghost" style={{ padding:"5px 12px", fontSize:11 }}
            onClick={() => setExp(!exp)}>
            {exp ? "▲ Less" : "▼ More"}
          </button>
        </div>
      </div>

      {/* Expanded controls */}
      {exp && (
        <div style={{ padding:"0 16px 16px", borderTop:"1px solid #1e293b" }}>

          {/* Profit Range */}
          <div style={{ marginTop:12 }}>
            <div style={{ fontSize:11, color:"#94a3b8", fontWeight:700, marginBottom:6 }}>
              🎯 PROFIT TARGET
            </div>
            <div style={{ display:"flex", flexWrap:"wrap", gap:4, marginBottom:8 }}>
              {PROFIT_OPTS.map(t => (
                <button key={t}
                  onClick={() => { setProfitT(t); onSetRange(bot.id, t, profitM); }}
                  style={{
                    padding:"4px 8px", borderRadius:6, fontSize:11, fontWeight:700,
                    border:`1.5px solid ${profitT===t ? PROFIT_CFG[t].c : "#1e293b"}`,
                    background: profitT===t ? `${PROFIT_CFG[t].c}20` : "transparent",
                    color: profitT===t ? PROFIT_CFG[t].c : "#475569",
                    cursor:"pointer",
                  }}>
                  {t}%
                </button>
              ))}
            </div>
            <div style={{ display:"flex", gap:6 }}>
              {["per_trade","per_session"].map(m => (
                <button key={m}
                  onClick={() => { setProfitM(m); onSetRange(bot.id, profitT, m); }}
                  style={{
                    flex:1, padding:"5px 0", borderRadius:7, fontSize:11, fontWeight:700,
                    border:`1.5px solid ${profitM===m ? "#6366f1" : "#1e293b"}`,
                    background: profitM===m ? "#6366f133" : "transparent",
                    color: profitM===m ? "#818cf8" : "#475569",
                    cursor:"pointer",
                  }}>
                  {m === "per_trade" ? "Per Trade" : "Per Session"}
                </button>
              ))}
            </div>
          </div>

          {/* 2% Pro Mode */}
          <div style={{ marginTop:10, display:"flex", alignItems:"center", justifyContent:"space-between",
                       background:"#0f172a", borderRadius:8, padding:"8px 12px" }}>
            <div>
              <div style={{ fontSize:12, color:"#e2e8f0", fontWeight:700 }}>⚡ 2% Pro Mode</div>
              <div style={{ fontSize:10, color:"#475569" }}>Lock target at 2%, max safety</div>
            </div>
            <button
              onClick={() => onToggle2Pct(bot.id, !bot.two_pct_mode)}
              style={{
                width:42, height:24, borderRadius:12, cursor:"pointer", border:"none",
                background: bot.two_pct_mode ? "#22c55e" : "#1e293b",
                position:"relative", transition:"background 0.2s",
              }}>
              <span style={{
                width:18, height:18, borderRadius:"50%", background:"#fff",
                position:"absolute", top:3,
                left: bot.two_pct_mode ? 21 : 3,
                transition:"left 0.2s",
              }}/>
            </button>
          </div>

          {/* AI Tier */}
          <div style={{ marginTop:10 }}>
            <div style={{ fontSize:11, color:"#64748b", marginBottom:6 }}>🧠 AI Tier</div>
            <div style={{ display:"flex", gap:6 }}>
              {["silver","gold","platinum"].map(tier => (
                <button key={tier}
                  onClick={() => onUpgrade(bot.id, tier)}
                  style={{
                    flex:1, padding:"5px 0", borderRadius:7, fontSize:11, fontWeight:700,
                    cursor:"pointer", border:"none",
                    background: bot.ai_tier === tier
                      ? tier==="platinum" ? "linear-gradient(135deg,#7c3aed,#6366f1)"
                        : tier==="gold" ? "linear-gradient(135deg,#d97706,#f59e0b)"
                        : "linear-gradient(135deg,#374151,#6b7280)"
                      : "#0f172a",
                    color: bot.ai_tier === tier ? "#fff" : "#475569",
                  }}>
                  {tier === "silver" ? "🥈" : tier === "gold" ? "🥇" : "💎"} {tier}
                </button>
              ))}
            </div>
          </div>

          {/* Pairs */}
          {bot.pairs_default?.length > 0 && (
            <div style={{ marginTop:10, display:"flex", flexWrap:"wrap", gap:4 }}>
              {bot.pairs_default.map(p => (
                <span key={p} style={{ fontSize:10, padding:"2px 6px", background:"#0f172a",
                                       border:"1px solid #1e293b", borderRadius:4, color:"#64748b" }}>
                  {p}
                </span>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Deriv Permission Gate ───────────────────────────────────
function DerivPermissionGate({ allowed, onAllow, onRevoke }) {
  return (
    <div style={{
      background: allowed ? "#052e1644" : "#1a0d2e",
      border: `1px solid ${allowed ? "#22c55e44" : "#7c3aed44"}`,
      borderRadius:14, padding:20, marginBottom:20,
    }}>
      <div style={{ display:"flex", alignItems:"center", gap:12, flexWrap:"wrap" }}>
        <span style={{ fontSize:28 }}>📊</span>
        <div style={{ flex:1 }}>
          <div style={{ fontWeight:800, fontSize:15, color:"#f1f5f9" }}>
            Deriv Synthetic Indices
          </div>
          <div style={{ fontSize:12, color:"#64748b", marginTop:3 }}>
            24/7 synthetic markets — Volatility Indices, Boom/Crash, Jump, Step, Range Break
          </div>
          <div style={{ fontSize:11, color: allowed ? "#22c55e" : "#a78bfa", marginTop:4, fontWeight:600 }}>
            {allowed
              ? "✅ Enabled — Deriv bots are active and trading"
              : "⚠️ Requires Deriv API token — click ALLOW to activate"
            }
          </div>
        </div>
        {allowed ? (
          <button className="btn btn-danger" style={{ fontSize:12 }} onClick={onRevoke}>
            🔒 Revoke Access
          </button>
        ) : (
          <button
            onClick={onAllow}
            style={{
              padding:"10px 20px", borderRadius:10, fontWeight:800, fontSize:14,
              background:"linear-gradient(135deg,#7c3aed,#6366f1)",
              color:"#fff", border:"none", cursor:"pointer",
              boxShadow:"0 0 20px #7c3aed44", animation:"glow-pulse 2s infinite",
            }}>
            ✅ ALLOW DERIV ACCESS
          </button>
        )}
      </div>

      {allowed && (
        <div style={{ marginTop:14, display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))", gap:8 }}>
          {DERIV_INDICES.map(idx => (
            <div key={idx.id} style={{
              background:"#0f172a", border:"1px solid #7c3aed33", borderRadius:10, padding:"8px 12px",
            }}>
              <div style={{ fontSize:12, fontWeight:700, color:"#c4b5fd" }}>{idx.name}</div>
              <div style={{ fontSize:10, color:"#475569", marginTop:2 }}>{idx.desc}</div>
            </div>
          ))}
        </div>
      )}

      {!allowed && (
        <div style={{ marginTop:12, padding:12, background:"#0f172a", borderRadius:10,
                     border:"1px solid #7c3aed22" }}>
          <div style={{ fontSize:11, color:"#64748b", lineHeight:1.7 }}>
            <strong style={{ color:"#a78bfa" }}>⚠️ Risk Disclosure:</strong> Deriv Synthetic Indices are simulated markets
            available 24/7. They carry the same risks as real markets. By clicking ALLOW, you confirm
            you understand the risks and have a valid Deriv API token configured in Settings.
          </div>
        </div>
      )}
    </div>
  );
}

// ── Main Bots Page ──────────────────────────────────────────
export default function Bots() {
  const [bots,       setBots]       = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [derivAllowed, setDerivAllowed] = useState(() =>
    localStorage.getItem("estrade_deriv_allowed") === "1"
  );
  const [search,     setSearch]     = useState("");
  const [catFilter,  setCatFilter]  = useState("all");
  const [statusFilt, setStatusFilt] = useState("all");
  const [showDeriv,  setShowDeriv]  = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api.get("/bots");
      setBots(r.bots || []);
    } catch(e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const ch = subscribeBots(() => load());
    return () => supabase.removeChannel(ch);
  }, [load]);

  const handleAllowDeriv = () => {
    localStorage.setItem("estrade_deriv_allowed","1");
    setDerivAllowed(true);
  };
  const handleRevokeDeriv = () => {
    localStorage.removeItem("estrade_deriv_allowed");
    setDerivAllowed(false);
  };

  const filtered = bots.filter(b => {
    if (search && !b.name?.toLowerCase().includes(search.toLowerCase())) return false;
    if (catFilter !== "all" && b.category !== catFilter) return false;
    if (statusFilt === "running" && b.status !== "running") return false;
    if (statusFilt === "stopped" && b.status !== "stopped") return false;
    if (!derivAllowed && b.category === "deriv") return false;
    return true;
  });

  const running = bots.filter(b => b.status === "running").length;

  return (
    <div style={{ padding:24, maxWidth:1600 }}>
      {/* Header */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20, flexWrap:"wrap", gap:12 }}>
        <div>
          <h1 style={{ fontSize:24, fontWeight:900, color:"#f1f5f9" }}>
            🤖 All Bots
          </h1>
          <p style={{ fontSize:13, color:"#475569", marginTop:4 }}>
            {running} running · {bots.length} total · 39 available
          </p>
        </div>
        <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
          <input className="input" placeholder="🔍 Search bots..."
            value={search} onChange={e=>setSearch(e.target.value)}
            style={{ width:180 }}/>
          <select className="select" value={catFilter} onChange={e=>setCatFilter(e.target.value)} style={{ width:140 }}>
            <option value="all">All Categories</option>
            {Object.entries(CATS).map(([k,v])=>(
              <option key={k} value={k}>{v.icon} {v.label}</option>
            ))}
          </select>
          <select className="select" value={statusFilt} onChange={e=>setStatusFilt(e.target.value)} style={{ width:120 }}>
            <option value="all">All Status</option>
            <option value="running">Running</option>
            <option value="stopped">Stopped</option>
          </select>
          <button className="btn btn-primary" onClick={() => setShowDeriv(!showDeriv)}>
            📊 Deriv {derivAllowed ? "✅" : "🔒"}
          </button>
        </div>
      </div>

      {/* Stats bar */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))", gap:12, marginBottom:20 }}>
        {[
          { label:"Running Bots", v:running, color:"#22c55e", icon:"▶" },
          { label:"Total Bots",   v:bots.length, color:"#6366f1", icon:"🤖" },
          { label:"Win Rate",     v:`${bots.length?Math.round(bots.reduce((a,b)=>(b.win_trades||0)+a,0)/Math.max(bots.reduce((a,b)=>(b.total_trades||0)+a,0),1)*100):0}%`, color:"#f59e0b", icon:"🏆" },
          { label:"Capital",      v:`$${bots.reduce((a,b)=>a+(b.allocated_capital||0),0).toLocaleString()}`, color:"#3b82f6", icon:"💰" },
        ].map(s => (
          <div key={s.label} className="card" style={{ textAlign:"center" }}>
            <div style={{ fontSize:20 }}>{s.icon}</div>
            <div style={{ fontSize:20, fontWeight:900, color:s.color, marginTop:4 }}>{s.v}</div>
            <div style={{ fontSize:11, color:"#475569" }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Deriv Gate */}
      {(showDeriv || derivAllowed) && (
        <DerivPermissionGate
          allowed={derivAllowed}
          onAllow={handleAllowDeriv}
          onRevoke={handleRevokeDeriv}
        />
      )}

      {/* Bot grid by category */}
      {loading ? (
        <div style={{ textAlign:"center", padding:60, color:"#475569" }}>
          <div className="spin" style={{ fontSize:32, display:"inline-block" }}>⚙️</div>
          <p style={{ marginTop:12 }}>Loading bots...</p>
        </div>
      ) : (
        Object.entries(CATS).map(([cat, catMeta]) => {
          const catBots = filtered.filter(b => b.category === cat);
          if (!catBots.length) return null;
          return (
            <div key={cat} style={{ marginBottom:28 }}>
              <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:12 }}>
                <span style={{ fontSize:20 }}>{catMeta.icon}</span>
                <h2 style={{ fontSize:16, fontWeight:800, color:catMeta.color }}>{catMeta.label}</h2>
                <span style={{ fontSize:12, color:"#475569" }}>({catBots.length} bots)</span>
                {cat === "deriv" && !derivAllowed && (
                  <span style={{ background:"#7c3aed22", color:"#a78bfa", fontSize:10,
                                 padding:"2px 8px", borderRadius:6, fontWeight:700 }}>
                    🔒 Click ALLOW DERIV ACCESS above
                  </span>
                )}
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(340px,1fr))", gap:12 }}>
                {catBots.map(bot => (
                  <BotCard
                    key={bot.id}
                    bot={bot}
                    onStart={(id) => api.post(`/bots/${id}/start`,{}).then(load)}
                    onStop={(id)  => api.post(`/bots/${id}/stop`,{}).then(load)}
                    onToggle2Pct={(id,en) => api.post(`/bots/${id}/two-pct-mode`,{enable:en}).then(load)}
                    onSetRange={(id,t,m)  => api.post(`/bots/${id}/profit-range`,{target_pct:t,mode:m}).then(load)}
                    onUpgrade={(id,tier)  => api.post(`/bots/${id}/upgrade-ai`,{tier}).then(load)}
                  />
                ))}
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}
