import{useState,useEffect}from"react";import{api}from"../utils/supabase.js";
const MODES=[
  {id:0,icon:"⏸",label:"OFF",color:"#475569",desc:"Fixed size. No reinvestment. Safe."},
  {id:1,icon:"🛡️",label:"Conservative 25%",color:"#22c55e",desc:"Reinvest 25% of profits. Slow steady growth."},
  {id:2,icon:"⚖️",label:"Moderate 50%",color:"#3b82f6",desc:"Reinvest 50% of profits. Balanced growth."},
  {id:3,icon:"🚀",label:"Aggressive 75%",color:"#f59e0b",desc:"Reinvest 75% of profits. Fast compounding."},
  {id:4,icon:"💰",label:"FULL 100%",color:"#f97316",desc:"Reinvest 100% of profits. Maximum growth."},
  {id:5,icon:"📐",label:"Geometric Kelly",color:"#8b5cf6",desc:"Kelly Criterion optimal sizing. Mathematical max."},
  {id:6,icon:"🔥",label:"Win Streak",color:"#ef4444",desc:"Scales up with win streaks. 1× to 2× on 5 wins."},
  {id:7,icon:"🧠",label:"AI Smart",color:"#a78bfa",desc:"AI decides rate based on win rate & drawdown."},
];
const COMPOUND=[
  {days:7,label:"1 Week"},{days:30,label:"1 Month"},{days:90,label:"3 Months"},{days:365,label:"1 Year"},
];
export default function Reinvest(){
const[selMode,setSelMode]=useState(4);const[balance,setBalance]=useState(10000);const[dailyPct,setDailyPct]=useState(5);const[proj,setProj]=useState({});const[stats,setStats]=useState({});
useEffect(()=>{calcProjections();},[selMode,balance,dailyPct]);
const calcProjections=()=>{
  const rate=MODES[selMode]?.id===0?0:selMode<=4?[0,0.25,0.5,0.75,1.0][selMode]:0.5;
  const results={};
  COMPOUND.forEach(({days,label})=>{
    let bal=balance;
    for(let d=0;d<days;d++){const profit=bal*(dailyPct/100);bal+=profit*rate;}
    results[label]={final:Math.round(bal),profit:Math.round(bal-balance),growth:((bal-balance)/balance*100).toFixed(1)};
  });
  setProj(results);
};
const applyToAll=async()=>{
  try{
    await api.post(`/reinvest/global`,{mode:selMode});
    alert(`✅ Mode "${MODES[selMode].label}" applied to all active bots!`);
  }catch(e){alert("Saved locally — connect API for live update");}
};
const S={card:{background:"var(--bg3,#0a1628)",border:"1px solid var(--border2,#1a3052)",borderRadius:14,padding:18},lbl:{fontSize:10,fontWeight:700,color:"var(--text3,#475569)",display:"block",marginBottom:4,textTransform:"uppercase",letterSpacing:".06em"},inp:{background:"var(--bg4,#0f1f3a)",border:"1px solid var(--border2,#1a3052)",borderRadius:9,padding:"8px 12px",color:"var(--text,#f0f4ff)",fontSize:13,fontFamily:"inherit",outline:"none"}};
return(
<div style={{padding:24,maxWidth:1400,fontFamily:"var(--font,'IBM Plex Sans',sans-serif)"}}>
<div style={{marginBottom:20}}>
  <div style={{fontSize:22,fontWeight:900,color:"var(--text,#f0f4ff)",fontFamily:"var(--display,'Space Grotesk',sans-serif)"}}>💰 Reinvestment Engine</div>
  <div style={{fontSize:12,color:"var(--text3,#475569)",marginTop:4}}>8 compounding modes · Capital maximization · Annual/Monthly/Weekly/Daily growth</div>
</div>

{/* Mode selector */}
<div style={S.card} className="mb-14">
  <div style={{fontWeight:700,fontSize:13,marginBottom:14,color:"var(--text,#f0f4ff)"}}>🔄 Select Reinvestment Mode</div>
  <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))",gap:10,marginBottom:14}}>
    {MODES.map(m=>(
      <div key={m.id} onClick={()=>setSelMode(m.id)} style={{padding:14,borderRadius:12,border:`2px solid ${selMode===m.id?m.color:"var(--border2,#1a3052)"}`,background:selMode===m.id?m.color+"15":"var(--bg4,#0f1f3a)",cursor:"pointer",transition:"all .15s"}}>
        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:6}}>
          <span style={{fontSize:20}}>{m.icon}</span>
          <span style={{fontWeight:800,fontSize:13,color:selMode===m.id?m.color:"var(--text,#f0f4ff)"}}>{m.label}</span>
        </div>
        <div style={{fontSize:11,color:"var(--text3,#475569)",lineHeight:1.4}}>{m.desc}</div>
        {selMode===m.id&&<div style={{marginTop:6,fontSize:10,fontWeight:700,color:m.color}}>✓ SELECTED</div>}
      </div>
    ))}
  </div>
  <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"flex-end"}}>
    <div><label style={S.lbl}>Starting Balance ($)</label><input type="number" style={{...S.inp,width:140}} value={balance} onChange={e=>setBalance(+e.target.value)}/></div>
    <div><label style={S.lbl}>Daily Profit Target (%)</label><input type="range" min="0.5" max="20" step="0.5" value={dailyPct} style={{width:160,accentColor:"var(--primary,#7c3aed)"}} onChange={e=>setDailyPct(+e.target.value)}/><div style={{fontSize:12,fontWeight:700,color:"#f59e0b",textAlign:"center"}}>{dailyPct}% / day</div></div>
    <button onClick={applyToAll} style={{padding:"10px 20px",borderRadius:10,border:"none",cursor:"pointer",fontWeight:800,fontSize:13,background:`linear-gradient(135deg,${MODES[selMode].color},${MODES[selMode].color}cc)`,color:"#fff",fontFamily:"inherit"}}>
      Apply to All Bots
    </button>
  </div>
</div>

{/* Projections */}
<div style={{...S.card,marginBottom:14}}>
  <div style={{fontWeight:700,fontSize:13,marginBottom:14,color:"var(--text,#f0f4ff)"}}>📈 Growth Projections — {MODES[selMode].label}</div>
  <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:10}}>
    {COMPOUND.map(({label})=>{
      const p=proj[label]||{};
      const growth=parseFloat(p.growth||0);
      return(
        <div key={label} style={{background:"var(--bg4,#0f1f3a)",borderRadius:12,padding:14,textAlign:"center",border:`1px solid ${growth>50?"rgba(0,255,179,.3)":growth>20?"rgba(245,158,11,.3)":"var(--border2,#1a3052)"}`}}>
          <div style={{fontSize:11,color:"var(--text3,#475569)",marginBottom:6}}>{label}</div>
          <div style={{fontSize:22,fontWeight:900,color:growth>50?"#00ffb3":growth>20?"#f59e0b":"var(--text,#f0f4ff)",fontFamily:"monospace"}}>${(p.final||balance).toLocaleString()}</div>
          <div style={{fontSize:12,fontWeight:700,color:"#00ffb3",marginTop:3}}>+${(p.profit||0).toLocaleString()}</div>
          <div style={{fontSize:11,color:"var(--text3,#475569)",marginTop:2}}>+{p.growth||0}% growth</div>
        </div>
      );
    })}
  </div>
  <div style={{marginTop:12,padding:12,background:"rgba(124,58,237,.08)",borderRadius:10,fontSize:12,color:"var(--text3,#475569)",lineHeight:1.7}}>
    <strong style={{color:"#8b5cf6"}}>📊 Compound Math at {dailyPct}% daily + {MODES[selMode].label}:</strong><br/>
    Formula: Balance × (1 + {dailyPct}% × reinvest_rate)^days<br/>
    Safety: Max 3× starting size · Drawdown &gt;10% → auto reduce size 50% · 3 losses → pause reinvestment<br/>
    <strong style={{color:"#f59e0b"}}>⚠️ Note: Projections are mathematical — real results vary with market conditions</strong>
  </div>
</div>

{/* Compound comparison */}
<div style={S.card}>
  <div style={{fontWeight:700,fontSize:13,marginBottom:14,color:"var(--text,#f0f4ff)"}}>⚖️ Mode Comparison at ${balance.toLocaleString()} — {dailyPct}% daily — 30 Days</div>
  <div style={{overflowX:"auto"}}>
    <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
      <thead><tr style={{borderBottom:"1px solid var(--border2,#1a3052)"}}>
        {["Mode","Rate","30-Day Balance","30-Day Profit","Growth %","Best For"].map(h=>(
          <th key={h} style={{padding:"8px 10px",textAlign:"left",color:"var(--text3,#475569)",fontSize:10,fontWeight:700,textTransform:"uppercase"}}>{h}</th>
        ))}
      </tr></thead>
      <tbody>{MODES.map(m=>{
        const rate=[0,0.25,0.5,0.75,1.0,0.5,0.65,0.5][m.id];
        let bal=balance;
        for(let d=0;d<30;d++) bal+=bal*(dailyPct/100)*rate;
        const profit=Math.round(bal-balance);
        const growth=((bal-balance)/balance*100).toFixed(1);
        const isSelected=m.id===selMode;
        return(
          <tr key={m.id} style={{borderBottom:"1px solid var(--bg4,#0f1f3a)",background:isSelected?m.color+"10":"transparent",cursor:"pointer"}} onClick={()=>setSelMode(m.id)}>
            <td style={{padding:"8px 10px",fontWeight:700,color:isSelected?m.color:"var(--text,#f0f4ff)"}}>{m.icon} {m.label}</td>
            <td style={{padding:"8px 10px",fontFamily:"monospace",color:m.color}}>{(rate*100).toFixed(0)}%</td>
            <td style={{padding:"8px 10px",fontFamily:"monospace",fontWeight:700,color:"var(--text,#f0f4ff)"}}>${Math.round(bal).toLocaleString()}</td>
            <td style={{padding:"8px 10px",fontFamily:"monospace",color:"#00ffb3"}}>${profit.toLocaleString()}</td>
            <td style={{padding:"8px 10px",fontFamily:"monospace",color:parseFloat(growth)>100?"#00ffb3":parseFloat(growth)>50?"#f59e0b":"var(--text2,#94a3b8)"}}>{growth}%</td>
            <td style={{padding:"8px 10px",fontSize:10,color:"var(--text3,#475569)"}}>{["Stable income","Beginners","Most traders","Experienced","Max growth","Mathematicians","Streak traders","Conservative"][m.id]}</td>
          </tr>
        );
      })}</tbody>
    </table>
  </div>
</div>
</div>);
}
