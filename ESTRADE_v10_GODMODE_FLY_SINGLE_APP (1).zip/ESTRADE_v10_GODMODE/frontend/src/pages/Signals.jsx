import{useState,useEffect}from"react";import{api}from"../utils/supabase.js";
const DIR_COLOR={BUY:"#00ffb3",SELL:"#ff3b5c",NEUTRAL:"#475569"};
const EMO_ICON={panic:"💀",euphoria:"🚀",fear:"😱",greed:"😈",optimism:"😊",neutral:"😐",anxiety:"😰"};
export default function Signals(){
const[signals,setSignals]=useState([]);const[active,setActive]=useState(null);const[loading,setLoading]=useState(false);const[cfg,setCfg]=useState({symbol:"BTCUSDT",timeframe:"5m",bot_key:"hybrid_alpha"});const[deliv,setDeliv]=useState({});const[accuracy,setAccuracy]=useState({});
const load=async()=>{try{const[s,a]=await Promise.all([api.get("/signals/history?limit=50"),api.get("/signals/accuracy")]);setSignals(s.signals||[]);setAccuracy(a||{});}catch(e){}};
useEffect(()=>{load();const iv=setInterval(load,10000);return()=>clearInterval(iv);},[]);
const generate=async()=>{setLoading(true);try{const r=await api.post("/signals/generate",cfg);if(r.signal){setActive(r.signal);setSignals(p=>[r.signal,...p.slice(0,49)]);}else alert("Signal below threshold — waiting for better setup");}catch(e){alert(e.message);}setLoading(false);};
const saveDelivery=async()=>{try{await api.post("/signals/configure-delivery",{...deliv,user_id:"me"});alert("✅ Delivery configured!");}catch(e){alert(e.message);}};
const S={card:{background:"var(--bg3,#0a1628)",border:"1px solid var(--border2,#1a3052)",borderRadius:14,padding:18},label:{fontSize:10,fontWeight:700,color:"var(--text3,#475569)",display:"block",marginBottom:4,textTransform:"uppercase",letterSpacing:".06em"},inp:{width:"100%",background:"var(--bg4,#0f1f3a)",border:"1px solid var(--border2,#1a3052)",borderRadius:9,padding:"8px 12px",color:"var(--text,#f0f4ff)",fontSize:13,fontFamily:"inherit",outline:"none",marginBottom:8}};
return(
<div style={{padding:24,maxWidth:1400}}>
<div style={{marginBottom:20}}>
  <div style={{fontSize:22,fontWeight:900,color:"var(--text,#f0f4ff)",fontFamily:"var(--display,'Space Grotesk',sans-serif)"}}>📡 Signal Engine</div>
  <div style={{fontSize:12,color:"var(--text3,#475569)",marginTop:4}}>Manual trading signals · 9 AI engines · Telegram · MT4/5 · TradingView</div>
</div>

{/* Stats */}
<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(130px,1fr))",gap:10,marginBottom:16}}>
  {[["Accuracy",`${(accuracy.tp2_rate||0).toFixed(1)}%`,"#00ffb3"],["Total Signals",accuracy.total||0,"#8b5cf6"],["TP2 Hit Rate",`${(accuracy.tp2_rate||0).toFixed(1)}%`,"#06b6d4"],["Avg R:R",`${(accuracy.avg_rr||0).toFixed(2)}:1`,"#f59e0b"]].map(([l,v,c])=>(
    <div key={l} style={{...S.card,textAlign:"center"}}>
      <div style={{fontSize:20,fontWeight:900,color:c,fontFamily:"monospace"}}>{v}</div>
      <div style={{fontSize:10,color:"var(--text3,#475569)",marginTop:3}}>{l}</div>
    </div>
  ))}
</div>

<div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,marginBottom:14}}>
  {/* Generate */}
  <div style={S.card}>
    <div style={{fontWeight:700,fontSize:13,marginBottom:12,color:"var(--text,#f0f4ff)"}}>🎯 Generate Signal</div>
    <label style={S.label}>Symbol</label>
    <select style={S.inp} value={cfg.symbol} onChange={e=>setCfg(c=>({...c,symbol:e.target.value}))}>
      {["BTCUSDT","ETHUSDT","SOLUSDT","XAUUSD","EURUSD","GBPUSD","BNBUSDT","XRPUSDT"].map(s=><option key={s}>{s}</option>)}
    </select>
    <label style={S.label}>Timeframe</label>
    <select style={S.inp} value={cfg.timeframe} onChange={e=>setCfg(c=>({...c,timeframe:e.target.value}))}>
      {["1m","3m","5m","15m","30m","1h","4h","1d"].map(t=><option key={t}>{t}</option>)}
    </select>
    <label style={S.label}>Bot Strategy</label>
    <select style={S.inp} value={cfg.bot_key} onChange={e=>setCfg(c=>({...c,bot_key:e.target.value}))}>
      {["hybrid_alpha","ai_fusion","bear_crusher_pro","volatility_assassin","quantum_arb_x","gold_master","promax_scalping"].map(b=><option key={b}>{b}</option>)}
    </select>
    <button onClick={generate} disabled={loading} style={{width:"100%",padding:"10px",borderRadius:10,border:"none",cursor:"pointer",fontWeight:800,fontSize:14,background:"linear-gradient(135deg,#00c98a,#00ffb3)",color:"#002810",fontFamily:"inherit",opacity:loading?.6:1}}>
      {loading?"⏳ Analyzing market...":"🚀 Generate Signal"}
    </button>
  </div>

  {/* Active Signal */}
  <div style={S.card}>
    <div style={{fontWeight:700,fontSize:13,marginBottom:12,color:"var(--text,#f0f4ff)"}}>📊 Active Signal</div>
    {active?(
      <>
        <div style={{textAlign:"center",padding:"12px 0"}}>
          <div style={{fontSize:36,marginBottom:6}}>{active.direction==="BUY"?"⬆":"⬇"}</div>
          <div style={{fontSize:22,fontWeight:900,color:DIR_COLOR[active.direction]}}>{active.direction} {active.symbol}</div>
          <div style={{fontSize:12,color:"var(--text3,#475569)",marginTop:4}}>
            Conf: <strong style={{color:"#00ffb3"}}>{active.confidence?.toFixed(1)}%</strong> · 
            Engines: <strong style={{color:"#8b5cf6"}}>{active.engines_agree}/9</strong> · 
            {EMO_ICON[active.emotion]} {active.emotion?.toUpperCase()}
          </div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6,marginBottom:10}}>
          {[["Entry",active.entry_price,"var(--text,#f0f4ff)"],["Stop Loss",active.stop_loss,"#ff3b5c"],["TP2",active.take_profit_2,"#00ffb3"]].map(([l,v,c])=>(
            <div key={l} style={{background:"var(--bg4,#0f1f3a)",borderRadius:8,padding:"8px",textAlign:"center"}}>
              <div style={{fontSize:9,color:"var(--text3,#475569)"}}>{l}</div>
              <div style={{fontFamily:"monospace",fontWeight:700,color:c,fontSize:11}}>{typeof v==="number"?v.toFixed(v>100?2:6):"-"}</div>
            </div>
          ))}
        </div>
        <div style={{background:"var(--bg4,#0f1f3a)",borderRadius:8,padding:10,fontSize:11,color:"var(--text3,#475569)",lineHeight:1.7}}>
          <strong style={{color:"var(--text2,#94a3b8)"}}>📋 Manual Steps:</strong><br/>
          1. Open {active.symbol} on your broker<br/>
          2. Place {active.direction} at {active.entry_price?.toFixed?.(active.entry_price>100?2:6)}<br/>
          3. SL: {active.stop_loss?.toFixed?.(active.stop_loss>100?2:6)} ({active.sl_pct?.toFixed(2)}%)<br/>
          4. TP2: {active.take_profit_2?.toFixed?.(active.take_profit_2>100?2:6)} · R:R {active.rr_ratio?.toFixed(1)}:1<br/>
          5. Risk 1-2% of account
        </div>
      </>
    ):(
      <div style={{textAlign:"center",padding:"40px 0",color:"var(--text3,#475569)"}}>
        <div style={{fontSize:36,marginBottom:8}}>📡</div>
        <div>Click Generate Signal to get AI analysis</div>
      </div>
    )}
  </div>
</div>

{/* Delivery Config */}
<div style={{...S.card,marginBottom:14}}>
  <div style={{fontWeight:700,fontSize:13,marginBottom:12,color:"var(--text,#f0f4ff)"}}>📤 Signal Delivery — Receive on Any Platform</div>
  <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:10}}>
    <div>
      <label style={S.label}>🤖 Telegram Bot Token</label>
      <input style={S.inp} placeholder="7123456789:AAF..." value={deliv.telegram_token||""} onChange={e=>setDeliv(d=>({...d,telegram_token:e.target.value}))}/>
      <label style={S.label}>Telegram Chat ID</label>
      <input style={S.inp} placeholder="-100123456789" value={deliv.telegram_chat_id||""} onChange={e=>setDeliv(d=>({...d,telegram_chat_id:e.target.value}))}/>
    </div>
    <div>
      <label style={S.label}>📺 TradingView Webhook URL</label>
      <input style={S.inp} placeholder="https://..." value={deliv.tv_webhook_url||""} onChange={e=>setDeliv(d=>({...d,tv_webhook_url:e.target.value}))}/>
      <label style={S.label}>🔗 Custom Webhook (3Commas/Cornix)</label>
      <input style={S.inp} placeholder="https://..." value={deliv.custom_webhook||""} onChange={e=>setDeliv(d=>({...d,custom_webhook:e.target.value}))}/>
    </div>
    <div>
      <label style={S.label}>📧 Email Alerts</label>
      <input style={S.inp} type="email" placeholder="you@email.com" value={deliv.email||""} onChange={e=>setDeliv(d=>({...d,email:e.target.value}))}/>
      <div style={{fontSize:10,color:"var(--text3,#475569)",marginBottom:8}}>Works with: MT4/MT5, cTrader, ZuluTrade, 3Commas, Pionex, Cornix, WunderTrading</div>
      <button onClick={saveDelivery} style={{width:"100%",padding:"8px",borderRadius:9,border:"none",cursor:"pointer",fontWeight:700,background:"linear-gradient(135deg,#4f46e5,#7c3aed)",color:"#fff",fontFamily:"inherit"}}>💾 Save Delivery Config</button>
    </div>
  </div>
</div>

{/* Formats */}
{active&&(
  <div style={{...S.card,marginBottom:14}}>
    <div style={{fontWeight:700,fontSize:13,marginBottom:12,color:"var(--text,#f0f4ff)"}}>📋 Platform Formats — Copy & Paste</div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
      {[["🤖 Telegram",active.telegram_msg],["📊 MT4/MT5",active.mt4_comment],["📺 TradingView",active.tv_alert],["🔗 Cornix",active.cornix_fmt]].map(([title,content])=>(
        <div key={title} style={{background:"var(--bg4,#0f1f3a)",borderRadius:10,padding:10}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
            <span style={{fontSize:11,fontWeight:700,color:"var(--text2,#94a3b8)"}}>{title}</span>
            <button onClick={()=>{navigator.clipboard.writeText(content||"");}} style={{fontSize:10,background:"none",border:"1px solid var(--border2,#1a3052)",borderRadius:5,cursor:"pointer",color:"var(--text3,#475569)",padding:"2px 7px"}}>Copy</button>
          </div>
          <pre style={{fontSize:9,color:"var(--text3,#475569)",overflow:"auto",maxHeight:80,whiteSpace:"pre-wrap",margin:0}}>{(content||"").slice(0,300)}</pre>
        </div>
      ))}
    </div>
  </div>
)}

{/* History */}
<div style={S.card}>
  <div style={{fontWeight:700,fontSize:13,marginBottom:12,color:"var(--text,#f0f4ff)"}}>📜 Signal History</div>
  <div style={{overflowX:"auto"}}>
    <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
      <thead><tr style={{borderBottom:"1px solid var(--border2,#1a3052)"}}>
        {["Time","Symbol","Dir","Entry","SL","TP2","Conf","R:R","Status","Emotion"].map(h=>(
          <th key={h} style={{padding:"6px 8px",textAlign:"left",color:"var(--text3,#475569)",fontSize:10,fontWeight:700,textTransform:"uppercase"}}>{h}</th>
        ))}
      </tr></thead>
      <tbody>{signals.slice(0,20).map((s,i)=>(
        <tr key={i} style={{borderBottom:"1px solid var(--bg4,#0f1f3a)"}}>
          <td style={{padding:"6px 8px",color:"var(--text3,#475569)",fontSize:10}}>{s.created_at?new Date(s.created_at).toLocaleTimeString():"--:--"}</td>
          <td style={{padding:"6px 8px",fontWeight:700,color:"var(--text,#f0f4ff)"}}>{s.symbol}</td>
          <td style={{padding:"6px 8px",fontWeight:700,color:DIR_COLOR[s.direction]||"#475569"}}>{s.direction}</td>
          <td style={{padding:"6px 8px",fontFamily:"monospace",fontSize:10}}>{s.entry_price?.toFixed?.(2)||"-"}</td>
          <td style={{padding:"6px 8px",fontFamily:"monospace",fontSize:10,color:"#ff3b5c"}}>{s.stop_loss?.toFixed?.(2)||"-"}</td>
          <td style={{padding:"6px 8px",fontFamily:"monospace",fontSize:10,color:"#00ffb3"}}>{s.take_profit_2?.toFixed?.(2)||"-"}</td>
          <td style={{padding:"6px 8px",color:"#06b6d4"}}>{s.confidence?.toFixed?.(1)||"-"}%</td>
          <td style={{padding:"6px 8px",color:"#f59e0b"}}>{s.rr_ratio?.toFixed?.(1)||"-"}:1</td>
          <td style={{padding:"6px 8px"}}>
            <span style={{padding:"2px 6px",borderRadius:4,fontSize:9,fontWeight:700,background:s.status==="active"?"rgba(0,255,179,.15)":s.status?.includes("tp")?"rgba(0,255,179,.15)":"rgba(255,59,92,.15)",color:s.status==="active"?"#00ffb3":s.status?.includes("tp")?"#00ffb3":"#ff3b5c"}}>
              {s.status||"active"}
            </span>
          </td>
          <td style={{padding:"6px 8px"}}>{EMO_ICON[s.emotion]||"📊"}</td>
        </tr>
      ))}</tbody>
    </table>
  </div>
</div>
</div>);
}
