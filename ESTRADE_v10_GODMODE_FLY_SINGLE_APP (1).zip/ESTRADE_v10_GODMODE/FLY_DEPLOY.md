# Single-App Fly.io Deployment (v10 GODMODE)

This replaces the split deployment (Vercel frontend + Render/Fly API + Railway
worker + external Redis) with **one Fly.io app, one image, four process
groups**, all deployed with a single `fly deploy`.

## What changed

| Old way | New way |
|---|---|
| `frontend/` → Vercel | Built into the image, served by FastAPI at `/` |
| `backend/` → Render/Fly | Process group `app` |
| `workers/` → Railway (Procfile) | Process groups `worker` + `beat` |
| External Redis | Process group `redis` (self-hosted, internal-only) |
| `backend/requirements.txt` + `workers/requirements.txt` | Merged into root `requirements.txt` |

Root-level files added: `Dockerfile`, `fly.toml`, `.dockerignore`, `deploy-fly.sh`.
`backend/main.py` now also serves the built frontend (static assets + SPA
fallback) so a single FastAPI process answers both `/api/*` and the React app.

The old `backend/Dockerfile` / `backend/fly.toml` still exist (renamed to
`*.standalone-api-only`) if you ever want to go back to API-only on Fly with
the frontend hosted elsewhere.

## One-time setup

```bash
curl -L https://fly.io/install.sh | sh   # install flyctl
fly auth login
```

## Deploy

```bash
bash deploy-fly.sh
```

This creates the app from `fly.toml` (if it doesn't exist yet), prompts for
secrets (Supabase, Stripe, Telegram, Sentry), and runs `fly deploy`, which
builds the one Docker image and starts all four process groups.

Manual equivalent:

```bash
fly launch --no-deploy --copy-config --name estrading-machine-v10
fly secrets set SUPABASE_URL=... SUPABASE_SERVICE_KEY=... SECRET_KEY=$(openssl rand -hex 32)
fly deploy
```

## Process groups

- **app** — FastAPI: `/api/*` + the built React frontend. Has the public
  `[http_service]`, auto-stops/starts with traffic.
- **worker** — `celery worker` consuming the trading/notifications/webhooks/
  payments/scheduler queues.
- **beat** — `celery beat`, the scheduler (bot scans every 30s, daily
  summaries, fee collection, etc.).
- **redis** — self-hosted broker/cache, reachable only over Fly's private
  6PN network at `redis.process.<app-name>.internal:6379`. Not exposed
  publicly.

`worker`, `beat`, and `redis` have no `[http_service]`, so they run
continuously rather than auto-stopping.

## Useful commands

```bash
fly status                                   # all process groups + machine states
fly logs                                     # tail logs (all groups)
fly logs --process-group worker              # just the worker
fly scale count 2 --process-group worker     # scale a single group
fly ssh console --process-group app          # shell into a machine
```

## Swapping in managed Redis later

If you outgrow the self-hosted `redis` process group (e.g. need HA/persistence
guarantees), provision Upstash via `fly redis create`, then just point
`REDIS_URL` at it with `fly secrets set REDIS_URL=...` and remove the `redis`
entry from `[processes]` / `[[vm]]` in `fly.toml`. Nothing else changes.
