"""
ai/candle_analysis.py — estrading.machine v10 GODMODE
══════════════════════════════════════════════════════════════════════════
CANDLE ANALYSIS ENGINE — pure price-action / candlestick pattern recognition.

Detects classic single-, two-, and three-candle patterns and turns them into
a -1..+1 bias score + confidence, the same shape as the other AI engines
(see ai/indicator_engine.py's LayeredAIEngine / AIDecision for the pattern
this mirrors).

Patterns covered:
  Single-candle : Doji, Hammer, Inverted Hammer, Hanging Man, Shooting Star,
                   Marubozu (bull/bear), Spinning Top
  Two-candle    : Bullish/Bearish Engulfing, Piercing Line, Dark Cloud Cover,
                   Bullish/Bearish Harami, Tweezer Top/Bottom
  Three-candle  : Morning Star, Evening Star,
                   Three White Soldiers, Three Black Crows

Trend context (SMA20 vs SMA50 slope) disambiguates shape-only patterns that
mean different things in different contexts — a Hammer shape at the bottom
of a downtrend is bullish; the *same shape* at the top of an uptrend is a
Hanging Man (bearish). Same for Inverted Hammer vs Shooting Star.

This engine is ADDITIVE: it does not change any other engine's weighting or
master_brain_v10's live decision logic. Wire its `composite_score` /
`bias` into your own consensus weighting deliberately, on your own schedule.

Input flexibility — `analyze()` accepts any of:
  • pandas.DataFrame with columns open/high/low/close[/volume]   (indicator_engine style)
  • list[dict] with keys open/high/low/close[/volume]            (master_brain_v10 style)
  • list[list] CCXT OHLCV rows [ts, open, high, low, close, vol]  (broker_service.get_ohlcv style)
══════════════════════════════════════════════════════════════════════════
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Union, Dict, Any

EPS = 1e-9

# ═══════════════════════════════════════════════════════════════
# INPUT ADAPTER — accept DataFrame / list[dict] / CCXT list[list]
# ═══════════════════════════════════════════════════════════════

def _to_df(candles: Union[pd.DataFrame, List[dict], List[list]]) -> pd.DataFrame:
    if isinstance(candles, pd.DataFrame):
        df = candles.copy()
    elif isinstance(candles, list) and candles and isinstance(candles[0], (list, tuple)):
        # CCXT-style [timestamp, open, high, low, close, volume]
        df = pd.DataFrame(candles, columns=["ts", "open", "high", "low", "close", "volume"])
    else:
        df = pd.DataFrame(candles or [])
    df.columns = [str(c).lower() for c in df.columns]
    for col in ("open", "high", "low", "close"):
        if col not in df.columns:
            raise ValueError(f"candle_analysis: missing required column '{col}'")
        df[col] = pd.to_numeric(df[col], errors="coerce")
    if "volume" not in df.columns:
        df["volume"] = 0.0
    return df.reset_index(drop=True)


# ═══════════════════════════════════════════════════════════════
# SHARED CANDLE GEOMETRY (vectorized over the whole frame)
# ═══════════════════════════════════════════════════════════════

def _geometry(df: pd.DataFrame) -> pd.DataFrame:
    g = pd.DataFrame(index=df.index)
    g["open"], g["high"], g["low"], g["close"] = df["open"], df["high"], df["low"], df["close"]
    g["body"] = (df["close"] - df["open"]).abs()
    g["rng"] = (df["high"] - df["low"]).clip(lower=EPS)
    g["upper_wick"] = df["high"] - df[["open", "close"]].max(axis=1)
    g["lower_wick"] = df[["open", "close"]].min(axis=1) - df["low"]
    g["body_pct"] = g["body"] / g["rng"]
    g["upper_pct"] = g["upper_wick"] / g["rng"]
    g["lower_pct"] = g["lower_wick"] / g["rng"]
    g["bullish"] = df["close"] > df["open"]
    g["bearish"] = df["close"] < df["open"]
    g["mid_body"] = (df["open"] + df["close"]) / 2
    return g


def _trend_context(df: pd.DataFrame, i: int) -> str:
    """Cheap trend read using SMA20 vs SMA50 at bar i. Used only to
    disambiguate shape-only patterns (hammer vs hanging man, etc.)."""
    closes = df["close"]
    if i < 20:
        return "sideways"
    sma20 = closes.iloc[max(0, i - 19): i + 1].mean()
    sma50 = closes.iloc[max(0, i - 49): i + 1].mean()
    if sma20 > sma50 * 1.001:
        return "uptrend"
    if sma20 < sma50 * 0.999:
        return "downtrend"
    return "sideways"


# ═══════════════════════════════════════════════════════════════
# OUTPUT SHAPES
# ═══════════════════════════════════════════════════════════════

@dataclass
class CandlePattern:
    name: str
    type: str           # bullish_reversal | bearish_reversal | continuation | indecision
    bars_ago: int        # 0 = pattern completes on the most recent closed candle
    strength: float       # 0-100, how textbook-clean the pattern is


@dataclass
class CandleDecision:
    bias: str                 # BUY | SELL | WAIT
    confidence: float          # 0-100
    composite_score: float      # -1..+1
    patterns: List[CandlePattern]
    dominant_pattern: Optional[str]
    candle_color: str           # bullish | bearish | neutral (latest candle)
    body_pct: float
    upper_wick_pct: float
    lower_wick_pct: float
    range_expansion: float        # latest range vs avg(last 14) range
    trend_context: str
    reasoning: str

    def to_dict(self) -> dict:
        d = asdict(self)
        d["patterns"] = [asdict(p) for p in self.patterns]
        return d


_PATTERN_WEIGHT = {
    # name -> (signed strength multiplier, type)
    "bullish_engulfing":   (+1.0, "bullish_reversal"),
    "bearish_engulfing":   (-1.0, "bearish_reversal"),
    "morning_star":        (+1.1, "bullish_reversal"),
    "evening_star":        (-1.1, "bearish_reversal"),
    "three_white_soldiers": (+1.2, "continuation"),
    "three_black_crows":   (-1.2, "continuation"),
    "piercing_line":       (+0.8, "bullish_reversal"),
    "dark_cloud_cover":    (-0.8, "bearish_reversal"),
    "hammer":              (+0.7, "bullish_reversal"),
    "inverted_hammer":     (+0.5, "bullish_reversal"),
    "hanging_man":         (-0.6, "bearish_reversal"),
    "shooting_star":       (-0.7, "bearish_reversal"),
    "bullish_harami":      (+0.5, "bullish_reversal"),
    "bearish_harami":      (-0.5, "bearish_reversal"),
    "tweezer_bottom":      (+0.6, "bullish_reversal"),
    "tweezer_top":         (-0.6, "bearish_reversal"),
    "bullish_marubozu":    (+0.6, "continuation"),
    "bearish_marubozu":    (-0.6, "continuation"),
    "doji":                (0.0, "indecision"),
    "spinning_top":        (0.0, "indecision"),
}


# ═══════════════════════════════════════════════════════════════
# ENGINE
# ═══════════════════════════════════════════════════════════════

class CandleAnalysisEngine:
    """
    Pure price-action candlestick pattern engine.
    `.analyze(candles)` -> CandleDecision for the most recently CLOSED candle.
    `.quick_score(candles)` -> slim dict, same convention as other engines.
    """

    DOJI_BODY_MAX = 0.10
    MARUBOZU_BODY_MIN = 0.90
    SPINNING_TOP_BODY_MAX = 0.30
    ENGULF_MIN_BODY_PCT = 0.40
    TWEEZER_TOLERANCE = 0.0015       # 0.15% — highs/lows considered "equal"

    def analyze(self, candles: Union[pd.DataFrame, List[dict], List[list]],
                lookback: int = 3) -> CandleDecision:
        df = _to_df(candles)
        if len(df) < 3:
            return self._empty("need at least 3 candles")

        g = _geometry(df)
        n = len(df)
        last = n - 1

        found: List[CandlePattern] = []
        # Scan backwards from the last closed candle so the freshest
        # pattern naturally has bars_ago == 0.
        for bars_ago in range(0, min(lookback, n - 2)):
            i = last - bars_ago
            if i < 2:
                break
            trend = _trend_context(df, i)
            found.extend(self._single_candle(g, i, trend, bars_ago))
            found.extend(self._two_candle(g, i, trend, bars_ago))
            found.extend(self._three_candle(g, i, trend, bars_ago))

        return self._decide(df, g, last, found)

    def quick_score(self, candles) -> dict:
        d = self.analyze(candles)
        return {"bias": d.bias, "confidence": d.confidence,
                "score": d.composite_score, "pattern": d.dominant_pattern}

    # ── Single-candle patterns at index i ─────────────────────
    def _single_candle(self, g: pd.DataFrame, i: int, trend: str, bars_ago: int) -> List[CandlePattern]:
        out = []
        body_pct = g["body_pct"].iat[i]
        up, lo = g["upper_pct"].iat[i], g["lower_pct"].iat[i]
        bullish = g["bullish"].iat[i]

        if body_pct <= self.DOJI_BODY_MAX:
            out.append(CandlePattern("doji", "indecision", bars_ago,
                                      round((1 - body_pct / self.DOJI_BODY_MAX) * 100, 1)))

        if body_pct >= self.MARUBOZU_BODY_MIN:
            name = "bullish_marubozu" if bullish else "bearish_marubozu"
            ptype = _PATTERN_WEIGHT[name][1]
            out.append(CandlePattern(name, ptype, bars_ago, round(body_pct * 100, 1)))

        if body_pct <= self.SPINNING_TOP_BODY_MAX and up > 0.2 and lo > 0.2 and abs(up - lo) < 0.2:
            out.append(CandlePattern("spinning_top", "indecision", bars_ago,
                                      round((1 - abs(up - lo)) * 60, 1)))

        body = g["body"].iat[i]
        lower_wick, upper_wick = g["lower_wick"].iat[i], g["upper_wick"].iat[i]
        # Range-relative (not body-relative): a hammer's body can be tiny,
        # so "opposite wick <= 30% of body" degenerates for small bodies.
        is_hammer_shape = (lo >= 0.55 and up <= 0.15 and body_pct <= 0.35)
        is_star_shape = (up >= 0.55 and lo <= 0.15 and body_pct <= 0.35)

        if is_hammer_shape:
            if trend == "downtrend":
                out.append(CandlePattern("hammer", "bullish_reversal", bars_ago,
                                          round(min(lower_wick / max(body, EPS), 5) * 18, 1)))
            elif trend == "uptrend":
                out.append(CandlePattern("hanging_man", "bearish_reversal", bars_ago,
                                          round(min(lower_wick / max(body, EPS), 5) * 18, 1)))

        if is_star_shape:
            if trend == "downtrend":
                out.append(CandlePattern("inverted_hammer", "bullish_reversal", bars_ago,
                                          round(min(upper_wick / max(body, EPS), 5) * 16, 1)))
            elif trend == "uptrend":
                out.append(CandlePattern("shooting_star", "bearish_reversal", bars_ago,
                                          round(min(upper_wick / max(body, EPS), 5) * 18, 1)))
        return out

    # ── Two-candle patterns ending at index i ─────────────────
    def _two_candle(self, g: pd.DataFrame, i: int, trend: str, bars_ago: int) -> List[CandlePattern]:
        if i < 1:
            return []
        out = []
        p, c = i - 1, i  # previous, current
        prev_bear, prev_bull = g["bearish"].iat[p], g["bullish"].iat[p]
        cur_bear, cur_bull = g["bearish"].iat[c], g["bullish"].iat[c]
        po, pc_ = g["open"].iat[p], g["close"].iat[p]
        co, cc = g["open"].iat[c], g["close"].iat[c]
        cur_body_pct, prev_body_pct = g["body_pct"].iat[c], g["body_pct"].iat[p]

        # Engulfing
        if prev_bear and cur_bull and co <= pc_ and cc >= po and cur_body_pct > self.ENGULF_MIN_BODY_PCT:
            strength = round(min((cc - co) / max(abs(pc_ - po), EPS), 3) * 30, 1)
            out.append(CandlePattern("bullish_engulfing", "bullish_reversal", bars_ago, strength))
        if prev_bull and cur_bear and co >= pc_ and cc <= po and cur_body_pct > self.ENGULF_MIN_BODY_PCT:
            strength = round(min((co - cc) / max(abs(po - pc_), EPS), 3) * 30, 1)
            out.append(CandlePattern("bearish_engulfing", "bearish_reversal", bars_ago, strength))

        # Harami (current body fully inside previous body, opposite/smaller)
        if prev_bear and cur_bull and co > pc_ and cc < po and cur_body_pct < prev_body_pct:
            out.append(CandlePattern("bullish_harami", "bullish_reversal", bars_ago,
                                      round((1 - cur_body_pct / max(prev_body_pct, EPS)) * 60, 1)))
        if prev_bull and cur_bear and co < pc_ and cc > po and cur_body_pct < prev_body_pct:
            out.append(CandlePattern("bearish_harami", "bearish_reversal", bars_ago,
                                      round((1 - cur_body_pct / max(prev_body_pct, EPS)) * 60, 1)))

        # Piercing Line / Dark Cloud Cover (gap + close past prev midpoint)
        prev_mid = g["mid_body"].iat[p]
        if prev_bear and cur_bull and co < g["low"].iat[p] and prev_mid < cc < po:
            out.append(CandlePattern("piercing_line", "bullish_reversal", bars_ago,
                                      round((cc - prev_mid) / max(po - prev_mid, EPS) * 70, 1)))
        if prev_bull and cur_bear and co > g["high"].iat[p] and po < cc < prev_mid:
            out.append(CandlePattern("dark_cloud_cover", "bearish_reversal", bars_ago,
                                      round((prev_mid - cc) / max(prev_mid - po, EPS) * 70, 1)))

        # Tweezer top/bottom (near-equal extremes, opposite colors)
        if abs(g["low"].iat[p] - g["low"].iat[c]) <= self.TWEEZER_TOLERANCE * max(g["low"].iat[c], EPS) \
                and prev_bear and cur_bull:
            out.append(CandlePattern("tweezer_bottom", "bullish_reversal", bars_ago, 55.0))
        if abs(g["high"].iat[p] - g["high"].iat[c]) <= self.TWEEZER_TOLERANCE * max(g["high"].iat[c], EPS) \
                and prev_bull and cur_bear:
            out.append(CandlePattern("tweezer_top", "bearish_reversal", bars_ago, 55.0))

        return out

    # ── Three-candle patterns ending at index i ───────────────
    def _three_candle(self, g: pd.DataFrame, i: int, trend: str, bars_ago: int) -> List[CandlePattern]:
        if i < 2:
            return []
        out = []
        a, b, c = i - 2, i - 1, i  # first, middle, last

        # Morning / Evening Star: long body, small-body middle (gapping), long opposite body closing past midpoint
        a_body_pct = g["body_pct"].iat[a]
        b_body_pct = g["body_pct"].iat[b]
        c_body_pct = g["body_pct"].iat[c]
        a_mid = g["mid_body"].iat[a]

        if (g["bearish"].iat[a] and a_body_pct > 0.5 and b_body_pct < 0.35
                and g["bullish"].iat[c] and c_body_pct > 0.5
                and g["close"].iat[c] > a_mid):
            out.append(CandlePattern("morning_star", "bullish_reversal", bars_ago,
                                      round(min(c_body_pct, 1) * 70, 1)))
        if (g["bullish"].iat[a] and a_body_pct > 0.5 and b_body_pct < 0.35
                and g["bearish"].iat[c] and c_body_pct > 0.5
                and g["close"].iat[c] < a_mid):
            out.append(CandlePattern("evening_star", "bearish_reversal", bars_ago,
                                      round(min(c_body_pct, 1) * 70, 1)))

        # Three White Soldiers / Three Black Crows
        closes = g["close"].iloc[a:c + 1].values
        opens = g["open"].iloc[a:c + 1].values
        bullish3 = bool(g["bullish"].iat[a] and g["bullish"].iat[b] and g["bullish"].iat[c])
        bearish3 = bool(g["bearish"].iat[a] and g["bearish"].iat[b] and g["bearish"].iat[c])

        if bullish3 and closes[1] > closes[0] and closes[2] > closes[1] \
                and opens[1] >= opens[0] and opens[2] >= opens[1] \
                and min(g["body_pct"].iloc[a:c + 1]) > 0.4:
            out.append(CandlePattern("three_white_soldiers", "continuation", bars_ago, 75.0))
        if bearish3 and closes[1] < closes[0] and closes[2] < closes[1] \
                and opens[1] <= opens[0] and opens[2] <= opens[1] \
                and min(g["body_pct"].iloc[a:c + 1]) > 0.4:
            out.append(CandlePattern("three_black_crows", "continuation", bars_ago, 75.0))

        return out

    # ── Aggregate findings into one decision ──────────────────
    def _decide(self, df: pd.DataFrame, g: pd.DataFrame, last: int,
                found: List[CandlePattern]) -> CandleDecision:
        ranges = g["rng"].iloc[max(0, last - 13): last + 1]
        avg_range = ranges.iloc[:-1].mean() if len(ranges) > 1 else g["rng"].iat[last]
        range_expansion = round(float(g["rng"].iat[last] / max(avg_range, EPS)), 2)

        score = 0.0
        dominant = None
        dominant_weighted = -1.0
        for p in found:
            mult, _ = _PATTERN_WEIGHT.get(p.name, (0.0, "indecision"))
            recency = max(0.2, 1 - 0.3 * p.bars_ago)  # fresher patterns count more
            score += mult * (p.strength / 100) * recency
            weighted = p.strength * recency
            if weighted > dominant_weighted and mult != 0:
                dominant_weighted = weighted
                dominant = p.name

        score = max(-1.0, min(1.0, score))
        confidence = round(min(99.0, abs(score) * 100 * (1.0 + 0.15 * min(len(found), 3))), 1)

        if score > 0.15:
            bias = "BUY"
        elif score < -0.15:
            bias = "SELL"
        else:
            bias = "WAIT"

        color = "bullish" if g["bullish"].iat[last] else ("bearish" if g["bearish"].iat[last] else "neutral")
        trend = _trend_context(df, last)
        names = ", ".join(sorted({p.name for p in found})) or "no significant pattern"
        reasoning = (f"[{bias} {confidence:.1f}%] score:{score:.3f} trend:{trend} "
                     f"range_expansion:{range_expansion}x patterns:[{names}]")

        return CandleDecision(
            bias=bias, confidence=confidence, composite_score=round(score, 4),
            patterns=found, dominant_pattern=dominant, candle_color=color,
            body_pct=round(float(g["body_pct"].iat[last]), 4),
            upper_wick_pct=round(float(g["upper_pct"].iat[last]), 4),
            lower_wick_pct=round(float(g["lower_pct"].iat[last]), 4),
            range_expansion=range_expansion, trend_context=trend, reasoning=reasoning,
        )

    def _empty(self, reason: str) -> CandleDecision:
        return CandleDecision(
            bias="WAIT", confidence=0, composite_score=0.0, patterns=[],
            dominant_pattern=None, candle_color="neutral", body_pct=0,
            upper_wick_pct=0, lower_wick_pct=0, range_expansion=1.0,
            trend_context="sideways", reasoning=reason,
        )


# ── Catalog (for API discovery / frontend tooltips) ───────────
PATTERN_CATALOG = [
    {"name": n, "type": t} for n, (_, t) in _PATTERN_WEIGHT.items()
]

# ── Singleton ───────────────────────────────────────────────
candle_ai = CandleAnalysisEngine()
