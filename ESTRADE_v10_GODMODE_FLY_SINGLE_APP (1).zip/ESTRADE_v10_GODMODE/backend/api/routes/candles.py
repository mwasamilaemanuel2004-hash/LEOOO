"""api/routes/candles.py — candlestick pattern analysis endpoints"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional

router = APIRouter()


class CandleIn(BaseModel):
    open: float
    high: float
    low: float
    close: float
    volume: Optional[float] = 0.0


class AnalyzeRequest(BaseModel):
    symbol: Optional[str] = None
    candles: List[CandleIn]
    lookback: Optional[int] = 3


@router.post("/candles/analyze")
async def analyze_candles(req: AnalyzeRequest):
    """
    Run the candlestick pattern engine over a list of OHLC(V) candles
    (oldest first, most recent last) and return bias/confidence + the
    specific patterns detected.
    """
    try:
        from ai.candle_analysis import candle_ai
        rows = [c.dict() for c in req.candles]
        decision = candle_ai.analyze(rows, lookback=req.lookback or 3)
        result = decision.to_dict()
        if req.symbol:
            result["symbol"] = req.symbol
        return result
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/candles/patterns")
async def list_patterns():
    """Catalog of supported candlestick patterns (for frontend tooltips/UI)."""
    try:
        from ai.candle_analysis import PATTERN_CATALOG
        return {"patterns": PATTERN_CATALOG, "count": len(PATTERN_CATALOG)}
    except Exception as e:
        raise HTTPException(500, str(e))
