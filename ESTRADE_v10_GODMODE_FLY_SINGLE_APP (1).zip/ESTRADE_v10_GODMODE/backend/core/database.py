"""core/database.py v10"""
from core.config import settings
import structlog
log = structlog.get_logger("database")

db = None
try:
    if settings.supabase_url and settings.supabase_key:
        from supabase import create_client
        db = create_client(settings.supabase_url, settings.supabase_key)
        log.info("✅ Supabase connected", url=settings.supabase_url[:30]+"...")
    else:
        log.warning("⚠ Supabase not configured — running in demo mode")
except Exception as e:
    log.error("Database connection failed", error=str(e))
