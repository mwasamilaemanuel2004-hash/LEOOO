"""core/security.py v10 — JWT, bcrypt, Fernet encryption"""
import jwt, time, os
from passlib.context import CryptContext
from cryptography.fernet import Fernet
from core.config import settings

pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
    return pwd_ctx.hash(password)

def verify_password(plain: str, hashed: str) -> bool:
    try: return pwd_ctx.verify(plain, hashed)
    except: return False

def create_token(data: dict, expires_in: int = 86400*7) -> str:
    payload = {**data, "exp": int(time.time()) + expires_in, "iat": int(time.time())}
    return jwt.encode(payload, settings.secret_key, algorithm="HS256")

def decode_token(token: str) -> dict:
    return jwt.decode(token, settings.secret_key, algorithms=["HS256"])

def encrypt_api_key(key: str) -> str:
    try:
        f = Fernet(settings.encryption_key.encode() if isinstance(settings.encryption_key, str) else settings.encryption_key)
        return f.encrypt(key.encode()).decode()
    except: return key

def decrypt_api_key(encrypted: str) -> str:
    try:
        f = Fernet(settings.encryption_key.encode() if isinstance(settings.encryption_key, str) else settings.encryption_key)
        return f.decrypt(encrypted.encode()).decode()
    except: return encrypted
