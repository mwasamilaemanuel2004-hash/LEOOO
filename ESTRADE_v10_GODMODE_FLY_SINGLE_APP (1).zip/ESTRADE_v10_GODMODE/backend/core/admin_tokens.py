"""Admin token generation for free/commission/discount access"""
import secrets, time, json
from pathlib import Path
from dataclasses import dataclass,asdict
from typing import Optional

TOKENS_FILE = Path("storage/admin_tokens.json")
TOKENS_FILE.parent.mkdir(parents=True,exist_ok=True)

@dataclass
class AdminToken:
    token: str
    type: str        # "free","commission","discount"
    discount_pct: float = 0.0
    commission_pct: float = 0.0
    max_uses: int = 1
    uses: int = 0
    created_by: str = ""
    created_at: float = 0.0
    expires_at: float = 0.0
    is_active: bool = True
    notes: str = ""

class AdminTokenManager:
    def __init__(self):
        self._tokens: dict = {}
        self._load()

    def create(self,type_:str,created_by:str,discount_pct:float=0,
               commission_pct:float=0,max_uses:int=1,
               expires_days:int=30,notes:str="") -> AdminToken:
        token = f"EST-{type_.upper()[:3]}-{secrets.token_hex(8).upper()}"
        t = AdminToken(
            token=token, type=type_, discount_pct=discount_pct,
            commission_pct=commission_pct, max_uses=max_uses,
            created_by=created_by, created_at=time.time(),
            expires_at=time.time()+expires_days*86400, notes=notes
        )
        self._tokens[token] = t
        self._save()
        return t

    def validate(self,token:str) -> Optional[dict]:
        t = self._tokens.get(token)
        if not t or not t.is_active: return None
        if t.expires_at < time.time(): return None
        if t.uses >= t.max_uses: return None
        return {"valid":True,"type":t.type,"discount_pct":t.discount_pct,
                "commission_pct":t.commission_pct,"remaining_uses":t.max_uses-t.uses}

    def use(self,token:str) -> bool:
        t = self._tokens.get(token)
        if not t: return False
        t.uses += 1
        if t.uses >= t.max_uses: t.is_active = False
        self._save()
        return True

    def list_tokens(self) -> list:
        return [asdict(t) for t in self._tokens.values()]

    def revoke(self,token:str):
        if token in self._tokens:
            self._tokens[token].is_active = False
            self._save()

    def _save(self):
        TOKENS_FILE.write_text(json.dumps({k:asdict(v) for k,v in self._tokens.items()},indent=2))

    def _load(self):
        try:
            if TOKENS_FILE.exists():
                data = json.loads(TOKENS_FILE.read_text())
                self._tokens = {k:AdminToken(**v) for k,v in data.items()}
        except: pass

admin_token_manager = AdminTokenManager()
