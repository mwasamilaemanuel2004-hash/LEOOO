# ⚡ estrading.machine — v8 GODMODE AI Trading System

> **The most advanced self-evolving AI trading bot system ever built.**
> Reinforcement Learning + Genetic Algorithms + Real-Time Streaming + Live Trading

---

## 🌐 Live Links

| Service | URL | Status |
|---------|-----|--------|
| 🌐 **Website** | https://estrading-machine.vercel.app | Vercel (Free) |
| 🔧 **Backend API** | https://estrading-machine-api.fly.dev | Fly.io (Free) |
| 📊 **API Docs** | https://estrading-machine-api.fly.dev/api/docs | FastAPI Swagger |
| 🗄️ **Database** | https://app.supabase.com | Supabase (Free) |
| ☁️ **CF Worker** | https://estrading-machine-proxy.workers.dev | Cloudflare (Free) |

---

## 🚀 Deploy in 5 Minutes (FREE)

```bash
git clone https://github.com/YOUR_USER/estrading-machine
cd estrading-machine
bash deploy.sh
```

### Manual Deployment

**Step 1 — Supabase Database (FREE)**
1. Create project at [supabase.com](https://supabase.com)
2. Go to SQL Editor → New Query
3. Paste contents of `database/v8_migration.sql` → Run
4. Save your `Project URL` and `service_role key`

**Step 2 — Backend on Fly.io (FREE)**
```bash
cd backend
cp .env.example .env   # Fill in your values
flyctl auth login
flyctl apps create estrading-machine-api
flyctl secrets set SUPABASE_URL=... SUPABASE_SERVICE_KEY=...
flyctl deploy
```

**Step 3 — Frontend on Vercel (FREE)**
```bash
cd frontend
cp .env.example .env.local   # Fill in your values
npm install
vercel --prod --name estrading-machine
```

**Step 4 — Cloudflare Worker (FREE)**
```bash
cd cloudflare
npm install -g wrangler
wrangler login
wrangler deploy
```

**Step 5 — GitHub Secrets for CI/CD**
Add these in repo Settings → Secrets → Actions:
```
FLY_API_TOKEN          # from: flyctl auth token
VERCEL_TOKEN           # from: vercel login
VERCEL_ORG_ID          # from: vercel whoami
VERCEL_PROJECT_ID      # from: vercel project ls
VITE_SUPABASE_URL      # your supabase URL
VITE_SUPABASE_ANON_KEY # your supabase anon key
VITE_API_URL           # https://estrading-machine-api.fly.dev/api
CLOUDFLARE_API_TOKEN   # from Cloudflare dashboard
```

---

## 🧠 AI System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    DECISION PIPELINE                        │
├─────────────────────────────────────────────────────────────┤
│  1. Market Data (WebSocket < 1ms)                           │
│     └─ Binance WS → Candle Builder → 72 Indicators         │
│                                                             │
│  2. Ultra Brain v7 (7-engine ensemble, ~8ms)                │
│     └─ SMC + RSI + EMA + Bollinger + MACD + Volume + AI    │
│                                                             │
│  3. RL Triple Brain (PPO + DQN + A3C, ~3ms)                │
│     ├─ PPO: Policy gradient, stable training                │
│     ├─ DQN: Q-learning, experience replay                   │
│     └─ A3C: Meta-controller, regime-aware blending          │
│                                                             │
│  4. Risk AI (Kelly + VaR + Drawdown Defense, ~1ms)          │
│     ├─ 5-Level drawdown defense (0-15%)                     │
│     ├─ Circuit breakers (6 types)                           │
│     └─ Portfolio heat map + VaR 95%/99%                     │
│                                                             │
│  5. Strategy Evolver (Genetic Algorithm, ~100ms/generation) │
│     ├─ Population: 50 strategy variants                     │
│     ├─ Hall of Fame: Top 10 all-time                        │
│     └─ Evolves every 1000 trades or 24h                     │
│                                                             │
│  6. Execution (Binance API / MT5, ~15ms)                    │
│     └─ Latency fallback: WS → REST → Cache                  │
└─────────────────────────────────────────────────────────────┘
```

---

## 🤖 39 Bots

| Category | Count | Exchanges |
|----------|-------|-----------|
| Hybrid | 8 | Binance + MT5 |
| High Profit | 6 | Binance |
| Crypto AI Scalp | 6 | Binance |
| Forex | 5 | MT5 |
| Gold & Silver | 4 | MT5 |
| Forex Hybrid | 4 | MT5 + Binance |
| Capital Max | 3 | Binance |
| Deriv Synthetic | 3 | Deriv (🔒 requires ALLOW) |

---

## 📊 Deriv Synthetic Indices

17 synthetic indices available — locked behind user permission gate:
- Volatility 10/25/50/75/100 (1s)
- Boom 500/1000 & Crash 500/1000
- Jump 10/25/50/75/100
- Range Break 100/200
- Step Index

> Click **✅ ALLOW DERIV ACCESS** in the Bots page to enable.

---

## 🛡️ Security Features

- AES-256 encrypted API keys (Fernet)
- Withdrawal permission disabled on all connections
- JWT authentication (7-day tokens)
- Row Level Security on all Supabase tables
- Cloudflare Worker CORS proxy
- Rate limiting: 100 req/min
- 5-level drawdown defense
- 6 circuit breakers
- Emergency stop all bots

---

## 📈 Profit Targets

| Target | Risk/Trade | Min Confidence | Min R:R |
|--------|-----------|----------------|---------|
| 2% | 0.44% | 68% | 1.5 |
| 5% | 1.10% | 72% | 1.8 |
| 10% | 2.30% | 76% | 2.2 |
| 15% | 4.50% | 80% | 2.5 |

---

## 🔑 Default Admin

```
Email:    admin@estrading.machine
Password: EstradingMachine2026!Change
⚠️ CHANGE THIS IMMEDIATELY AFTER FIRST LOGIN
```

---

## 📁 Project Structure

```
estrading-machine/
├── backend/                # Python FastAPI
│   ├── ai/
│   │   ├── ultra_brain.py          # 7-engine signal brain
│   │   ├── reinforcement_engine.py # PPO + DQN + A3C
│   │   ├── strategy_evolver.py     # Genetic algorithm
│   │   ├── risk_ai_engine.py       # Risk management AI
│   │   └── trading_loop_v8.py     # Master trading loop
│   ├── api/routes/         # All API endpoints
│   ├── services/           # Exchange, MT5, data streaming
│   ├── strategies/         # Trading strategies
│   ├── core/               # Config, DB, bot registry
│   ├── main.py             # FastAPI app entry
│   ├── requirements.txt
│   ├── Dockerfile
│   └── fly.toml            # Fly.io config
├── frontend/               # React + Vite + Tailwind
│   ├── src/
│   │   ├── pages/          # Dashboard, Bots, TradingPanel...
│   │   ├── utils/          # Supabase + API helpers
│   │   └── App.jsx         # Root with sidebar navigation
│   ├── vercel.json
│   └── package.json
├── database/
│   └── v8_migration.sql    # Complete Supabase schema
├── cloudflare/
│   ├── worker.js           # CORS proxy for exchanges
│   └── wrangler.toml
├── .github/workflows/
│   └── deploy.yml          # Auto-deploy CI/CD
├── deploy.sh               # One-command deploy
├── render.yaml             # Render.com alternative
└── README.md
```

---

## ⚡ Tech Stack

- **Frontend**: React 18 + Vite + Tailwind CSS → Vercel ($0)
- **Backend**: FastAPI + Python 3.11 → Fly.io ($0)
- **Database**: PostgreSQL + Realtime → Supabase ($0)
- **Worker**: JavaScript → Cloudflare Workers ($0)
- **CI/CD**: GitHub Actions ($0)
- **AI**: Pure NumPy neural networks (no PyTorch needed)
- **Exchange**: Binance WebSocket + REST, MT5 Bridge, Deriv WS

**Total monthly cost: $0** on free tiers
