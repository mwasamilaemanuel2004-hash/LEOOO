#!/bin/bash
# ═══════════════════════════════════════════════════════════════
# estrading.machine — ONE-COMMAND FULL DEPLOY
# ═══════════════════════════════════════════════════════════════
# Usage: bash deploy.sh
# Deploys: GitHub + Vercel + Fly.io + Cloudflare + Supabase
# ═══════════════════════════════════════════════════════════════

set -e
RED='\033[0;31m' GREEN='\033[0;32m' YELLOW='\033[1;33m' BLUE='\033[0;34m' NC='\033[0m'
log()  { echo -e "${GREEN}✅ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
info() { echo -e "${BLUE}ℹ️  $1${NC}"; }
err()  { echo -e "${RED}❌ $1${NC}"; exit 1; }

echo ""
echo -e "${BLUE}╔══════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   ⚡ estrading.machine DEPLOY v8          ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════╝${NC}"
echo ""

# ── CHECK REQUIRED TOOLS ─────────────────────────────────────
info "Checking required tools..."
command -v git     >/dev/null 2>&1 || err "git not found. Install: https://git-scm.com"
command -v node    >/dev/null 2>&1 || err "node not found. Install: https://nodejs.org"
command -v npm     >/dev/null 2>&1 || err "npm not found"
command -v gh      >/dev/null 2>&1 || warn "GitHub CLI (gh) not found — manual GitHub push required"
command -v flyctl  >/dev/null 2>&1 || warn "flyctl not found — install: curl -L https://fly.io/install.sh | sh"
command -v vercel  >/dev/null 2>&1 || warn "Vercel CLI not found — install: npm i -g vercel"

# ── COLLECT SECRETS ──────────────────────────────────────────
echo ""
info "Enter your credentials (press Enter to skip optional):"
echo ""

read -p "Supabase Project URL: " SUPABASE_URL
read -p "Supabase Service Key (secret): " SUPABASE_KEY
read -p "Supabase Anon Key (public): " SUPABASE_ANON
read -p "GitHub username: " GITHUB_USER
read -p "GitHub repo name [estrading-machine]: " GITHUB_REPO
GITHUB_REPO=${GITHUB_REPO:-estrading-machine}

echo ""
log "Configuration received"

# ── WRITE ENV FILES ───────────────────────────────────────────
info "Writing environment files..."

# Backend .env
cat > backend/.env << EOF
SUPABASE_URL=${SUPABASE_URL}
SUPABASE_SERVICE_KEY=${SUPABASE_KEY}
FRONTEND_URL=https://${GITHUB_REPO}.vercel.app
SECRET_KEY=$(openssl rand -hex 32)
ENCRYPTION_KEY=$(python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())" 2>/dev/null || echo "CHANGE_ME")
ENV=production
PORT=8000
EOF

# Frontend .env
cat > frontend/.env.local << EOF
VITE_SUPABASE_URL=${SUPABASE_URL}
VITE_SUPABASE_ANON_KEY=${SUPABASE_ANON}
VITE_API_URL=https://${GITHUB_REPO}-api.fly.dev/api
VITE_APP_NAME=estrading.machine
VITE_PLATFORM=both
EOF

log "Environment files created"

# ── GITHUB ─────────────────────────────────────────────────────
echo ""
info "Setting up GitHub repository..."
if ! git rev-parse --git-dir > /dev/null 2>&1; then
    git init
    git branch -M main
fi
git add -A
git commit -m "🚀 estrading.machine v8 GODMODE — Initial deploy" 2>/dev/null || git commit --allow-empty -m "🚀 Deploy"

if command -v gh >/dev/null 2>&1; then
    gh repo create ${GITHUB_REPO} --public --push --source=. 2>/dev/null && \
        log "GitHub repo created: https://github.com/${GITHUB_USER}/${GITHUB_REPO}" || \
        warn "Repo may already exist — pushing to origin"
    git remote set-url origin "https://github.com/${GITHUB_USER}/${GITHUB_REPO}.git" 2>/dev/null || \
        git remote add origin "https://github.com/${GITHUB_USER}/${GITHUB_REPO}.git"
    git push -u origin main --force
    log "Code pushed to GitHub"
else
    warn "Create GitHub repo manually at: https://github.com/new"
    warn "Name: ${GITHUB_REPO} | Then run: git remote add origin https://github.com/${GITHUB_USER}/${GITHUB_REPO}.git && git push -u origin main"
fi

# ── SUPABASE MIGRATION ────────────────────────────────────────
echo ""
info "Running Supabase migration..."
if command -v supabase >/dev/null 2>&1; then
    supabase db push --db-url "${SUPABASE_URL}" 2>/dev/null && log "Supabase migration applied" || \
        warn "Run migration manually: copy database/v8_migration.sql → Supabase SQL Editor → Run"
else
    warn "Supabase CLI not found."
    warn "Run migration manually: Supabase Dashboard → SQL Editor → paste database/v8_migration.sql → Run"
fi

# ── FLY.IO BACKEND ───────────────────────────────────────────
echo ""
info "Deploying backend to Fly.io..."
cd backend
if command -v flyctl >/dev/null 2>&1; then
    flyctl auth login 2>/dev/null || true
    flyctl apps create "${GITHUB_REPO}-api" 2>/dev/null || true
    flyctl secrets set \
        SUPABASE_URL="${SUPABASE_URL}" \
        SUPABASE_SERVICE_KEY="${SUPABASE_KEY}" \
        SECRET_KEY="$(openssl rand -hex 32)" \
        FRONTEND_URL="https://${GITHUB_REPO}.vercel.app" \
        ENV="production" 2>/dev/null || warn "Set secrets manually in Fly.io dashboard"
    flyctl deploy --remote-only && log "Backend deployed to: https://${GITHUB_REPO}-api.fly.dev" || \
        warn "Fly.io deploy failed — try: cd backend && flyctl deploy"
else
    warn "Install flyctl: curl -L https://fly.io/install.sh | sh"
    warn "Then: cd backend && flyctl deploy"
fi
cd ..

# ── VERCEL FRONTEND ───────────────────────────────────────────
echo ""
info "Deploying frontend to Vercel..."
cd frontend
npm install --silent
if command -v vercel >/dev/null 2>&1; then
    vercel --prod \
        --name "${GITHUB_REPO}" \
        --env VITE_SUPABASE_URL="${SUPABASE_URL}" \
        --env VITE_SUPABASE_ANON_KEY="${SUPABASE_ANON}" \
        --env VITE_API_URL="https://${GITHUB_REPO}-api.fly.dev/api" \
        --env VITE_APP_NAME="estrading.machine" \
        --yes 2>/dev/null && log "Frontend deployed!" || \
        warn "Run manually: cd frontend && vercel --prod"
else
    warn "Install Vercel CLI: npm i -g vercel"
    warn "Then: cd frontend && vercel --prod"
fi
cd ..

# ── CLOUDFLARE WORKER ────────────────────────────────────────
echo ""
info "Deploying Cloudflare Worker..."
cd cloudflare
if command -v wrangler >/dev/null 2>&1; then
    wrangler deploy 2>/dev/null && log "Cloudflare Worker deployed!" || \
        warn "Run manually: cd cloudflare && wrangler deploy"
else
    warn "Install: npm i -g wrangler | Then: cd cloudflare && wrangler deploy"
fi
cd ..

# ── SUMMARY ──────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   🎉 estrading.machine DEPLOYMENT COMPLETE!              ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║  🌐 Website:  https://${GITHUB_REPO}.vercel.app    ║${NC}"
echo -e "${GREEN}║  🔧 Backend:  https://${GITHUB_REPO}-api.fly.dev   ║${NC}"
echo -e "${GREEN}║  📦 GitHub:   https://github.com/${GITHUB_USER}/${GITHUB_REPO}  ║${NC}"
echo -e "${GREEN}║  🗄️  Supabase: ${SUPABASE_URL}  ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║  👤 Default admin: admin@estrading.machine               ║${NC}"
echo -e "${GREEN}║  🔑 Password:      EstradingMachine2026!Change           ║${NC}"
echo -e "${GREEN}║  ⚠️  CHANGE PASSWORD IMMEDIATELY AFTER FIRST LOGIN!       ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
