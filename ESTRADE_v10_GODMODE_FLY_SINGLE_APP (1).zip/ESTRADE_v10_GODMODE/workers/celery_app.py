"""
workers/celery_app.py — ESTRADE v6 Background Worker Queue
Handles: bot scans, notifications, webhook processing, daily summaries.
Deploy on: Railway (separate service from main API)
"""
from celery import Celery
import os

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
app = Celery("estrade_workers", broker=REDIS_URL, backend=REDIS_URL)
app.conf.update(
    task_serializer="json", result_serializer="json",
    accept_content=["json"], timezone="UTC", enable_utc=True,
    task_routes={
        "workers.tasks.scan_bot_pair":      {"queue": "trading"},
        "workers.tasks.send_notification":  {"queue": "notifications"},
        "workers.tasks.process_webhook":    {"queue": "webhooks"},
        "workers.tasks.daily_summary":      {"queue": "scheduler"},
        "workers.tasks.process_withdrawal": {"queue": "payments"},
    },
    beat_schedule={
        "bot-scan-every-30s":   {"task":"workers.tasks.run_all_bot_scans","schedule":30},
        "daily-summary-9am":    {"task":"workers.tasks.send_daily_summaries","schedule":86400},
        "cleanup-old-logs":     {"task":"workers.tasks.cleanup_old_logs","schedule":3600},
        "accrue-daily-sub":     {"task":"workers.tasks.accrue_daily_subscriptions","schedule":86400},
        "monthly-fee-collect":  {"task":"workers.tasks.collect_monthly_fees","schedule":2592000},
        "refresh-market-data":  {"task":"workers.tasks.refresh_market_cache","schedule":15},
        "auto-trade-bots":     {"task":"workers.tasks.auto_trade_all_bots","schedule":30},
        "manage-open-trades":  {"task":"workers.tasks.manage_open_trades","schedule":10},
        "check-auto-withdrawals":{"task":"workers.tasks.check_auto_withdrawals","schedule":300},
    }
)
