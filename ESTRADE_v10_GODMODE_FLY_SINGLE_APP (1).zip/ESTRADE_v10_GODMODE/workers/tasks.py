"""
workers/tasks.py — Celery Task Definitions
"""
from workers.celery_app import app
import asyncio, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

def run_async(coro):
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()

@app.task(name="workers.tasks.run_all_bot_scans", bind=True, max_retries=3)
def run_all_bot_scans(self):
    """Trigger full bot scan cycle — runs every 30s."""
    try:
        from ai.trading_loop import trading_loop
        run_async(trading_loop._run_full_scan())
        return {"status": "scanned"}
    except Exception as e:
        self.retry(exc=e, countdown=10)

@app.task(name="workers.tasks.scan_bot_pair", bind=True, max_retries=3)
def scan_bot_pair(self, bot_id: str, pair: str, timeframe: str):
    """Scan a single bot pair — called by run_all_bot_scans."""
    try:
        from services.bot_service import bot_service
        from ai.indicators import compute_all
        return {"bot_id": bot_id, "pair": pair, "status": "scanned"}
    except Exception as e:
        self.retry(exc=e, countdown=5)

@app.task(name="workers.tasks.send_notification", bind=True, max_retries=2)
def send_notification(self, user_id: str, event: str, title: str, body: str, data: dict = None):
    """Send notification via all channels."""
    try:
        from services.notification_service import notification_service
        result = run_async(notification_service.notify(user_id, event, title, body, data))
        return result
    except Exception as e:
        self.retry(exc=e, countdown=5)

@app.task(name="workers.tasks.process_webhook", bind=True, max_retries=3)
def process_webhook(self, provider: str, payload: dict, signature: str):
    """Process payment/signal webhooks asynchronously."""
    try:
        from services.payment_service import payment_service
        if provider == "flutterwave":
            result = run_async(payment_service.handle_flutterwave_webhook(payload, signature))
        elif provider == "nowpayments":
            result = run_async(payment_service.handle_nowpayments_webhook(payload, signature))
        else:
            result = {"skipped": True, "provider": provider}
        return result
    except Exception as e:
        self.retry(exc=e, countdown=15)

@app.task(name="workers.tasks.process_withdrawal", bind=True, max_retries=2)
def process_withdrawal(self, withdrawal_id: str):
    """Process withdrawal request in background."""
    try:
        from services.wallet_service import wallet_service
        result = run_async(wallet_service.execute_withdrawal(withdrawal_id))
        return result
    except Exception as e:
        self.retry(exc=e, countdown=30)

@app.task(name="workers.tasks.send_daily_summaries")
def send_daily_summaries():
    """Send daily P&L summary to all active users."""
    try:
        from core.database import db
        from services.notification_service import notification_service
        users = (db.table("users").select("id").eq("is_active", True).execute()).data or []
        for u in users:
            uid = u["id"]
            trades = (db.table("trades").select("net_pnl,status")
                      .eq("user_id", uid).gte("closed_at", "now()-interval '1 day'").execute()).data or []
            pnl   = sum(float(t.get("net_pnl", 0)) for t in trades)
            wins  = sum(1 for t in trades if float(t.get("net_pnl",0)) > 0)
            wr    = wins/max(len(trades),1)*100
            wallet = (db.table("wallets").select("balance").eq("user_id", uid)
                      .eq("wallet_type","trading").eq("mode","live").execute()).data
            bal    = float(wallet[0]["balance"]) if wallet else 0
            run_async(notification_service.daily_summary(uid, pnl, len(trades), wr, bal))
        return {"sent": len(users)}
    except Exception as e:
        return {"error": str(e)}

@app.task(name="workers.tasks.refresh_market_cache")
def refresh_market_cache():
    """Pre-fetch and cache market data every 15s."""
    try:
        from exchanges.exchange_service import exchange_service
        pairs = ["BTC/USDT","ETH/USDT","SOL/USDT","BNB/USDT","ADA/USDT"]
        for pair in pairs:
            run_async(exchange_service.get_ticker(pair))
        return {"refreshed": len(pairs)}
    except Exception as e:
        return {"error": str(e)}

@app.task(name="workers.tasks.cleanup_old_logs")
def cleanup_old_logs():
    """Clean notification logs older than 30 days."""
    try:
        from core.database import db
        db.table("notification_logs").delete().lt("created_at","now()-interval '30 days'").execute()
        return {"cleaned": True}
    except Exception as e:
        return {"error": str(e)}


@app.task(name="workers.tasks.accrue_daily_subscriptions")
def accrue_daily_subscriptions():
    """Accrue $1/day subscription for all active subscribers (runs daily 00:01 UTC)."""
    try:
        from core.database import db
        from services.fee_engine import fee_engine
        subs = (db.table("subscriptions").select("user_id")
                .eq("status","active").execute()).data or []
        accrued = 0
        for s in subs:
            result = run_async(fee_engine.accrue_daily_subscription(s["user_id"]))
            if result.get("accrued"):
                accrued += 1
        return {"accrued": accrued, "total_users": len(subs)}
    except Exception as e:
        return {"error": str(e)}

@app.task(name="workers.tasks.collect_monthly_fees")
def collect_monthly_fees():
    """1st of month: collect all outstanding fees for all users."""
    try:
        from services.fee_engine import fee_engine
        return run_async(fee_engine.collect_monthly_all_users())
    except Exception as e:
        return {"error": str(e)}


@app.task(name="workers.tasks.auto_trade_all_bots", bind=True, max_retries=2)
def auto_trade_all_bots(self):
    """Run auto-trade cycle for ALL running bots across ALL users."""
    try:
        from core.database import db
        from services.bot_service import auto_trade_engine
        running = (db.table("bots").select("id,user_id")
                   .eq("status","running").execute()).data or []
        results = []
        for bot in running:
            try:
                r = run_async(auto_trade_engine.run_bot_cycle(bot["id"], bot["user_id"]))
                results.append({"bot":bot["id"],"user":bot["user_id"],"result":r})
            except Exception as e:
                results.append({"bot":bot["id"],"error":str(e)})
        return {"cycles": len(results), "results": results}
    except Exception as e:
        self.retry(exc=e, countdown=10)

@app.task(name="workers.tasks.manage_open_trades")
def manage_open_trades():
    """Check SL/TP/trail for all open trades (every 10s)."""
    try:
        from core.database import db
        from services.bot_service import auto_trade_engine
        users = list(set(r["user_id"] for r in
            (db.table("trades").select("user_id").eq("status","open").execute()).data or []))
        for uid in users:
            run_async(auto_trade_engine.manage_open_trades(uid))
        return {"users_processed": len(users)}
    except Exception as e:
        return {"error": str(e)}

@app.task(name="workers.tasks.check_auto_withdrawals")
def check_auto_withdrawals():
    """Check if any user has hit auto-withdrawal threshold."""
    try:
        from core.database import db
        from services.payment_service import advanced_payment
        configs = (db.table("auto_withdrawal_config").select("user_id")
                   .eq("is_active",True).execute()).data or []
        triggered = 0
        for c in configs:
            r = run_async(advanced_payment.check_auto_withdrawal(c["user_id"]))
            if r.get("triggered"):
                triggered += 1
        return {"checked": len(configs), "triggered": triggered}
    except Exception as e:
        return {"error": str(e)}
