-- ESTRADE v6 Multiplier System Migration (007)

-- Bot multiplier config
CREATE TABLE IF NOT EXISTS bot_multiplier_config (
    id                  uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    bot_id              uuid,
    user_id             uuid REFERENCES auth.users(id) ON DELETE CASCADE,
    default_multiplier  int DEFAULT 1,
    max_multiplier      int DEFAULT 1,
    auto_scale          boolean DEFAULT false,
    scale_on_confidence numeric(5,2) DEFAULT 85.0,
    created_at          timestamptz DEFAULT now(),
    updated_at          timestamptz DEFAULT now(),
    UNIQUE(bot_id, user_id)
);

-- Trade guards (drawdown protection)
CREATE TABLE IF NOT EXISTS trade_guards (
    id               uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    trade_id         uuid,
    guard_type       text DEFAULT 'max_drawdown',
    threshold_pct    numeric(5,2),
    initial_capital  numeric(18,4),
    is_active        boolean DEFAULT true,
    triggered_at     timestamptz,
    created_at       timestamptz DEFAULT now()
);

-- Multiplier trade log
CREATE TABLE IF NOT EXISTS multiplier_trades (
    id                 uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id            uuid REFERENCES auth.users(id),
    trade_id           uuid,
    bot_id             uuid,
    multiplier         int,
    level_name         text,
    base_capital       numeric(18,4),
    effective_capital  numeric(18,4),
    validation_score   numeric(5,2),
    anti_fake_passed   boolean DEFAULT false,
    executed           boolean DEFAULT false,
    created_at         timestamptz DEFAULT now()
);

-- RLS
ALTER TABLE bot_multiplier_config  ENABLE ROW LEVEL SECURITY;
ALTER TABLE trade_guards           ENABLE ROW LEVEL SECURITY;
ALTER TABLE multiplier_trades      ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own_mult_config" ON bot_multiplier_config FOR ALL USING (auth.uid()=user_id);
CREATE POLICY "own_mult_trades" ON multiplier_trades     FOR ALL USING (auth.uid()=user_id);

CREATE INDEX IF NOT EXISTS idx_mult_config_bot  ON bot_multiplier_config(bot_id, user_id);
CREATE INDEX IF NOT EXISTS idx_trade_guards_tid ON trade_guards(trade_id) WHERE is_active=true;
