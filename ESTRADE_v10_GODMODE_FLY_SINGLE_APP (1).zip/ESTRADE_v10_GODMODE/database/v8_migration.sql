-- ═══════════════════════════════════════════════════════════════════════════
-- ESTRADE v8 GODMODE — Complete Supabase Migration
-- Includes: ALL v7 tables + v8 additions
--   • RL Engine state persistence
--   • Strategy Evolution Hall of Fame
--   • Risk AI event log
--   • Deriv indices permissions
--   • Market sessions tracking
--   • Performance analytics
--   • Security events (enhanced)
-- Run this in Supabase SQL Editor → New Query → Run
-- ═══════════════════════════════════════════════════════════════════════════

BEGIN;

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- ══════════════════════════════════════════════════════════════
-- USERS
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS users (
    id                     UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email                  TEXT UNIQUE NOT NULL,
    password_hash          TEXT NOT NULL,
    full_name              TEXT DEFAULT '',
    phone                  TEXT DEFAULT '',
    country                TEXT DEFAULT '',
    role                   TEXT DEFAULT 'user' CHECK (role IN ('user','admin','analyst','broker')),
    platform               TEXT DEFAULT 'both' CHECK (platform IN ('esf','esc','both')),
    tier                   TEXT DEFAULT 'silver' CHECK (tier IN ('silver','gold','platinum')),
    ai_tier                TEXT DEFAULT 'silver' CHECK (ai_tier IN ('silver','gold','platinum')),
    subscription_plan      TEXT DEFAULT 'free',
    subscription_status    TEXT DEFAULT 'inactive',
    stripe_customer_id     TEXT,
    stripe_subscription_id TEXT,
    trial_ends_at          TIMESTAMPTZ,
    is_active              BOOLEAN DEFAULT TRUE,
    is_verified            BOOLEAN DEFAULT FALSE,
    two_fa_enabled         BOOLEAN DEFAULT FALSE,
    two_fa_secret          TEXT,
    kyc_verified           BOOLEAN DEFAULT FALSE,
    referral_code          TEXT UNIQUE DEFAULT encode(gen_random_bytes(6),'hex'),
    referred_by            UUID REFERENCES users(id),
    last_login             TIMESTAMPTZ,
    login_count            INTEGER DEFAULT 0,
    total_profit           NUMERIC(20,8) DEFAULT 0,
    total_trades           INTEGER DEFAULT 0,
    -- v8 additions
    deriv_allowed          BOOLEAN DEFAULT FALSE,
    deriv_allowed_at       TIMESTAMPTZ,
    preferred_exchange     TEXT DEFAULT 'binance',
    timezone               TEXT DEFAULT 'UTC',
    telegram_chat_id       TEXT,
    notification_prefs     JSONB DEFAULT '{"trade_open":true,"trade_close":true,"daily_report":true,"circuit_break":true}',
    created_at             TIMESTAMPTZ DEFAULT NOW(),
    updated_at             TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_users_email  ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_stripe ON users(stripe_customer_id);
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
CREATE POLICY users_self ON users USING (id = auth.uid());
CREATE POLICY users_admin ON users USING (
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin')
);

-- ══════════════════════════════════════════════════════════════
-- WALLETS
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS wallets (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    currency        TEXT NOT NULL DEFAULT 'USDT',
    balance         NUMERIC(20,8) DEFAULT 0 CHECK (balance >= 0),
    locked_balance  NUMERIC(20,8) DEFAULT 0,
    total_deposited NUMERIC(20,8) DEFAULT 0,
    total_withdrawn NUMERIC(20,8) DEFAULT 0,
    total_profit    NUMERIC(20,8) DEFAULT 0,
    total_loss      NUMERIC(20,8) DEFAULT 0,
    peak_balance    NUMERIC(20,8) DEFAULT 0,
    is_primary      BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, currency)
);
ALTER TABLE wallets ENABLE ROW LEVEL SECURITY;
CREATE POLICY wallets_user ON wallets USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- EXCHANGE CONNECTIONS
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS exchange_connections (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    exchange        TEXT NOT NULL,
    platform        TEXT DEFAULT 'esc',
    label           TEXT DEFAULT '',
    api_key_enc     TEXT NOT NULL,
    api_secret_enc  TEXT NOT NULL,
    passphrase_enc  TEXT,
    is_testnet      BOOLEAN DEFAULT FALSE,
    status          TEXT DEFAULT 'pending' CHECK (status IN ('pending','active','error','disconnected')),
    balance_cache   JSONB DEFAULT '{}',
    permissions     JSONB DEFAULT '{"read":true,"trade":false,"withdraw":false}',
    withdraw_allowed BOOLEAN DEFAULT FALSE,
    last_sync       TIMESTAMPTZ,
    error_message   TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE exchange_connections ENABLE ROW LEVEL SECURITY;
CREATE POLICY ex_conn_user ON exchange_connections USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- MT5 CONNECTIONS
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS mt5_connections (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    broker_name     TEXT NOT NULL,
    server          TEXT NOT NULL,
    login_enc       TEXT NOT NULL,
    password_enc    TEXT NOT NULL,
    connection_type TEXT DEFAULT 'rest',
    rest_url        TEXT,
    api_key_enc     TEXT,
    account_id      TEXT,
    account_type    TEXT DEFAULT 'real',
    currency        TEXT DEFAULT 'USD',
    leverage        INTEGER DEFAULT 100,
    is_active       BOOLEAN DEFAULT TRUE,
    is_hedging      BOOLEAN DEFAULT FALSE,
    last_balance    NUMERIC(20,4),
    last_equity     NUMERIC(20,4),
    last_sync       TIMESTAMPTZ,
    status          TEXT DEFAULT 'pending',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE mt5_connections ENABLE ROW LEVEL SECURITY;
CREATE POLICY mt5_user ON mt5_connections USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- DERIV CONNECTIONS (v8 NEW)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS deriv_connections (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_enc       TEXT NOT NULL,
    app_id          TEXT DEFAULT '36544',
    account_id      TEXT,
    account_type    TEXT DEFAULT 'real',
    currency        TEXT DEFAULT 'USD',
    balance         NUMERIC(20,4),
    allowed         BOOLEAN DEFAULT FALSE,
    allowed_at      TIMESTAMPTZ,
    allowed_ip      TEXT,
    status          TEXT DEFAULT 'pending',
    last_sync       TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE deriv_connections ENABLE ROW LEVEL SECURITY;
CREATE POLICY deriv_user ON deriv_connections USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- BOTS
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS bots (
    id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id              UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    bot_id               TEXT NOT NULL,
    name                 TEXT NOT NULL,
    category             TEXT NOT NULL,
    platform             TEXT DEFAULT 'both',
    status               TEXT DEFAULT 'stopped'
                         CHECK (status IN ('running','stopped','paused','frozen','error')),
    ai_tier              TEXT DEFAULT 'silver',
    capital_mode         TEXT DEFAULT 'hybrid',
    allocated_capital    NUMERIC(20,8) DEFAULT 0,
    exchange_conn_id     UUID REFERENCES exchange_connections(id),
    mt5_conn_id          UUID REFERENCES mt5_connections(id),
    deriv_conn_id        UUID REFERENCES deriv_connections(id),
    is_active            BOOLEAN DEFAULT TRUE,
    is_demo              BOOLEAN DEFAULT FALSE,

    -- 2% Pro Mode
    two_pct_mode         BOOLEAN DEFAULT FALSE,

    -- Profit Range Selector
    profit_range_target  NUMERIC(6,2) DEFAULT 0,
    profit_range_mode    TEXT DEFAULT 'per_session'
                         CHECK (profit_range_mode IN ('per_trade','per_session','')),
    active_strategy      TEXT DEFAULT '',

    -- Capital maximizer
    daily_target_pct     NUMERIC(8,4) DEFAULT 3.0,
    small_profit_mode    BOOLEAN DEFAULT FALSE,
    reinvest_pct         NUMERIC(8,4) DEFAULT 0,
    kelly_sizing         BOOLEAN DEFAULT FALSE,
    auto_pause_on_target BOOLEAN DEFAULT FALSE,
    headway_style        BOOLEAN DEFAULT FALSE,
    royaliq_style        BOOLEAN DEFAULT FALSE,
    capital_growth       BOOLEAN DEFAULT FALSE,
    drawdown_circuit_breaker_pct NUMERIC(8,4) DEFAULT 15.0,

    -- ProMax USDT sequence
    promax_sequence_pos  INTEGER DEFAULT 0,
    promax_session_usdt  NUMERIC(12,4) DEFAULT 0,
    promax_cycle_done    BOOLEAN DEFAULT FALSE,
    usdt_sequence_mode   BOOLEAN DEFAULT FALSE,

    -- v8: RL + Risk settings
    rl_enabled           BOOLEAN DEFAULT TRUE,
    risk_ai_enabled      BOOLEAN DEFAULT TRUE,
    strategy_evolver_enabled BOOLEAN DEFAULT TRUE,
    genome_id            TEXT,
    max_risk_pct         NUMERIC(6,4) DEFAULT 2.0,
    use_deriv            BOOLEAN DEFAULT FALSE,

    -- Performance
    total_trades         INTEGER DEFAULT 0,
    win_trades           INTEGER DEFAULT 0,
    loss_trades          INTEGER DEFAULT 0,
    total_pnl            NUMERIC(20,8) DEFAULT 0,
    total_pnl_pct        NUMERIC(10,4) DEFAULT 0,
    daily_pnl            NUMERIC(20,8) DEFAULT 0,
    daily_pnl_pct        NUMERIC(10,4) DEFAULT 0,
    session_pnl_pct      NUMERIC(10,4) DEFAULT 0,
    max_drawdown_pct     NUMERIC(10,4) DEFAULT 0,
    best_trade_pct       NUMERIC(10,4) DEFAULT 0,
    worst_trade_pct      NUMERIC(10,4) DEFAULT 0,
    sharpe_ratio         NUMERIC(10,4) DEFAULT 0,
    win_rate             NUMERIC(6,4) DEFAULT 0,

    -- State
    circuit_breaker      BOOLEAN DEFAULT FALSE,
    stop_reason          TEXT,
    stopped_at           TIMESTAMPTZ,
    last_trade_at        TIMESTAMPTZ,
    started_at           TIMESTAMPTZ,
    created_at           TIMESTAMPTZ DEFAULT NOW(),
    updated_at           TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_bots_user     ON bots(user_id, status);
CREATE INDEX IF NOT EXISTS idx_bots_platform ON bots(platform);
CREATE INDEX IF NOT EXISTS idx_bots_bot_id   ON bots(bot_id);
ALTER TABLE bots ENABLE ROW LEVEL SECURITY;
CREATE POLICY bots_user  ON bots USING (user_id = auth.uid());
CREATE POLICY bots_admin ON bots USING (
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin')
);

-- ══════════════════════════════════════════════════════════════
-- TRADES
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS trades (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bot_id          UUID REFERENCES bots(id) ON DELETE SET NULL,
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    symbol          TEXT NOT NULL,
    direction       TEXT NOT NULL CHECK (direction IN ('buy','sell')),
    size_usd        NUMERIC(20,8) DEFAULT 0,
    entry_price     NUMERIC(20,8),
    exit_price      NUMERIC(20,8),
    sl_price        NUMERIC(20,8),
    tp_price        NUMERIC(20,8),
    pnl             NUMERIC(20,8) DEFAULT 0,
    pnl_pct         NUMERIC(10,4) DEFAULT 0,
    commission      NUMERIC(20,8) DEFAULT 0,
    slippage_pct    NUMERIC(8,4) DEFAULT 0,
    status          TEXT DEFAULT 'open' CHECK (status IN ('open','closed','cancelled','error')),
    exchange        TEXT DEFAULT 'binance',
    exchange_order_id TEXT,
    timeframe       TEXT DEFAULT '5m',
    confidence      NUMERIC(6,2) DEFAULT 0,
    rr_ratio        NUMERIC(6,2) DEFAULT 0,
    risk_score      NUMERIC(6,2) DEFAULT 0,
    latency_ms      NUMERIC(8,2) DEFAULT 0,
    session         TEXT DEFAULT 'neutral',
    regime          TEXT DEFAULT 'neutral',
    -- v8: AI metadata
    ai_signal       JSONB DEFAULT '{}',
    rl_action       INTEGER,
    rl_confidence   NUMERIC(6,2),
    genome_id       TEXT,
    risk_decision   JSONB DEFAULT '{}',
    -- v8: Deriv specific
    is_deriv        BOOLEAN DEFAULT FALSE,
    deriv_contract_id TEXT,
    -- Timestamps
    opened_at       TIMESTAMPTZ DEFAULT NOW(),
    closed_at       TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_trades_user   ON trades(user_id, status);
CREATE INDEX IF NOT EXISTS idx_trades_bot    ON trades(bot_id, status);
CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
CREATE INDEX IF NOT EXISTS idx_trades_time   ON trades(created_at DESC);
ALTER TABLE trades ENABLE ROW LEVEL SECURITY;
CREATE POLICY trades_user ON trades USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- RL ENGINE STATE (v8 NEW)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS rl_engine_state (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id) ON DELETE CASCADE,
    version         TEXT DEFAULT 'v8',
    total_trades    INTEGER DEFAULT 0,
    win_count       INTEGER DEFAULT 0,
    loss_count      INTEGER DEFAULT 0,
    total_pnl       NUMERIC(20,8) DEFAULT 0,
    max_drawdown    NUMERIC(8,4) DEFAULT 0,
    sharpe          NUMERIC(8,4) DEFAULT 0,
    ppo_updates     INTEGER DEFAULT 0,
    dqn_updates     INTEGER DEFAULT 0,
    ppo_weight      NUMERIC(6,4) DEFAULT 0.6,
    dqn_weight      NUMERIC(6,4) DEFAULT 0.4,
    dqn_epsilon     NUMERIC(6,4) DEFAULT 1.0,
    regime_weights  JSONB DEFAULT '{}',
    pnl_history     JSONB DEFAULT '[]',
    ppo_params      JSONB DEFAULT '{}',
    dqn_params      JSONB DEFAULT '{}',
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE rl_engine_state ENABLE ROW LEVEL SECURITY;
CREATE POLICY rl_state_user  ON rl_engine_state USING (user_id = auth.uid() OR user_id IS NULL);
CREATE POLICY rl_state_admin ON rl_engine_state USING (
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin')
);

-- ══════════════════════════════════════════════════════════════
-- STRATEGY HALL OF FAME (v8 NEW)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS strategy_hall_of_fame (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    genome_id       TEXT UNIQUE NOT NULL,
    generation      INTEGER DEFAULT 0,
    fitness         NUMERIC(10,6) DEFAULT 0,
    sharpe          NUMERIC(10,6) DEFAULT 0,
    win_rate        NUMERIC(8,6) DEFAULT 0,
    profit_factor   NUMERIC(10,6) DEFAULT 0,
    max_drawdown    NUMERIC(8,4) DEFAULT 0,
    total_trades    INTEGER DEFAULT 0,
    genome_params   JSONB NOT NULL DEFAULT '{}',
    symbol          TEXT DEFAULT 'BTCUSDT',
    timeframe       TEXT DEFAULT '1h',
    backtest_candles INTEGER DEFAULT 0,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_hof_fitness ON strategy_hall_of_fame(fitness DESC);

-- ══════════════════════════════════════════════════════════════
-- RISK EVENTS (v8 NEW)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS risk_events (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bot_id      UUID REFERENCES bots(id),
    user_id     UUID REFERENCES users(id),
    event_type  TEXT NOT NULL,  -- drawdown_level_change, circuit_trip, halt, resume
    dd_level    INTEGER,
    dd_pct      NUMERIC(8,4),
    circuit     TEXT,
    details     JSONB DEFAULT '{}',
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_risk_events_time ON risk_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_risk_events_bot  ON risk_events(bot_id);
ALTER TABLE risk_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY risk_events_user ON risk_events USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- MARKET SESSIONS LOG (v8 NEW)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS market_sessions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session         TEXT NOT NULL CHECK (session IN ('asia','london','new_york','overnight')),
    date            DATE NOT NULL,
    pnl_total       NUMERIC(20,8) DEFAULT 0,
    trades_count    INTEGER DEFAULT 0,
    wins            INTEGER DEFAULT 0,
    losses          INTEGER DEFAULT 0,
    best_trade_pct  NUMERIC(8,4),
    worst_trade_pct NUMERIC(8,4),
    avg_latency_ms  NUMERIC(8,2),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(session, date)
);

-- ══════════════════════════════════════════════════════════════
-- SECURITY EVENTS (enhanced v8)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS security_events (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type        TEXT NOT NULL,
    user_id     UUID REFERENCES users(id),
    ip          TEXT,
    user_agent  TEXT,
    severity    TEXT DEFAULT 'LOW' CHECK (severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
    data        JSONB DEFAULT '{}',
    resolved    BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_sec_events_time ON security_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sec_events_type ON security_events(type, severity);
ALTER TABLE security_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY sec_events_admin ON security_events USING (
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid() AND role = 'admin')
);

-- ══════════════════════════════════════════════════════════════
-- MAINTENANCE WINDOWS
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS maintenance_windows (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title           TEXT NOT NULL,
    message         TEXT DEFAULT '',
    starts_at       TIMESTAMPTZ NOT NULL,
    ends_at         TIMESTAMPTZ NOT NULL,
    is_active       BOOLEAN DEFAULT FALSE,
    affects_bots    BOOLEAN DEFAULT TRUE,
    affects_trading BOOLEAN DEFAULT TRUE,
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ══════════════════════════════════════════════════════════════
-- PAYMENTS / SUBSCRIPTIONS
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS payments (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    stripe_payment_id TEXT,
    stripe_session_id TEXT,
    amount          NUMERIC(10,2) NOT NULL,
    currency        TEXT DEFAULT 'usd',
    plan            TEXT NOT NULL,
    status          TEXT DEFAULT 'pending' CHECK (status IN ('pending','completed','failed','refunded')),
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY payments_user ON payments USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- NOTIFICATIONS
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS notifications (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type        TEXT NOT NULL,
    title       TEXT NOT NULL,
    body        TEXT DEFAULT '',
    icon        TEXT DEFAULT '🔔',
    is_read     BOOLEAN DEFAULT FALSE,
    data        JSONB DEFAULT '{}',
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, is_read);
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY notif_user ON notifications USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- PERFORMANCE ANALYTICS (v8 NEW — daily rollup)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS daily_performance (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    date            DATE NOT NULL,
    balance_start   NUMERIC(20,8),
    balance_end     NUMERIC(20,8),
    pnl             NUMERIC(20,8) DEFAULT 0,
    pnl_pct         NUMERIC(8,4) DEFAULT 0,
    trades          INTEGER DEFAULT 0,
    wins            INTEGER DEFAULT 0,
    losses          INTEGER DEFAULT 0,
    max_drawdown    NUMERIC(8,4) DEFAULT 0,
    sharpe          NUMERIC(8,4) DEFAULT 0,
    best_trade      NUMERIC(8,4),
    worst_trade     NUMERIC(8,4),
    sessions_data   JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, date)
);
ALTER TABLE daily_performance ENABLE ROW LEVEL SECURITY;
CREATE POLICY daily_perf_user ON daily_performance USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- REALTIME PUBLICATION
-- ══════════════════════════════════════════════════════════════
ALTER PUBLICATION supabase_realtime ADD TABLE bots;
ALTER PUBLICATION supabase_realtime ADD TABLE trades;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE risk_events;

-- ══════════════════════════════════════════════════════════════
-- FUNCTIONS & TRIGGERS
-- ══════════════════════════════════════════════════════════════

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER bots_updated_at BEFORE UPDATE ON bots
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER wallets_updated_at BEFORE UPDATE ON wallets
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Auto-create wallet on user creation
CREATE OR REPLACE FUNCTION create_default_wallet()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO wallets (user_id, currency, is_primary)
    VALUES (NEW.id, 'USDT', TRUE)
    ON CONFLICT DO NOTHING;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_user_created AFTER INSERT ON users
    FOR EACH ROW EXECUTE FUNCTION create_default_wallet();

-- Update bot stats when trade closes
CREATE OR REPLACE FUNCTION update_bot_stats_on_trade()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'closed' AND OLD.status = 'open' THEN
        UPDATE bots SET
            total_trades = total_trades + 1,
            win_trades   = win_trades + CASE WHEN NEW.pnl > 0 THEN 1 ELSE 0 END,
            loss_trades  = loss_trades + CASE WHEN NEW.pnl <= 0 THEN 1 ELSE 0 END,
            total_pnl    = total_pnl + COALESCE(NEW.pnl, 0),
            daily_pnl    = daily_pnl + COALESCE(NEW.pnl, 0),
            daily_pnl_pct= daily_pnl_pct + COALESCE(NEW.pnl_pct, 0),
            last_trade_at= NOW(),
            updated_at   = NOW()
        WHERE id = NEW.bot_id;

        -- Update user wallet
        UPDATE wallets SET
            balance      = balance + COALESCE(NEW.pnl, 0),
            total_profit = total_profit + CASE WHEN NEW.pnl > 0 THEN NEW.pnl ELSE 0 END,
            total_loss   = total_loss + CASE WHEN NEW.pnl < 0 THEN ABS(NEW.pnl) ELSE 0 END,
            updated_at   = NOW()
        WHERE user_id = NEW.user_id AND is_primary = TRUE;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_trade_closed AFTER UPDATE ON trades
    FOR EACH ROW EXECUTE FUNCTION update_bot_stats_on_trade();

-- ══════════════════════════════════════════════════════════════
-- DEFAULT ADMIN USER (change password after first login!)
-- ══════════════════════════════════════════════════════════════
INSERT INTO users (email, password_hash, full_name, role, is_active, is_verified)
VALUES (
    'admin@estrading.machine',
    encode(sha256('EstradingMachine2026!Change'),'hex'),
    'ESTRADE Admin',
    'admin',
    TRUE,
    TRUE
) ON CONFLICT (email) DO NOTHING;

COMMIT;

-- ═══════════════════════════════════════════════════════════════
-- POST-MIGRATION: Enable Realtime in Supabase Dashboard
-- Go to: Database → Replication → Enable for: bots, trades, notifications
-- ═══════════════════════════════════════════════════════════════
