-- ═══════════════════════════════════════════════════════════════════════════
-- estrading.machine v10 GODMODE — COMPLETE SUPABASE MIGRATION
-- ONE FILE TO RULE THEM ALL — Run this SINGLE file in Supabase SQL Editor
-- Creates EVERYTHING: auth, bots, trades, signals, reinvest, security, AI
-- ═══════════════════════════════════════════════════════════════════════════

BEGIN;

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ═══════════════════════════════════════════════════
-- 1. USERS & AUTH
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS users (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email               TEXT UNIQUE NOT NULL,
    password_hash       TEXT NOT NULL,
    full_name           TEXT DEFAULT '',
    phone               TEXT DEFAULT '',
    country             TEXT DEFAULT '',
    avatar_url          TEXT DEFAULT '',
    role                TEXT DEFAULT 'user' CHECK (role IN ('user','admin','analyst')),
    tier                TEXT DEFAULT 'silver' CHECK (tier IN ('silver','gold','platinum')),
    platform            TEXT DEFAULT 'both',
    is_active           BOOLEAN DEFAULT TRUE,
    is_verified         BOOLEAN DEFAULT FALSE,
    is_suspended        BOOLEAN DEFAULT FALSE,
    two_fa_enabled      BOOLEAN DEFAULT FALSE,
    two_fa_secret       TEXT,
    kyc_verified        BOOLEAN DEFAULT FALSE,
    referral_code       TEXT UNIQUE DEFAULT encode(gen_random_bytes(6),'hex'),
    referred_by         UUID REFERENCES users(id),
    -- Preferences
    preferred_exchange  TEXT DEFAULT 'binance',
    timezone            TEXT DEFAULT 'UTC',
    language            TEXT DEFAULT 'en',
    telegram_chat_id    TEXT,
    notification_prefs  JSONB DEFAULT '{"trade_open":true,"trade_close":true,"signal":true,"daily_report":true}',
    -- v10 additions
    deriv_allowed       BOOLEAN DEFAULT FALSE,
    deriv_allowed_at    TIMESTAMPTZ,
    signal_mode         TEXT DEFAULT 'auto' CHECK (signal_mode IN ('auto','manual','both')),
    reinvest_global     INTEGER DEFAULT 0,  -- global reinvest mode (0-7)
    -- Stats
    total_profit        NUMERIC(20,8) DEFAULT 0,
    total_trades        INTEGER DEFAULT 0,
    win_trades          INTEGER DEFAULT 0,
    -- Subscription
    subscription_plan   TEXT DEFAULT 'free',
    stripe_customer_id  TEXT,
    trial_ends_at       TIMESTAMPTZ,
    -- Meta
    last_login          TIMESTAMPTZ,
    login_count         INTEGER DEFAULT 0,
    last_ip             TEXT,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_users_email  ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role   ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_active ON users(is_active);
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS users_self  ON users FOR ALL USING (id = auth.uid());
CREATE POLICY IF NOT EXISTS users_admin ON users FOR ALL USING (
    EXISTS (SELECT 1 FROM users u WHERE u.id = auth.uid() AND u.role = 'admin')
);

-- Auth Sessions
CREATE TABLE IF NOT EXISTS auth_sessions (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash  TEXT NOT NULL,
    device_info JSONB DEFAULT '{}',
    ip_address  TEXT,
    user_agent  TEXT,
    is_active   BOOLEAN DEFAULT TRUE,
    expires_at  TIMESTAMPTZ NOT NULL,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON auth_sessions(user_id, is_active);
ALTER TABLE auth_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS sessions_user ON auth_sessions USING (user_id = auth.uid());

-- ═══════════════════════════════════════════════════
-- 2. WALLETS & FINANCE
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS wallets (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    currency        TEXT NOT NULL DEFAULT 'USDT',
    balance         NUMERIC(20,8) DEFAULT 0 CHECK (balance >= 0),
    locked_balance  NUMERIC(20,8) DEFAULT 0,
    total_deposited NUMERIC(20,8) DEFAULT 0,
    total_withdrawn NUMERIC(20,8) DEFAULT 0,
    total_profit    NUMERIC(20,8) DEFAULT 0,
    total_loss      NUMERIC(20,8) DEFAULT 0,
    peak_balance    NUMERIC(20,8) DEFAULT 0,
    is_primary      BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, currency)
);
ALTER TABLE wallets ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS wallets_user ON wallets FOR ALL USING (user_id = auth.uid());

-- ═══════════════════════════════════════════════════
-- 3. EXCHANGE CONNECTIONS
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS exchange_connections (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    exchange        TEXT NOT NULL,
    label           TEXT DEFAULT 'My Account',
    api_key_enc     TEXT NOT NULL,
    api_secret_enc  TEXT NOT NULL,
    passphrase_enc  TEXT,
    is_testnet      BOOLEAN DEFAULT FALSE,
    is_active       BOOLEAN DEFAULT TRUE,
    status          TEXT DEFAULT 'pending',
    balance_cache   JSONB DEFAULT '{}',
    withdraw_allowed BOOLEAN DEFAULT FALSE,
    permissions     JSONB DEFAULT '{"read":true,"trade":false,"withdraw":false}',
    last_sync       TIMESTAMPTZ,
    error_message   TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE exchange_connections ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS ex_user ON exchange_connections FOR ALL USING (user_id = auth.uid());

-- MT5 Connections
CREATE TABLE IF NOT EXISTS mt5_connections (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    broker_name     TEXT NOT NULL,
    server          TEXT NOT NULL,
    login_enc       TEXT NOT NULL,
    password_enc    TEXT NOT NULL,
    rest_url        TEXT,
    account_type    TEXT DEFAULT 'real',
    currency        TEXT DEFAULT 'USD',
    leverage        INTEGER DEFAULT 100,
    last_balance    NUMERIC(20,4),
    last_equity     NUMERIC(20,4),
    status          TEXT DEFAULT 'pending',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE mt5_connections ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS mt5_user ON mt5_connections FOR ALL USING (user_id = auth.uid());

-- Deriv Connections
CREATE TABLE IF NOT EXISTS deriv_connections (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_enc       TEXT NOT NULL,
    app_id          TEXT DEFAULT '36544',
    account_type    TEXT DEFAULT 'real',
    currency        TEXT DEFAULT 'USD',
    balance         NUMERIC(20,4),
    allowed         BOOLEAN DEFAULT FALSE,
    allowed_at      TIMESTAMPTZ,
    status          TEXT DEFAULT 'pending',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE deriv_connections ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS deriv_user ON deriv_connections FOR ALL USING (user_id = auth.uid());

-- ═══════════════════════════════════════════════════
-- 4. BOTS (v10 - complete with all fields)
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS bots (
    id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id              UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    bot_id               TEXT NOT NULL,
    name                 TEXT NOT NULL,
    category             TEXT NOT NULL,
    platform             TEXT DEFAULT 'both',
    status               TEXT DEFAULT 'stopped'
                         CHECK (status IN ('running','stopped','paused','frozen','error')),
    ai_tier              TEXT DEFAULT 'silver',
    -- Capital
    allocated_capital    NUMERIC(20,8) DEFAULT 1000,
    exchange_conn_id     UUID REFERENCES exchange_connections(id),
    mt5_conn_id          UUID REFERENCES mt5_connections(id),
    deriv_conn_id        UUID REFERENCES deriv_connections(id),
    is_demo              BOOLEAN DEFAULT FALSE,
    -- v10: Reinvestment
    reinvest_mode        INTEGER DEFAULT 0 CHECK (reinvest_mode BETWEEN 0 AND 7),
    compound_pool        NUMERIC(20,8) DEFAULT 0,
    total_reinvested     NUMERIC(20,8) DEFAULT 0,
    -- 2% Pro Mode
    two_pct_mode         BOOLEAN DEFAULT FALSE,
    -- Profit Range
    profit_range_target  NUMERIC(6,2) DEFAULT 0,
    profit_range_mode    TEXT DEFAULT 'per_session',
    -- Timeframe Strategy
    active_timeframe     TEXT DEFAULT '5m',
    active_profit_profile TEXT DEFAULT '5pct',
    -- Signal mode
    signal_mode          TEXT DEFAULT 'auto' CHECK (signal_mode IN ('auto','manual','both')),
    signal_channels      JSONB DEFAULT '{"telegram":false,"email":false,"webhook":false}',
    -- Money Printer
    capital_pct          NUMERIC(6,2) DEFAULT 50.0,
    pyramid_enabled      BOOLEAN DEFAULT TRUE,
    pyramid_level        INTEGER DEFAULT 0,
    -- v10: All-condition adapter
    condition_mode       TEXT DEFAULT 'adaptive',
    profit_lock_enabled  BOOLEAN DEFAULT TRUE,
    anti_loss_enabled    BOOLEAN DEFAULT TRUE,
    micro_harvest_enabled BOOLEAN DEFAULT FALSE,
    -- Risk
    max_dd_pct           NUMERIC(6,2) DEFAULT 15.0,
    daily_loss_limit     NUMERIC(6,2) DEFAULT 5.0,
    dd_level             INTEGER DEFAULT 0,
    circuit_breaker      BOOLEAN DEFAULT FALSE,
    -- RL & AI
    rl_enabled           BOOLEAN DEFAULT TRUE,
    genome_id            TEXT,
    -- Performance
    total_trades         INTEGER DEFAULT 0,
    win_trades           INTEGER DEFAULT 0,
    loss_trades          INTEGER DEFAULT 0,
    total_pnl            NUMERIC(20,8) DEFAULT 0,
    daily_pnl            NUMERIC(20,8) DEFAULT 0,
    daily_pnl_pct        NUMERIC(10,4) DEFAULT 0,
    session_pnl_pct      NUMERIC(10,4) DEFAULT 0,
    max_drawdown_pct     NUMERIC(10,4) DEFAULT 0,
    sharpe_ratio         NUMERIC(10,4) DEFAULT 0,
    win_rate             NUMERIC(6,4) DEFAULT 0,
    best_trade_pct       NUMERIC(10,4) DEFAULT 0,
    -- State
    stop_reason          TEXT,
    started_at           TIMESTAMPTZ,
    stopped_at           TIMESTAMPTZ,
    last_trade_at        TIMESTAMPTZ,
    created_at           TIMESTAMPTZ DEFAULT NOW(),
    updated_at           TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_bots_user   ON bots(user_id, status);
CREATE INDEX IF NOT EXISTS idx_bots_bot_id ON bots(bot_id);
ALTER TABLE bots ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS bots_user  ON bots FOR ALL USING (user_id = auth.uid());
CREATE POLICY IF NOT EXISTS bots_admin ON bots FOR ALL USING (
    EXISTS (SELECT 1 FROM users u WHERE u.id = auth.uid() AND u.role = 'admin')
);

-- ═══════════════════════════════════════════════════
-- 5. TRADES (v10)
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS trades (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bot_id          UUID REFERENCES bots(id) ON DELETE SET NULL,
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    symbol          TEXT NOT NULL,
    direction       TEXT NOT NULL CHECK (direction IN ('buy','sell')),
    size_usd        NUMERIC(20,8) DEFAULT 0,
    entry_price     NUMERIC(20,8),
    exit_price      NUMERIC(20,8),
    sl_price        NUMERIC(20,8),
    tp_price        NUMERIC(20,8),
    pnl             NUMERIC(20,8) DEFAULT 0,
    pnl_pct         NUMERIC(10,4) DEFAULT 0,
    commission      NUMERIC(20,8) DEFAULT 0,
    slippage_pct    NUMERIC(8,4) DEFAULT 0,
    status          TEXT DEFAULT 'open' CHECK (status IN ('open','closed','cancelled','error')),
    exchange        TEXT DEFAULT 'binance',
    timeframe       TEXT DEFAULT '5m',
    confidence      NUMERIC(6,2) DEFAULT 0,
    rr_ratio        NUMERIC(6,2) DEFAULT 0,
    latency_ms      NUMERIC(8,2) DEFAULT 0,
    -- v10: AI context
    emotion         TEXT DEFAULT 'neutral',
    engines_agree   INTEGER DEFAULT 0,
    strategy_code   TEXT,
    signal_id       TEXT,
    reinvest_mode   INTEGER DEFAULT 0,
    capital_pct_used NUMERIC(6,2) DEFAULT 50,
    -- v10: Profit lock
    profit_locked   BOOLEAN DEFAULT FALSE,
    locked_at_pct   NUMERIC(8,4),
    -- Timing
    opened_at       TIMESTAMPTZ DEFAULT NOW(),
    closed_at       TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_trades_user   ON trades(user_id, status);
CREATE INDEX IF NOT EXISTS idx_trades_bot    ON trades(bot_id, status);
CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
CREATE INDEX IF NOT EXISTS idx_trades_time   ON trades(created_at DESC);
ALTER TABLE trades ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS trades_user ON trades FOR ALL USING (user_id = auth.uid());

-- ═══════════════════════════════════════════════════
-- 6. SIGNALS v10 (manual + auto)
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS signals_v9 (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    signal_id       TEXT UNIQUE NOT NULL,
    user_id         UUID REFERENCES users(id),
    bot_key         TEXT,
    symbol          TEXT NOT NULL,
    timeframe       TEXT NOT NULL,
    direction       TEXT NOT NULL CHECK (direction IN ('BUY','SELL','NEUTRAL')),
    signal_type     TEXT DEFAULT 'standard',
    -- Prices
    entry_price     NUMERIC(20,8),
    entry_zone_lo   NUMERIC(20,8),
    entry_zone_hi   NUMERIC(20,8),
    stop_loss       NUMERIC(20,8),
    take_profit_1   NUMERIC(20,8),
    take_profit_2   NUMERIC(20,8),
    take_profit_3   NUMERIC(20,8),
    -- Risk metrics
    sl_pct          NUMERIC(8,4),
    tp2_pct         NUMERIC(8,4),
    rr_ratio        NUMERIC(6,2),
    sl_pips         NUMERIC(10,2),
    -- AI quality
    confidence      NUMERIC(6,2),
    engines_agree   INTEGER DEFAULT 0,
    emotion         TEXT DEFAULT 'neutral',
    feeling_boost   NUMERIC(6,3) DEFAULT 1.0,
    -- Strategy
    strategy_name   TEXT,
    strategy_code   TEXT,
    special_edge    TEXT,
    entry_reason    TEXT,
    -- Delivery formats
    telegram_msg    TEXT,
    mt4_comment     TEXT,
    tv_alert        TEXT,
    cornix_fmt      TEXT,
    -- Outcome
    status          TEXT DEFAULT 'active'
                    CHECK (status IN ('active','hit_tp1','hit_tp2','hit_tp3','stopped','expired')),
    pnl_pct         NUMERIC(10,4),
    won             BOOLEAN,
    -- Timestamps
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    closed_at       TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_signals_user   ON signals_v9(user_id, status);
CREATE INDEX IF NOT EXISTS idx_signals_sym    ON signals_v9(symbol, created_at DESC);
ALTER TABLE signals_v9 ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS signals_user ON signals_v9 FOR ALL USING (
    user_id = auth.uid() OR user_id IS NULL
);

-- Signal delivery config per user
CREATE TABLE IF NOT EXISTS user_signal_config (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    telegram_token  TEXT,
    telegram_chat_id TEXT,
    email           TEXT,
    email_alerts    BOOLEAN DEFAULT FALSE,
    tv_webhook_url  TEXT,
    custom_webhook  TEXT,
    cornix_enabled  BOOLEAN DEFAULT FALSE,
    min_confidence  NUMERIC(6,2) DEFAULT 70.0,
    symbols_filter  JSONB DEFAULT '[]',
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE user_signal_config ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS sig_cfg_user ON user_signal_config FOR ALL USING (user_id = auth.uid());

-- ═══════════════════════════════════════════════════
-- 7. REINVESTMENT ENGINE v10
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS reinvest_states (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    bot_id           UUID REFERENCES bots(id) ON DELETE CASCADE,
    bot_key          TEXT NOT NULL,
    mode             INTEGER DEFAULT 0 CHECK (mode BETWEEN 0 AND 7),
    base_size_usd    NUMERIC(20,8) DEFAULT 0,
    current_size_usd NUMERIC(20,8) DEFAULT 0,
    compound_pool    NUMERIC(20,8) DEFAULT 0,
    total_reinvested NUMERIC(20,8) DEFAULT 0,
    total_withdrawn  NUMERIC(20,8) DEFAULT 0,
    multiplier       NUMERIC(10,4) DEFAULT 1.0,
    cons_wins        INTEGER DEFAULT 0,
    cons_losses      INTEGER DEFAULT 0,
    win_rate         NUMERIC(6,4) DEFAULT 0.5,
    drawdown_pct     NUMERIC(8,4) DEFAULT 0,
    peak_size        NUMERIC(20,8) DEFAULT 0,
    trades           INTEGER DEFAULT 0,
    updated_at       TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, bot_key)
);
ALTER TABLE reinvest_states ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS reinvest_user ON reinvest_states FOR ALL USING (user_id = auth.uid());

-- ═══════════════════════════════════════════════════
-- 8. v10 PROFIT LOCK & ANTI-LOSS
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS profit_locks (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    bot_id          UUID REFERENCES bots(id),
    trade_id        UUID REFERENCES trades(id),
    symbol          TEXT,
    locked_at_pct   NUMERIC(8,4),  -- profit % when lock triggered
    lock_price      NUMERIC(20,8), -- price when locked (new SL)
    original_sl     NUMERIC(20,8),
    current_sl      NUMERIC(20,8),
    max_profit_seen NUMERIC(8,4),
    lock_triggered  BOOLEAN DEFAULT FALSE,
    outcome         TEXT,           -- 'profit_preserved' | 'stopped_at_lock' | 'tp_hit'
    pnl_pct         NUMERIC(8,4),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE profit_locks ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS pl_user ON profit_locks FOR ALL USING (user_id = auth.uid());

-- All-condition performance log
CREATE TABLE IF NOT EXISTS condition_performance (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id),
    condition       TEXT NOT NULL,  -- bull_strong, bull_weak, bear_strong, bear_weak, sideways, breakout, crash, high_vol, low_vol
    emotion         TEXT,
    trades          INTEGER DEFAULT 0,
    wins            INTEGER DEFAULT 0,
    total_pnl       NUMERIC(20,8) DEFAULT 0,
    avg_pnl_pct     NUMERIC(10,4) DEFAULT 0,
    best_strategy   TEXT,
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, condition)
);
ALTER TABLE condition_performance ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS cond_user ON condition_performance FOR ALL USING (user_id = auth.uid());

-- ═══════════════════════════════════════════════════
-- 9. BOT DESCRIPTIONS (all 43 bots metadata)
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS bot_descriptions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bot_id          TEXT UNIQUE NOT NULL,
    name            TEXT NOT NULL,
    icon            TEXT DEFAULT '🤖',
    color           TEXT DEFAULT '#6366f1',
    category        TEXT NOT NULL,
    platform        TEXT DEFAULT 'both',
    badge           TEXT DEFAULT '',
    ribbon_text     TEXT DEFAULT '',
    ai_tier_default TEXT DEFAULT 'silver',
    description     TEXT DEFAULT '',
    short_desc      TEXT DEFAULT '',
    special_feature TEXT DEFAULT '',
    highlight       TEXT DEFAULT '',
    strategy_primary TEXT DEFAULT '',
    pairs_default   JSONB DEFAULT '[]',
    timeframes      JSONB DEFAULT '[]',
    risk_profile    JSONB DEFAULT '{}',
    market_conditions JSONB DEFAULT '[]',
    sort_order      INTEGER DEFAULT 0,
    is_active       BOOLEAN DEFAULT TRUE,
    requires_deriv  BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_bot_desc_cat ON bot_descriptions(category);

-- ═══════════════════════════════════════════════════
-- 10. MARKET FEELINGS & AI STATE
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS market_feelings (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    symbol          TEXT NOT NULL,
    emotion         TEXT NOT NULL,
    emotion_score   NUMERIC(6,2),
    confidence      NUMERIC(6,2),
    technical_score NUMERIC(6,2),
    volume_score    NUMERIC(6,2),
    funding_score   NUMERIC(6,2),
    orderbook_score NUMERIC(6,2),
    momentum_score  NUMERIC(6,2),
    volatility_score NUMERIC(6,2),
    trade_signal    TEXT,
    size_multiplier NUMERIC(6,3),
    entry_note      TEXT,
    rsi             NUMERIC(6,2),
    funding_rate    NUMERIC(10,6),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_mf_sym  ON market_feelings(symbol, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_mf_emo  ON market_feelings(emotion, created_at DESC);

-- RL Engine state
CREATE TABLE IF NOT EXISTS rl_engine_state (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    version         TEXT DEFAULT 'v10',
    total_trades    INTEGER DEFAULT 0,
    win_count       INTEGER DEFAULT 0,
    loss_count      INTEGER DEFAULT 0,
    total_pnl       NUMERIC(20,8) DEFAULT 0,
    max_drawdown    NUMERIC(8,4) DEFAULT 0,
    sharpe          NUMERIC(8,4) DEFAULT 0,
    ppo_updates     INTEGER DEFAULT 0,
    dqn_updates     INTEGER DEFAULT 0,
    ppo_weight      NUMERIC(6,4) DEFAULT 0.6,
    dqn_weight      NUMERIC(6,4) DEFAULT 0.4,
    dqn_epsilon     NUMERIC(6,4) DEFAULT 1.0,
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Strategy Hall of Fame
CREATE TABLE IF NOT EXISTS strategy_hall_of_fame (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    genome_id       TEXT UNIQUE NOT NULL,
    generation      INTEGER DEFAULT 0,
    fitness         NUMERIC(10,6) DEFAULT 0,
    sharpe          NUMERIC(10,6) DEFAULT 0,
    win_rate        NUMERIC(8,6) DEFAULT 0,
    profit_factor   NUMERIC(10,6) DEFAULT 0,
    max_drawdown    NUMERIC(8,4) DEFAULT 0,
    total_trades    INTEGER DEFAULT 0,
    genome_params   JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_hof_fitness ON strategy_hall_of_fame(fitness DESC);

-- ═══════════════════════════════════════════════════
-- 11. MONEY PRINTING & PROFIT TRACKING
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS profit_generation_log (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id),
    bot_id          UUID REFERENCES bots(id),
    bot_key         TEXT,
    strategy        TEXT,
    profit_type     TEXT DEFAULT 'trend_trade',
    symbol          TEXT,
    market_regime   TEXT,
    gross_pnl       NUMERIC(20,8) DEFAULT 0,
    fees            NUMERIC(20,8) DEFAULT 0,
    net_pnl         NUMERIC(20,8) DEFAULT 0,
    net_pnl_pct     NUMERIC(10,4) DEFAULT 0,
    hold_minutes    NUMERIC(10,2),
    ai_confidence   NUMERIC(6,2),
    reinvest_mode   INTEGER DEFAULT 0,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_pgl_user ON profit_generation_log(user_id, created_at DESC);
ALTER TABLE profit_generation_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS pgl_user ON profit_generation_log FOR ALL USING (user_id = auth.uid());

-- Daily performance
CREATE TABLE IF NOT EXISTS daily_performance (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    date            DATE NOT NULL DEFAULT CURRENT_DATE,
    balance_start   NUMERIC(20,8),
    balance_end     NUMERIC(20,8),
    pnl             NUMERIC(20,8) DEFAULT 0,
    pnl_pct         NUMERIC(8,4) DEFAULT 0,
    trades          INTEGER DEFAULT 0,
    wins            INTEGER DEFAULT 0,
    losses          INTEGER DEFAULT 0,
    max_drawdown    NUMERIC(8,4) DEFAULT 0,
    sharpe          NUMERIC(8,4) DEFAULT 0,
    compound_earned NUMERIC(20,8) DEFAULT 0,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, date)
);
ALTER TABLE daily_performance ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS dp_user ON daily_performance FOR ALL USING (user_id = auth.uid());

-- Compound tracker
CREATE TABLE IF NOT EXISTS compound_tracker (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    bot_key         TEXT NOT NULL,
    snapshot_date   DATE NOT NULL DEFAULT CURRENT_DATE,
    profit_usd      NUMERIC(20,8) DEFAULT 0,
    profit_pct      NUMERIC(10,4) DEFAULT 0,
    compounded_usd  NUMERIC(20,8) DEFAULT 0,
    compound_pool   NUMERIC(20,8) DEFAULT 0,
    running_total   NUMERIC(20,8) DEFAULT 0,
    multiplier      NUMERIC(10,4) DEFAULT 1.0,
    trades_count    INTEGER DEFAULT 0,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, bot_key, snapshot_date)
);
ALTER TABLE compound_tracker ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS ct_user ON compound_tracker FOR ALL USING (user_id = auth.uid());

-- ═══════════════════════════════════════════════════
-- 12. SECURITY EVENTS
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS security_events (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type        TEXT NOT NULL,
    user_id     UUID REFERENCES users(id),
    ip          TEXT,
    user_agent  TEXT,
    severity    TEXT DEFAULT 'LOW' CHECK (severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
    data        JSONB DEFAULT '{}',
    resolved    BOOLEAN DEFAULT FALSE,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_sec_time ON security_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sec_type ON security_events(type, severity);

-- Failed login attempts
CREATE TABLE IF NOT EXISTS failed_logins (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email       TEXT,
    ip          TEXT,
    attempts    INTEGER DEFAULT 1,
    blocked     BOOLEAN DEFAULT FALSE,
    blocked_until TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(ip)
);

-- ═══════════════════════════════════════════════════
-- 13. NOTIFICATIONS
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS notifications (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type        TEXT NOT NULL,
    title       TEXT NOT NULL,
    body        TEXT DEFAULT '',
    icon        TEXT DEFAULT '🔔',
    is_read     BOOLEAN DEFAULT FALSE,
    data        JSONB DEFAULT '{}',
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, is_read, created_at DESC);
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS notif_user ON notifications FOR ALL USING (user_id = auth.uid());

-- ═══════════════════════════════════════════════════
-- 14. PAYMENTS & SUBSCRIPTIONS
-- ═══════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS payments (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    stripe_payment_id TEXT,
    amount          NUMERIC(10,2) NOT NULL,
    currency        TEXT DEFAULT 'usd',
    plan            TEXT NOT NULL,
    status          TEXT DEFAULT 'pending',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS pay_user ON payments FOR ALL USING (user_id = auth.uid());

-- ═══════════════════════════════════════════════════
-- 15. FUNCTIONS & TRIGGERS
-- ═══════════════════════════════════════════════════

-- Auto updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER users_upd   BEFORE UPDATE ON users    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE OR REPLACE TRIGGER bots_upd    BEFORE UPDATE ON bots     FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE OR REPLACE TRIGGER wallets_upd BEFORE UPDATE ON wallets  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Auto-create wallet on user register
CREATE OR REPLACE FUNCTION create_default_wallet()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO wallets (user_id, currency, is_primary)
    VALUES (NEW.id, 'USDT', TRUE) ON CONFLICT DO NOTHING;
    RETURN NEW;
END; $$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE TRIGGER on_user_created
AFTER INSERT ON users FOR EACH ROW EXECUTE FUNCTION create_default_wallet();

-- Update bot stats on trade close
CREATE OR REPLACE FUNCTION update_bot_on_trade_close()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'closed' AND OLD.status = 'open' THEN
        UPDATE bots SET
            total_trades  = total_trades + 1,
            win_trades    = win_trades + CASE WHEN NEW.pnl > 0 THEN 1 ELSE 0 END,
            loss_trades   = loss_trades + CASE WHEN NEW.pnl <= 0 THEN 1 ELSE 0 END,
            total_pnl     = total_pnl + COALESCE(NEW.pnl, 0),
            daily_pnl     = daily_pnl + COALESCE(NEW.pnl, 0),
            daily_pnl_pct = daily_pnl_pct + COALESCE(NEW.pnl_pct, 0),
            win_rate      = CASE WHEN (total_trades + 1) > 0 THEN
                (win_trades + CASE WHEN NEW.pnl > 0 THEN 1 ELSE 0 END)::FLOAT / (total_trades + 1) ELSE 0 END,
            last_trade_at = NOW(), updated_at = NOW()
        WHERE id = NEW.bot_id;

        UPDATE wallets SET
            balance      = GREATEST(0, balance + COALESCE(NEW.pnl, 0)),
            total_profit = total_profit + CASE WHEN NEW.pnl > 0 THEN NEW.pnl ELSE 0 END,
            total_loss   = total_loss + CASE WHEN NEW.pnl < 0 THEN ABS(NEW.pnl) ELSE 0 END,
            peak_balance = GREATEST(peak_balance, balance + COALESCE(NEW.pnl, 0)),
            updated_at   = NOW()
        WHERE user_id = NEW.user_id AND is_primary = TRUE;
    END IF;
    RETURN NEW;
END; $$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE TRIGGER on_trade_close
AFTER UPDATE ON trades FOR EACH ROW EXECUTE FUNCTION update_bot_on_trade_close();

-- Block IP after failed logins
CREATE OR REPLACE FUNCTION check_failed_login(p_email TEXT, p_ip TEXT)
RETURNS JSONB AS $$
DECLARE v_rec RECORD; BEGIN
    SELECT * INTO v_rec FROM failed_logins WHERE ip = p_ip;
    IF FOUND AND v_rec.blocked AND v_rec.blocked_until > NOW() THEN
        RETURN jsonb_build_object('blocked', true, 'until', v_rec.blocked_until);
    END IF;
    INSERT INTO failed_logins (email, ip, attempts)
    VALUES (p_email, p_ip, 1)
    ON CONFLICT (ip) DO UPDATE SET
        attempts  = failed_logins.attempts + 1,
        blocked   = (failed_logins.attempts + 1) >= 5,
        blocked_until = CASE WHEN (failed_logins.attempts + 1) >= 5
                        THEN NOW() + INTERVAL '30 minutes' ELSE NULL END;
    SELECT * INTO v_rec FROM failed_logins WHERE ip = p_ip;
    RETURN jsonb_build_object('blocked', v_rec.blocked, 'attempts', v_rec.attempts);
END; $$ LANGUAGE plpgsql SECURITY DEFINER;

-- Clear failed logins on successful login
CREATE OR REPLACE FUNCTION clear_failed_login(p_ip TEXT)
RETURNS VOID AS $$
BEGIN DELETE FROM failed_logins WHERE ip = p_ip; END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ═══════════════════════════════════════════════════
-- 16. ANALYTICS VIEWS
-- ═══════════════════════════════════════════════════
CREATE OR REPLACE VIEW v_portfolio_summary AS
SELECT u.id AS user_id, u.email, u.full_name,
    w.balance, w.total_profit, w.total_loss,
    COUNT(DISTINCT b.id) FILTER (WHERE b.status='running') AS running_bots,
    COUNT(DISTINCT b.id) AS total_bots,
    COUNT(t.id) FILTER (WHERE t.status='closed') AS total_trades,
    COUNT(t.id) FILTER (WHERE t.status='closed' AND t.pnl>0) AS win_trades,
    ROUND(COUNT(t.id) FILTER (WHERE t.status='closed' AND t.pnl>0)::NUMERIC /
          NULLIF(COUNT(t.id) FILTER (WHERE t.status='closed'),0)*100, 2) AS win_rate_pct,
    SUM(t.pnl) FILTER (WHERE t.status='closed') AS realized_pnl,
    COUNT(t.id) FILTER (WHERE t.status='open') AS open_trades
FROM users u
LEFT JOIN wallets w ON w.user_id=u.id AND w.is_primary=TRUE
LEFT JOIN bots b    ON b.user_id=u.id
LEFT JOIN trades t  ON t.user_id=u.id
GROUP BY u.id, u.email, u.full_name, w.balance, w.total_profit, w.total_loss;

CREATE OR REPLACE VIEW v_bot_leaderboard AS
SELECT b.id, b.name, b.bot_id, b.category, b.status,
    b.total_trades, b.win_trades, b.win_rate,
    b.total_pnl, b.daily_pnl_pct, b.sharpe_ratio,
    b.reinvest_mode, b.compound_pool,
    b.allocated_capital, b.max_drawdown_pct
FROM bots b WHERE b.is_active = TRUE
ORDER BY b.total_pnl DESC;

CREATE OR REPLACE VIEW v_signal_leaderboard AS
SELECT strategy_name, strategy_code,
    COUNT(*) AS total_signals,
    COUNT(*) FILTER (WHERE won=TRUE) AS wins,
    COUNT(*) FILTER (WHERE status='stopped') AS losses,
    ROUND(COUNT(*) FILTER (WHERE won=TRUE)::NUMERIC / NULLIF(COUNT(*),0)*100,1) AS win_rate,
    ROUND(AVG(pnl_pct) FILTER (WHERE pnl_pct IS NOT NULL),3) AS avg_pnl,
    ROUND(AVG(rr_ratio),2) AS avg_rr,
    ROUND(AVG(confidence),1) AS avg_confidence
FROM signals_v9
GROUP BY strategy_name, strategy_code
ORDER BY win_rate DESC;

-- ═══════════════════════════════════════════════════
-- 17. REALTIME PUBLICATION
-- ═══════════════════════════════════════════════════
DO $$ BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE bots;
    ALTER PUBLICATION supabase_realtime ADD TABLE trades;
    ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
    ALTER PUBLICATION supabase_realtime ADD TABLE signals_v9;
    ALTER PUBLICATION supabase_realtime ADD TABLE market_feelings;
EXCEPTION WHEN others THEN NULL; END $$;

-- ═══════════════════════════════════════════════════
-- 18. DEFAULT ADMIN USER
-- ═══════════════════════════════════════════════════
INSERT INTO users (email, password_hash, full_name, role, tier, is_active, is_verified)
VALUES (
    'admin@estrading.machine',
    encode(sha256('EstradingV10Admin!2026')::bytea, 'hex'),
    'estrading.machine Admin',
    'admin', 'platinum', TRUE, TRUE
) ON CONFLICT (email) DO NOTHING;

COMMIT;

-- ══════════════════════════════════════════════════
-- AFTER RUNNING: Enable Realtime in Supabase Dashboard
-- Database → Replication → Toggle ON for:
-- bots, trades, notifications, signals_v9, market_feelings
--
-- Default Admin Login:
-- Email:    admin@estrading.machine
-- Password: EstradingV10Admin!2026
-- ⚠️  CHANGE PASSWORD IMMEDIATELY AFTER FIRST LOGIN!
-- ══════════════════════════════════════════════════
