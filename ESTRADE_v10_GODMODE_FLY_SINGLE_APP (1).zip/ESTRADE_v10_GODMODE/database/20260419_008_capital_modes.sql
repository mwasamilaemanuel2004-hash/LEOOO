-- ESTRADE v6 Capital Modes Migration (008)
CREATE TABLE IF NOT EXISTS bot_capital_modes (
    id         uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    bot_id     uuid, user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
    mode       text DEFAULT 'safe',
    updated_at timestamptz DEFAULT now(),
    UNIQUE(bot_id, user_id)
);
CREATE TABLE IF NOT EXISTS bot_mode_logs (
    id         uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    bot_id     uuid, user_id uuid REFERENCES auth.users(id),
    mode       text, changed_at timestamptz DEFAULT now()
);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS mode_key   text DEFAULT 'safe';
ALTER TABLE trades ADD COLUMN IF NOT EXISTS explainability jsonb;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS rule_conf  numeric(5,2);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS ml_score   numeric(5,4);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS regime     text;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS ai_reason  text;

ALTER TABLE bot_capital_modes ENABLE ROW LEVEL SECURITY;
ALTER TABLE bot_mode_logs     ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own_capital_modes" ON bot_capital_modes FOR ALL USING (auth.uid()=user_id);
CREATE POLICY "own_mode_logs"     ON bot_mode_logs     FOR SELECT USING (auth.uid()=user_id);
CREATE INDEX IF NOT EXISTS idx_trades_mode_key ON trades(mode_key, user_id);
