-- ═══════════════════════════════════════════════════════════════════════════
-- ESTRADE v9 GODMODE — COMPLETE SQL MIGRATION
-- Combines ALL migrations: v8 base + v8.2 bots + v8.3 money + v9 new
-- Run in Supabase SQL Editor as ONE script after fresh project creation
-- ═══════════════════════════════════════════════════════════════════════════

BEGIN;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ═══════════════════════════════════════
-- V9 NEW TABLES
-- ═══════════════════════════════════════

-- Market feeling readings
CREATE TABLE IF NOT EXISTS market_feelings (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    symbol           TEXT NOT NULL,
    emotion          TEXT NOT NULL CHECK (emotion IN ('euphoria','greed','optimism','neutral','anxiety','fear','panic')),
    emotion_score    NUMERIC(6,2),
    confidence       NUMERIC(6,2),
    technical_score  NUMERIC(6,2),
    volume_score     NUMERIC(6,2),
    funding_score    NUMERIC(6,2),
    orderbook_score  NUMERIC(6,2),
    momentum_score   NUMERIC(6,2),
    volatility_score NUMERIC(6,2),
    trade_signal     TEXT,
    size_multiplier  NUMERIC(6,3),
    entry_note       TEXT,
    rsi              NUMERIC(6,2),
    funding_rate     NUMERIC(10,6),
    vol_ratio        NUMERIC(8,4),
    atr_pct          NUMERIC(10,6),
    created_at       TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_mf_sym  ON market_feelings(symbol, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_mf_emo  ON market_feelings(emotion, created_at DESC);

-- Engine vote log
CREATE TABLE IF NOT EXISTS engine_votes (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bot_id         UUID REFERENCES bots(id),
    trade_id       UUID REFERENCES trades(id),
    symbol         TEXT NOT NULL,
    -- Vote tally
    total_engines  INTEGER,
    agree_count    INTEGER,
    dissent_count  INTEGER,
    direction      TEXT,
    confidence     NUMERIC(6,2),
    -- Per-engine votes
    ultra_brain_vote  TEXT,
    lstm_vote         TEXT,
    transformer_vote  TEXT,
    rl_vote           TEXT,
    feeling_vote      TEXT,
    evolver_vote      TEXT,
    whale_vote        TEXT,
    analyst_vote      TEXT,
    hybrid_brain_vote TEXT,
    -- Decision
    approved         BOOLEAN,
    reject_reason    TEXT,
    latency_ms       NUMERIC(8,2),
    created_at       TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_ev_bot  ON engine_votes(bot_id, created_at DESC);

-- Capital maximizer state per bot per user
CREATE TABLE IF NOT EXISTS capital_max_state (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id),
    bot_id          UUID REFERENCES bots(id),
    bot_key         TEXT NOT NULL,
    balance         NUMERIC(20,8) DEFAULT 0,
    peak_balance    NUMERIC(20,8) DEFAULT 0,
    compound_pool   NUMERIC(20,8) DEFAULT 0,
    total_compounded NUMERIC(20,8) DEFAULT 0,
    cons_wins       INTEGER DEFAULT 0,
    cons_losses     INTEGER DEFAULT 0,
    pyramid_level   INTEGER DEFAULT 0,
    daily_pnl_pct   NUMERIC(10,4) DEFAULT 0,
    session_pnl_pct NUMERIC(10,4) DEFAULT 0,
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, bot_key)
);
ALTER TABLE capital_max_state ENABLE ROW LEVEL SECURITY;
CREATE POLICY cms_user ON capital_max_state USING (user_id = auth.uid());

-- V9 Trade decisions log (full AI context per trade)
CREATE TABLE IF NOT EXISTS trade_decisions_v9 (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id),
    bot_id          UUID REFERENCES bots(id),
    trade_id        UUID REFERENCES trades(id),
    symbol          TEXT,
    direction       TEXT,
    confidence      NUMERIC(6,2),
    size_usd        NUMERIC(20,4),
    capital_pct     NUMERIC(6,2),
    compound_bonus  NUMERIC(20,4),
    engines_voted   INTEGER,
    engines_agree   INTEGER,
    emotion         TEXT,
    feeling_boost   NUMERIC(6,3),
    whale_aligned   BOOLEAN,
    special_strategy TEXT,
    special_codename TEXT,
    special_edge    TEXT,
    vote_breakdown  JSONB DEFAULT '{}',
    feeling_data    JSONB DEFAULT '{}',
    pnl_pct         NUMERIC(10,4),
    pnl_usd         NUMERIC(20,8),
    outcome         TEXT CHECK (outcome IN ('win','loss','open','cancelled')),
    latency_ms      NUMERIC(8,2),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_tdv9_user ON trade_decisions_v9(user_id, created_at DESC);
ALTER TABLE trade_decisions_v9 ENABLE ROW LEVEL SECURITY;
CREATE POLICY tdv9_user ON trade_decisions_v9 USING (user_id = auth.uid());

-- Emotion performance (which feelings lead to best outcomes)
CREATE TABLE IF NOT EXISTS emotion_performance (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID REFERENCES users(id),
    emotion     TEXT NOT NULL,
    wins        INTEGER DEFAULT 0,
    losses      INTEGER DEFAULT 0,
    total_pnl   NUMERIC(20,8) DEFAULT 0,
    avg_pnl_pct NUMERIC(10,4) DEFAULT 0,
    best_trade  NUMERIC(10,4),
    worst_trade NUMERIC(10,4),
    updated_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, emotion)
);
ALTER TABLE emotion_performance ENABLE ROW LEVEL SECURITY;
CREATE POLICY ep_user ON emotion_performance USING (user_id = auth.uid());

-- Special strategy performance
CREATE TABLE IF NOT EXISTS strategy_performance (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id),
    bot_key         TEXT NOT NULL,
    strategy_name   TEXT NOT NULL,
    codename        TEXT,
    wins            INTEGER DEFAULT 0,
    losses          INTEGER DEFAULT 0,
    total_pnl       NUMERIC(20,8) DEFAULT 0,
    avg_pnl_pct     NUMERIC(10,4) DEFAULT 0,
    best_emotion    TEXT,
    feeling_boosts  JSONB DEFAULT '{}',
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, bot_key)
);
ALTER TABLE strategy_performance ENABLE ROW LEVEL SECURITY;
CREATE POLICY sp_user ON strategy_performance USING (user_id = auth.uid());

-- ═══════════════════════════════════════
-- VIEWS FOR ANALYTICS
-- ═══════════════════════════════════════

CREATE OR REPLACE VIEW emotion_trading_stats AS
SELECT
    emotion,
    COUNT(*) as total_readings,
    AVG(emotion_score) as avg_score,
    AVG(confidence) as avg_confidence,
    COUNT(*) FILTER (WHERE trade_signal != 'neutral') as signals_emitted,
    MAX(created_at) as last_seen
FROM market_feelings
GROUP BY emotion
ORDER BY AVG(emotion_score) DESC;

CREATE OR REPLACE VIEW v9_engine_agreement AS
SELECT
    symbol,
    DATE_TRUNC('hour', created_at) as hour,
    AVG(agree_count::float / NULLIF(total_engines,0)) as avg_agreement_rate,
    AVG(confidence) as avg_confidence,
    COUNT(*) FILTER (WHERE approved) as approved_trades,
    COUNT(*) as total_decisions
FROM engine_votes
GROUP BY symbol, DATE_TRUNC('hour', created_at)
ORDER BY hour DESC;

CREATE OR REPLACE VIEW capital_compound_growth AS
SELECT
    user_id,
    bot_key,
    SUM(profit_usd) as total_profit,
    SUM(compounded_usd) as total_compounded,
    MAX(running_total) as cumulative_compounded,
    COUNT(DISTINCT snapshot_date) as days_active,
    MAX(multiplier) as max_multiplier
FROM compound_tracker
GROUP BY user_id, bot_key
ORDER BY total_compounded DESC;

-- ═══════════════════════════════════════
-- FUNCTIONS
-- ═══════════════════════════════════════

-- Record emotion outcome
CREATE OR REPLACE FUNCTION record_emotion_outcome(
    p_user_id UUID, p_emotion TEXT, p_pnl NUMERIC, p_won BOOLEAN
) RETURNS VOID AS $$
BEGIN
    INSERT INTO emotion_performance(user_id, emotion, wins, losses, total_pnl)
    VALUES(p_user_id, p_emotion,
           CASE WHEN p_won THEN 1 ELSE 0 END,
           CASE WHEN p_won THEN 0 ELSE 1 END,
           p_pnl)
    ON CONFLICT(user_id, emotion) DO UPDATE SET
        wins      = emotion_performance.wins      + CASE WHEN p_won THEN 1 ELSE 0 END,
        losses    = emotion_performance.losses    + CASE WHEN p_won THEN 0 ELSE 1 END,
        total_pnl = emotion_performance.total_pnl + p_pnl,
        avg_pnl_pct = (emotion_performance.total_pnl + p_pnl) /
                      NULLIF(emotion_performance.wins + emotion_performance.losses + 1, 0),
        updated_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Get top performing emotions for a user
CREATE OR REPLACE FUNCTION get_top_emotions(p_user_id UUID)
RETURNS TABLE(emotion TEXT, avg_pnl NUMERIC, win_rate NUMERIC, total INT) AS $$
    SELECT emotion,
           avg_pnl_pct,
           ROUND(wins::NUMERIC / NULLIF(wins+losses,0) * 100, 1),
           wins + losses
    FROM emotion_performance
    WHERE user_id = p_user_id
    ORDER BY avg_pnl_pct DESC;
$$ LANGUAGE SQL SECURITY DEFINER;

-- ═══════════════════════════════════════
-- REALTIME
-- ═══════════════════════════════════════
DO $$
BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE market_feelings;
    ALTER PUBLICATION supabase_realtime ADD TABLE trade_decisions_v9;
    ALTER PUBLICATION supabase_realtime ADD TABLE engine_votes;
    ALTER PUBLICATION supabase_realtime ADD TABLE capital_max_state;
EXCEPTION WHEN others THEN NULL;
END $$;

COMMIT;

-- ═══════════════════════════════════════
-- QUICK START GUIDE:
-- 1. Run v8_migration.sql first (creates base tables)
-- 2. Run v8_2_new_bots_migration.sql (adds new bots + descriptions)
-- 3. Run v8_3_money_printing.sql (adds profit tracking)
-- 4. Run THIS file (v9_godmode_migration.sql) last
-- All 4 files give you complete v9 database
-- ═══════════════════════════════════════
