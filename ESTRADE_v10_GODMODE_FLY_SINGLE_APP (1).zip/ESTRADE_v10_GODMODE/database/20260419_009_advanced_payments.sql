-- ESTRADE v6 Advanced Payments + Auto-Trade Migration (009)

-- Double-entry ledger (immutable, hash-chained)
CREATE TABLE IF NOT EXISTS ledger_entries (
    id          uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id     uuid REFERENCES auth.users(id),
    debit       text, credit text, amount numeric(18,8),
    txn_type    text, description text, ref text,
    entry_hash  text UNIQUE, prev_hash text,
    immutable   boolean DEFAULT true,
    created_at  timestamptz DEFAULT now()
);

-- Fraud alerts
CREATE TABLE IF NOT EXISTS fraud_alerts (
    id        uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id   uuid REFERENCES auth.users(id),
    amount    numeric(18,4), flags jsonb, ip text,
    severity  text DEFAULT 'MEDIUM', reviewed boolean DEFAULT false,
    created_at timestamptz DEFAULT now()
);

-- Auto-withdrawal config
CREATE TABLE IF NOT EXISTS auto_withdrawal_config (
    id            uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id       uuid REFERENCES auth.users(id) UNIQUE,
    threshold_usd numeric(18,4), method text, phone text,
    is_active     boolean DEFAULT false,
    updated_at    timestamptz DEFAULT now()
);

-- Wallet snapshots (for drawdown calc)
CREATE TABLE IF NOT EXISTS wallet_snapshots (
    id         uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id    uuid REFERENCES auth.users(id),
    balance    numeric(18,8),
    created_at timestamptz DEFAULT now()
);

-- Auto-snapshot every hour via trigger
CREATE OR REPLACE FUNCTION snapshot_wallet_balance()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO wallet_snapshots(user_id, balance)
    VALUES(NEW.user_id, NEW.balance)
    ON CONFLICT DO NOTHING;
    RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS trg_wallet_snapshot ON wallets;
CREATE TRIGGER trg_wallet_snapshot
    AFTER UPDATE OF balance ON wallets
    FOR EACH ROW EXECUTE FUNCTION snapshot_wallet_balance();

-- RLS
ALTER TABLE ledger_entries           ENABLE ROW LEVEL SECURITY;
ALTER TABLE fraud_alerts             ENABLE ROW LEVEL SECURITY;
ALTER TABLE auto_withdrawal_config   ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet_snapshots         ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own_ledger"     ON ledger_entries           FOR SELECT USING (auth.uid()=user_id);
CREATE POLICY "own_autowith"   ON auto_withdrawal_config   FOR ALL    USING (auth.uid()=user_id);
CREATE POLICY "own_snapshots"  ON wallet_snapshots         FOR SELECT USING (auth.uid()=user_id);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_ledger_user    ON ledger_entries(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wallet_snap    ON wallet_snapshots(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_fraud_user     ON fraud_alerts(user_id, created_at DESC);
