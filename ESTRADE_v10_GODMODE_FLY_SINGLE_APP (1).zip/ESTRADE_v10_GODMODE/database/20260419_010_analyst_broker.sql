-- ESTRADE v6 Analyst + Broker + Bot Upgrades (010)

CREATE TABLE IF NOT EXISTS trade_analyses (
    id              uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    trade_id        uuid, bot_id text, user_id uuid REFERENCES auth.users(id),
    headline        text, reasoning text, recommendation text,
    risk_level      text DEFAULT 'MEDIUM',
    risk_factors    jsonb DEFAULT '[]',
    signal_sources  jsonb DEFAULT '[]',
    ai_confidence   numeric(5,2) DEFAULT 0,
    ai_tier         text DEFAULT 'silver',
    win_probability numeric(5,2) DEFAULT 50,
    rr_ratio        numeric(5,2) DEFAULT 1,
    scenarios       jsonb DEFAULT '{}',
    top_features    jsonb DEFAULT '{}',
    full_analysis   jsonb DEFAULT '{}',
    created_at      timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS bot_upgrades (
    id          uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id     uuid REFERENCES auth.users(id),
    bot_id      text, ai_tier text,
    cost_paid   numeric(10,4) DEFAULT 0,
    upgraded_at timestamptz DEFAULT now(),
    UNIQUE(user_id, bot_id)
);

CREATE TABLE IF NOT EXISTS security_alerts (
    id         uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id    uuid REFERENCES auth.users(id),
    bot_id     text, severity text,
    alerts     jsonb DEFAULT '[]',
    actions    jsonb DEFAULT '[]',
    resolved   boolean DEFAULT false,
    created_at timestamptz DEFAULT now()
);

-- RLS
ALTER TABLE trade_analyses  ENABLE ROW LEVEL SECURITY;
ALTER TABLE bot_upgrades    ENABLE ROW LEVEL SECURITY;
ALTER TABLE security_alerts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own_analyses" ON trade_analyses  FOR ALL USING (auth.uid()=user_id);
CREATE POLICY "own_upgrades" ON bot_upgrades    FOR ALL USING (auth.uid()=user_id);
CREATE POLICY "own_alerts"   ON security_alerts FOR ALL USING (auth.uid()=user_id);

CREATE INDEX IF NOT EXISTS idx_analyses_user ON trade_analyses(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_upgrades_user ON bot_upgrades(user_id,bot_id);
CREATE INDEX IF NOT EXISTS idx_alerts_user   ON security_alerts(user_id,created_at DESC);
