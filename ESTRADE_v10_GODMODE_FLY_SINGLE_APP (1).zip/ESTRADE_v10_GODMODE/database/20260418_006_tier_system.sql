-- ESTRADE v6 Tier System Migration (006) - Run after 005

ALTER TABLE subscriptions
  ADD COLUMN IF NOT EXISTS tier              text DEFAULT 'gold',
  ADD COLUMN IF NOT EXISTS per_trade_fee     numeric(10,4) DEFAULT 0.01,
  ADD COLUMN IF NOT EXISTS profit_share_pct  numeric(5,2)  DEFAULT 0,
  ADD COLUMN IF NOT EXISTS auto_renew        boolean DEFAULT false;

CREATE TABLE IF NOT EXISTS signal_providers (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid REFERENCES auth.users(id),
    name text NOT NULL, avatar text, bio text,
    win_rate numeric(5,2) DEFAULT 0, total_trades int DEFAULT 0,
    total_profit numeric(18,4) DEFAULT 0, sharpe_ratio numeric(6,4) DEFAULT 0,
    subscribers int DEFAULT 0, verified boolean DEFAULT false,
    is_active boolean DEFAULT true, created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS royal_iq_signals (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    provider_id uuid REFERENCES signal_providers(id),
    symbol text, action text, entry_price numeric(18,8),
    stop_loss numeric(18,8), take_profit numeric(18,8),
    confidence numeric(5,2) DEFAULT 70, timeframe text DEFAULT '1h',
    reasoning text, risk_level text DEFAULT 'moderate',
    status text DEFAULT 'active', copy_count int DEFAULT 0,
    expires_at timestamptz, created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS royal_iq_copies (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid REFERENCES auth.users(id),
    signal_id uuid REFERENCES royal_iq_signals(id),
    risk_level text DEFAULT 'moderate', risk_pct numeric(5,2) DEFAULT 1.5,
    position_usd numeric(18,4) DEFAULT 0, entry_price numeric(18,8),
    pnl numeric(18,8), status text DEFAULT 'pending',
    created_at timestamptz DEFAULT now(), closed_at timestamptz
);

CREATE TABLE IF NOT EXISTS royal_iq_auto_copy (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid REFERENCES auth.users(id) UNIQUE,
    provider_id uuid REFERENCES signal_providers(id),
    risk_level text DEFAULT 'moderate', allocation_pct numeric(5,2) DEFAULT 1.5,
    max_per_day int DEFAULT 5, min_confidence numeric(5,2) DEFAULT 70,
    is_active boolean DEFAULT false, created_at timestamptz DEFAULT now()
);

ALTER TABLE trade_fees
  ADD COLUMN IF NOT EXISTS tier text DEFAULT 'gold',
  ADD COLUMN IF NOT EXISTS maintenance_fee numeric(18,8) DEFAULT 0.01;

CREATE OR REPLACE FUNCTION auto_accrue_trade_fee()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE v_tier text; v_ptf numeric; v_psp numeric; v_ps numeric;
BEGIN
    IF NEW.status='closed' AND OLD.status='open' AND COALESCE(NEW.mode,'demo')='live' THEN
        SELECT COALESCE(tier,'gold'),COALESCE(per_trade_fee,0.01),COALESCE(profit_share_pct,0)
        INTO v_tier,v_ptf,v_psp FROM subscriptions
        WHERE user_id=NEW.user_id AND status='active' ORDER BY created_at DESC LIMIT 1;
        v_ps := CASE WHEN COALESCE(NEW.net_pnl,0)>0 THEN NEW.net_pnl*COALESCE(v_psp,0)/100 ELSE 0 END;
        INSERT INTO trade_fees(user_id,trade_id,symbol,side,notional,gross_pnl,net_pnl,
            platform_fee,profit_share,total_fee,collected,fee_period,tier,maintenance_fee)
        VALUES(NEW.user_id,NEW.id,NEW.symbol,NEW.side,COALESCE(NEW.notional_value,0),
            COALESCE(NEW.gross_pnl,0),COALESCE(NEW.net_pnl,0),COALESCE(v_ptf,0.01),v_ps,
            COALESCE(v_ptf,0.01)+v_ps,false,TO_CHAR(now(),'YYYY-MM'),
            COALESCE(v_tier,'gold'),COALESCE(v_ptf,0.01)) ON CONFLICT DO NOTHING;
    END IF; RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS trg_auto_accrue_fee ON trades;
CREATE TRIGGER trg_auto_accrue_fee AFTER UPDATE OF status ON trades
FOR EACH ROW EXECUTE FUNCTION auto_accrue_trade_fee();

CREATE OR REPLACE VIEW v_user_fees AS
SELECT u.id AS user_id, COALESCE(s.tier,'gold') AS tier,
    COALESCE(s.per_trade_fee,0.01) AS per_trade_fee,
    COALESCE(s.profit_share_pct,0) AS profit_share_pct,
    COALESCE(s.monthly_fee,0) AS monthly_fee,
    COALESCE(tf.maint,0) AS total_maintenance,
    COALESCE(tf.ps,0) AS total_profit_share,
    COALESCE(sf.sub,0) AS total_subscription,
    COALESCE(tf.maint,0)+COALESCE(tf.ps,0)+COALESCE(sf.sub,0) AS grand_total,
    COALESCE(tf.cnt,0) AS uncollected_trades
FROM auth.users u
LEFT JOIN subscriptions s ON s.user_id=u.id AND s.status='active'
LEFT JOIN (SELECT user_id,SUM(maintenance_fee) AS maint,SUM(profit_share) AS ps,COUNT(*) AS cnt
    FROM trade_fees WHERE collected=false GROUP BY user_id) tf ON tf.user_id=u.id
LEFT JOIN (SELECT user_id,SUM(amount) AS sub FROM subscription_fees
    WHERE collected=false GROUP BY user_id) sf ON sf.user_id=u.id;

ALTER TABLE signal_providers    ENABLE ROW LEVEL SECURITY;
ALTER TABLE royal_iq_signals    ENABLE ROW LEVEL SECURITY;
ALTER TABLE royal_iq_copies     ENABLE ROW LEVEL SECURITY;
ALTER TABLE royal_iq_auto_copy  ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public_providers" ON signal_providers FOR SELECT USING (true);
CREATE POLICY "public_signals"   ON royal_iq_signals FOR SELECT USING (true);
CREATE POLICY "own_copies"       ON royal_iq_copies  FOR ALL USING (auth.uid()=user_id);
CREATE POLICY "own_autocopy"     ON royal_iq_auto_copy FOR ALL USING (auth.uid()=user_id);

CREATE INDEX IF NOT EXISTS idx_iq_signals_active ON royal_iq_signals(status,expires_at DESC);
CREATE INDEX IF NOT EXISTS idx_iq_copies_user    ON royal_iq_copies(user_id,created_at DESC);
