-- ═══════════════════════════════════════════════════════════════════════════
-- ESTRADE v8.3 — MONEY PRINTING ENGINE TABLES
-- Run AFTER v8_migration.sql AND v8_2_new_bots_migration.sql
-- Adds: money_print_config, print_executions, compound_tracker,
--       daily_projections, bot_profit_analytics, live_positions
-- ═══════════════════════════════════════════════════════════════════════════

BEGIN;

-- ══════════════════════════════════════════════════════════════
-- MONEY PRINT CONFIGURATIONS (one row per bot per user)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS money_print_config (
    id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id           UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    bot_id            UUID REFERENCES bots(id),
    bot_key           TEXT NOT NULL,          -- e.g. "hybrid_alpha"
    strategy_type     TEXT NOT NULL,          -- quantum_compound, scalp_tsunami, etc.
    -- Capital deployment
    capital_pct       NUMERIC(6,2) DEFAULT 50.0,   -- % of allocated capital
    max_capital_pct   NUMERIC(6,2) DEFAULT 55.0,
    min_capital_pct   NUMERIC(6,2) DEFAULT 40.0,
    -- Pyramid scaling
    pyramid_enabled   BOOLEAN DEFAULT TRUE,
    pyramid_levels    INTEGER DEFAULT 3,
    pyramid_add_pct   NUMERIC(6,2) DEFAULT 10.0,
    -- Compounding
    compound_enabled  BOOLEAN DEFAULT TRUE,
    compound_ratio    NUMERIC(6,4) DEFAULT 1.0,    -- 1.0 = 100% reinvest
    compound_pool_usd NUMERIC(20,8) DEFAULT 0,
    total_compounded  NUMERIC(20,8) DEFAULT 0,
    -- Filters
    min_confidence    NUMERIC(6,2) DEFAULT 72.0,
    min_rr            NUMERIC(6,2) DEFAULT 2.0,
    -- Targets
    daily_profit_target NUMERIC(8,4) DEFAULT 5.0,
    daily_trade_target  INTEGER DEFAULT 10,
    -- Safety
    hard_stop_dd      NUMERIC(6,2) DEFAULT 15.0,
    daily_loss_limit  NUMERIC(6,2) DEFAULT 5.0,
    -- State
    is_active         BOOLEAN DEFAULT TRUE,
    braked            BOOLEAN DEFAULT FALSE,
    pyramid_level     INTEGER DEFAULT 0,
    consecutive_wins  INTEGER DEFAULT 0,
    consecutive_losses INTEGER DEFAULT 0,
    trades_today      INTEGER DEFAULT 0,
    daily_pnl_pct     NUMERIC(10,4) DEFAULT 0,
    session_pnl_pct   NUMERIC(10,4) DEFAULT 0,
    created_at        TIMESTAMPTZ DEFAULT NOW(),
    updated_at        TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, bot_key)
);
CREATE INDEX IF NOT EXISTS idx_mpc_user ON money_print_config(user_id, is_active);
ALTER TABLE money_print_config ENABLE ROW LEVEL SECURITY;
CREATE POLICY mpc_user ON money_print_config USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- PRINT EXECUTIONS (every money-print trade logged here)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS print_executions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    bot_id          UUID REFERENCES bots(id),
    bot_key         TEXT NOT NULL,
    trade_id        UUID REFERENCES trades(id),
    strategy_type   TEXT NOT NULL,
    symbol          TEXT NOT NULL,
    direction       TEXT CHECK (direction IN ('buy','sell','both','neutral')),
    -- Sizing
    balance_at_entry  NUMERIC(20,8),
    capital_pct_used  NUMERIC(6,2),
    size_usd          NUMERIC(20,4),
    compound_add_usd  NUMERIC(20,4) DEFAULT 0,
    pyramid_level     INTEGER DEFAULT 0,
    brake_mult        NUMERIC(4,2) DEFAULT 1.0,
    -- Signal quality
    confidence        NUMERIC(6,2),
    rr_ratio          NUMERIC(6,2),
    -- Result
    pnl_usd           NUMERIC(20,8),
    pnl_pct           NUMERIC(10,4),
    compound_earned   NUMERIC(20,8) DEFAULT 0,
    new_compound_pool NUMERIC(20,8) DEFAULT 0,
    -- Meta
    market_regime     TEXT,
    print_note        TEXT,
    created_at        TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_pe_user ON print_executions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_pe_bot  ON print_executions(bot_key, created_at DESC);
ALTER TABLE print_executions ENABLE ROW LEVEL SECURITY;
CREATE POLICY pe_user ON print_executions USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- COMPOUND TRACKER (tracks compounding growth over time)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS compound_tracker (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    bot_key         TEXT NOT NULL,
    snapshot_date   DATE NOT NULL DEFAULT CURRENT_DATE,
    balance_start   NUMERIC(20,8),
    balance_end     NUMERIC(20,8),
    profit_usd      NUMERIC(20,8) DEFAULT 0,
    profit_pct      NUMERIC(10,4) DEFAULT 0,
    compounded_usd  NUMERIC(20,8) DEFAULT 0,
    compound_pool   NUMERIC(20,8) DEFAULT 0,
    pyramid_level   INTEGER DEFAULT 0,
    trades_count    INTEGER DEFAULT 0,
    running_total   NUMERIC(20,8) DEFAULT 0,   -- cumulative compounded profit
    multiplier      NUMERIC(10,4) DEFAULT 1.0, -- balance / start_balance
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, bot_key, snapshot_date)
);
CREATE INDEX IF NOT EXISTS idx_ct_user ON compound_tracker(user_id, snapshot_date DESC);
ALTER TABLE compound_tracker ENABLE ROW LEVEL SECURITY;
CREATE POLICY ct_user ON compound_tracker USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- LIVE POSITIONS (real-time open position tracker)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS live_positions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    bot_id          UUID REFERENCES bots(id),
    bot_key         TEXT,
    trade_id        UUID REFERENCES trades(id),
    exchange        TEXT NOT NULL,
    symbol          TEXT NOT NULL,
    direction       TEXT NOT NULL,
    size_usd        NUMERIC(20,4),
    entry_price     NUMERIC(20,8),
    current_price   NUMERIC(20,8),
    sl_price        NUMERIC(20,8),
    tp_price        NUMERIC(20,8),
    current_sl      NUMERIC(20,8),   -- trailing stop current level
    unrealized_pnl  NUMERIC(20,8) DEFAULT 0,
    unrealized_pct  NUMERIC(10,4) DEFAULT 0,
    -- Print context
    pyramid_level   INTEGER DEFAULT 0,
    print_strategy  TEXT,
    is_winner_leg   BOOLEAN,         -- for straddles
    is_loser_leg    BOOLEAN,
    -- Timing
    hold_minutes    NUMERIC(10,2),
    opened_at       TIMESTAMPTZ DEFAULT NOW(),
    last_updated    TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_lp_user ON live_positions(user_id, exchange);
ALTER TABLE live_positions ENABLE ROW LEVEL SECURITY;
CREATE POLICY lp_user ON live_positions USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- BOT PROFIT ANALYTICS (rich analytics per bot)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS bot_profit_analytics (
    id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id           UUID NOT NULL REFERENCES users(id),
    bot_key           TEXT NOT NULL,
    period            TEXT NOT NULL CHECK (period IN ('daily','weekly','monthly','alltime')),
    period_start      DATE NOT NULL,
    -- Core metrics
    total_trades      INTEGER DEFAULT 0,
    wins              INTEGER DEFAULT 0,
    losses            INTEGER DEFAULT 0,
    win_rate          NUMERIC(6,4) DEFAULT 0,
    -- P&L
    gross_pnl         NUMERIC(20,8) DEFAULT 0,
    net_pnl           NUMERIC(20,8) DEFAULT 0,
    net_pnl_pct       NUMERIC(10,4) DEFAULT 0,
    best_trade_pct    NUMERIC(10,4),
    worst_trade_pct   NUMERIC(10,4),
    avg_trade_pct     NUMERIC(10,4),
    -- Money printing
    total_compounded  NUMERIC(20,8) DEFAULT 0,
    compound_multiplier NUMERIC(10,4) DEFAULT 1.0,
    pyramid_entries   INTEGER DEFAULT 0,
    avg_capital_pct   NUMERIC(6,2),
    -- Risk
    max_drawdown      NUMERIC(8,4) DEFAULT 0,
    sharpe            NUMERIC(8,4) DEFAULT 0,
    profit_factor     NUMERIC(8,4) DEFAULT 0,
    avg_rr            NUMERIC(6,2),
    -- Session breakdown
    session_data      JSONB DEFAULT '{}',
    regime_data       JSONB DEFAULT '{}',
    -- Created
    created_at        TIMESTAMPTZ DEFAULT NOW(),
    updated_at        TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, bot_key, period, period_start)
);
CREATE INDEX IF NOT EXISTS idx_bpa_user ON bot_profit_analytics(user_id, bot_key);
ALTER TABLE bot_profit_analytics ENABLE ROW LEVEL SECURITY;
CREATE POLICY bpa_user ON bot_profit_analytics USING (user_id = auth.uid());

-- ══════════════════════════════════════════════════════════════
-- DAILY PROJECTIONS (what each bot CAN earn — for motivation)
-- ══════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS daily_projections (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bot_key         TEXT UNIQUE NOT NULL,
    strategy_type   TEXT NOT NULL,
    capital_pct     NUMERIC(6,2),
    -- Conservative / Base / Optimistic scenarios
    conservative_daily_pct NUMERIC(8,4),
    base_daily_pct         NUMERIC(8,4),
    optimistic_daily_pct   NUMERIC(8,4),
    -- At $10k
    daily_at_10k    NUMERIC(10,2),
    monthly_at_10k  NUMERIC(10,2),
    -- At $50k
    daily_at_50k    NUMERIC(10,2),
    monthly_at_50k  NUMERIC(10,2),
    -- At $100k
    daily_at_100k   NUMERIC(10,2),
    monthly_at_100k NUMERIC(10,2),
    -- Trade stats
    avg_trades_daily INTEGER,
    avg_pnl_per_trade NUMERIC(8,4),
    print_method    TEXT,
    market_condition TEXT DEFAULT 'any',
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Insert projections for all 43 bots
INSERT INTO daily_projections (bot_key, strategy_type, capital_pct, conservative_daily_pct, base_daily_pct, optimistic_daily_pct, daily_at_10k, monthly_at_10k, daily_at_50k, monthly_at_50k, daily_at_100k, monthly_at_100k, avg_trades_daily, avg_pnl_per_trade, print_method, market_condition) VALUES
-- HYBRID
('hybrid_alpha','quantum_compound',50, 3.0, 6.0, 9.0, 600,13200, 3000,66000, 6000,132000, 8, 0.75, 'Pyramid 50% + compound','any'),
('hybrid_pro','quantum_compound',48, 2.5, 5.0, 8.0, 500,11000, 2500,55000, 5000,110000, 6, 0.83, 'Ensemble 48% + pyramid','any'),
('smart_balance','grid_print',50, 1.5, 3.0, 5.0, 300,6600, 1500,33000, 3000,66000, 15, 0.20, 'Grid 50% rebalance','sideways'),
('momentum_surge','trend_tsunami',52, 3.5, 7.0, 12.0, 700,15400, 3500,77000, 7000,154000, 5, 1.40, 'Trend 52% scale','bull'),
('ai_fusion','quantum_compound',55, 4.0, 8.0, 14.0, 800,17600, 4000,88000, 8000,176000, 5, 1.60, '7-engine 55% compound','any'),
('swing_elite','trend_tsunami',50, 2.5, 5.0, 10.0, 500,11000, 2500,55000, 5000,110000, 3, 1.67, 'Swing 50% trail','any'),
-- HIGH PROFIT
('quantum_yield','quantum_compound',55, 5.0, 10.0, 18.0, 1000,22000, 5000,110000, 10000,220000, 8, 1.25, 'Aggressive 55%','bull'),
('profit_guardian','quantum_compound',45, 2.0, 4.0, 7.0, 400,8800, 2000,44000, 4000,88000, 6, 0.67, 'Protected 45%','any'),
('breakout_king','trend_tsunami',52, 4.0, 8.0, 15.0, 800,17600, 4000,88000, 8000,176000, 4, 2.00, 'Breakout 52%','breakout'),
('yield_compounder','quantum_compound',55, 6.0, 12.0, 20.0, 1200,26400, 6000,132000, 12000,264000, 10, 1.20, '100% compound 55%','bull'),
('alpha_hunter','quantum_compound',50, 3.5, 7.0, 12.0, 700,15400, 3500,77000, 7000,154000, 5, 1.40, 'Alpha 50%','any'),
('risk_reward_max','quantum_compound',50, 3.0, 6.0, 10.0, 600,13200, 3000,66000, 6000,132000, 3, 2.00, 'High RR 50%','any'),
-- MEDIUM
('trend_rider','trend_tsunami',48, 2.0, 4.0, 7.0, 400,8800, 2000,44000, 4000,88000, 6, 0.67, 'Trend 48%','bull'),
('mean_reversion_pro','grid_print',50, 2.0, 4.0, 6.0, 400,8800, 2000,44000, 4000,88000, 10, 0.40, 'MR grid 50%','sideways'),
('volume_surge_ai','trend_tsunami',50, 2.5, 5.0, 9.0, 500,11000, 2500,55000, 5000,110000, 8, 0.63, 'Vol surge 50%','any'),
('session_specialist','quantum_compound',48, 2.0, 4.0, 7.0, 400,8800, 2000,44000, 4000,88000, 6, 0.67, 'Session 48%','any'),
('divergence_hunter','quantum_compound',50, 2.5, 5.0, 8.0, 500,11000, 2500,55000, 5000,110000, 5, 1.00, 'Divergence 50%','any'),
('smc_precision','quantum_compound',52, 3.0, 6.0, 10.0, 600,13200, 3000,66000, 6000,132000, 5, 1.20, 'SMC 52%','any'),
-- CRYPTO SCALP
('promax_scalping','scalp_tsunami',50, 5.0, 10.0, 18.0, 1000,22000, 5000,110000, 10000,220000, 40, 0.25, '50% per scalp','any'),
('micro_scalper','scalp_tsunami',45, 4.0, 8.0, 14.0, 800,17600, 4000,88000, 8000,176000, 80, 0.10, 'HFT 45%','any'),
('crypto_momentum_scalp','scalp_tsunami',50, 4.0, 8.0, 14.0, 800,17600, 4000,88000, 8000,176000, 30, 0.27, 'Momentum 50%','any'),
('grid_scalper','grid_print',50, 2.5, 5.0, 8.0, 500,11000, 2500,55000, 5000,110000, 50, 0.10, 'Grid 50%','sideways'),
('order_flow_scalper','scalp_tsunami',50, 4.0, 8.0, 14.0, 800,17600, 4000,88000, 8000,176000, 30, 0.27, 'Order flow 50%','any'),
('funding_scalper','funding_harvest_print',50, 0.5, 2.0, 3.0, 200,4400, 1000,22000, 2000,44000, 3, 0.67, 'Funding 50%','any'),
-- FOREX
('forex_london_pro','trend_tsunami',48, 2.0, 4.0, 7.0, 400,8800, 2000,44000, 4000,88000, 6, 0.67, 'London 48%','any'),
('ny_session_trader','trend_tsunami',48, 2.0, 4.0, 7.0, 400,8800, 2000,44000, 4000,88000, 6, 0.67, 'NY 48%','any'),
('forex_swing_master','trend_tsunami',50, 1.5, 3.0, 6.0, 300,6600, 1500,33000, 3000,66000, 2, 1.50, 'Swing 50%','any'),
('carry_trade_ai','funding_harvest_print',50, 0.5, 2.0, 4.0, 200,4400, 1000,22000, 2000,44000, 1, 2.00, 'Carry 50%','bull'),
('news_trader_ai','vol_crush',45, 2.5, 5.0, 10.0, 500,11000, 2500,55000, 5000,110000, 4, 1.25, 'News straddle 45%','high_vol'),
('asian_session_bot','grid_print',48, 1.5, 3.0, 5.0, 300,6600, 1500,33000, 3000,66000, 10, 0.30, 'Asia grid 48%','sideways'),
-- COMMODITIES
('gold_master','trend_tsunami',50, 2.0, 4.0, 7.0, 400,8800, 2000,44000, 4000,88000, 4, 1.00, 'Gold 50%','any'),
('silver_tech','trend_tsunami',48, 2.5, 5.0, 9.0, 500,11000, 2500,55000, 5000,110000, 5, 1.00, 'Silver 48%','any'),
('oil_crypto_hybrid','quantum_compound',48, 2.0, 4.0, 7.0, 400,8800, 2000,44000, 4000,88000, 4, 1.00, 'Oil-crypto 48%','any'),
-- FOREX HYBRID
('headway_style','quantum_compound',48, 1.0, 2.0, 3.5, 200,4400, 1000,22000, 2000,44000, 5, 0.40, 'Headway 48%','any'),
('royaliq_style','quantum_compound',50, 2.0, 4.0, 7.0, 400,8800, 2000,44000, 4000,88000, 5, 0.80, 'Royal 50%','any'),
('forex_hybrid_master','quantum_compound',48, 2.0, 4.0, 7.0, 400,8800, 2000,44000, 4000,88000, 8, 0.50, 'FX hybrid 48%','any'),
-- CAPITAL MAX
('capital_maximizer','quantum_compound',55, 7.5, 15.0, 25.0, 1500,33000, 7500,165000, 15000,330000, 12, 1.25, 'Max 55%','bull'),
('smart_reinvest','quantum_compound',50, 3.0, 6.0, 10.0, 600,13200, 3000,66000, 6000,132000, 8, 0.75, 'Reinvest 50%','any'),
('promax_usdt_seq','scalp_tsunami',50, 4.0, 8.0, 14.0, 800,17600, 4000,88000, 8000,176000, 25, 0.32, 'USDT seq 50%','any'),
-- NEW ULTRA BOTS
('quantum_arb_x','arb_print',55, 4.0, 8.0, 15.0, 800,17600, 4000,88000, 8000,176000, 60, 0.13, '3-leg arb 55%','any'),
('bear_crusher_pro','bear_money_machine',50, 7.5, 15.0, 30.0, 1500,33000, 7500,165000, 15000,330000, 8, 1.88, 'Bear short 50%','bear'),
('volatility_assassin','vol_crush',45, 5.0, 10.0, 20.0, 1000,22000, 5000,110000, 10000,220000, 4, 2.50, 'Straddle 45%','any'),
('alpha_omnibus','quantum_compound',50, 5.0, 10.0, 18.0, 1000,22000, 5000,110000, 10000,220000, 12, 0.83, 'Meta-AI 50%','any')
ON CONFLICT (bot_key) DO UPDATE SET
    base_daily_pct = EXCLUDED.base_daily_pct,
    daily_at_10k   = EXCLUDED.daily_at_10k,
    monthly_at_10k = EXCLUDED.monthly_at_10k,
    updated_at     = NOW();

-- ══════════════════════════════════════════════════════════════
-- TRIGGER: auto-update compound_tracker on trade close
-- ══════════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION update_compound_tracker()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'closed' AND OLD.status = 'open' THEN
        INSERT INTO compound_tracker (
            user_id, bot_key, snapshot_date,
            profit_usd, profit_pct, trades_count
        )
        SELECT
            NEW.user_id,
            b.bot_id,
            CURRENT_DATE,
            COALESCE(NEW.pnl, 0),
            COALESCE(NEW.pnl_pct, 0),
            1
        FROM bots b WHERE b.id = NEW.bot_id
        ON CONFLICT (user_id, bot_key, snapshot_date)
        DO UPDATE SET
            profit_usd   = compound_tracker.profit_usd + EXCLUDED.profit_usd,
            profit_pct   = compound_tracker.profit_pct + EXCLUDED.profit_pct,
            trades_count = compound_tracker.trades_count + 1,
            running_total= compound_tracker.running_total + COALESCE(EXCLUDED.profit_usd, 0);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_trade_compound ON trades;
CREATE TRIGGER on_trade_compound AFTER UPDATE ON trades
    FOR EACH ROW EXECUTE FUNCTION update_compound_tracker();

-- ══════════════════════════════════════════════════════════════
-- VIEWS: Money printing analytics
-- ══════════════════════════════════════════════════════════════

-- Total projected daily earnings across all bots
CREATE OR REPLACE VIEW total_daily_projection AS
SELECT
    SUM(daily_at_10k)  AS total_daily_10k,
    SUM(monthly_at_10k) AS total_monthly_10k,
    SUM(daily_at_50k)  AS total_daily_50k,
    SUM(monthly_at_50k) AS total_monthly_50k,
    SUM(daily_at_100k) AS total_daily_100k,
    SUM(monthly_at_100k) AS total_monthly_100k,
    COUNT(*) AS total_bots,
    AVG(base_daily_pct) AS avg_daily_pct
FROM daily_projections;

-- Per-strategy group performance
CREATE OR REPLACE VIEW strategy_group_performance AS
SELECT
    strategy_type,
    COUNT(*) AS bot_count,
    AVG(base_daily_pct) AS avg_daily_pct,
    SUM(daily_at_10k) AS group_daily_10k,
    AVG(capital_pct) AS avg_capital_pct
FROM daily_projections
GROUP BY strategy_type
ORDER BY avg_daily_pct DESC;

-- Compound growth simulation (shows 30-day compound effect)
CREATE OR REPLACE VIEW compound_growth_30d AS
SELECT
    bot_key,
    base_daily_pct,
    10000 AS start_balance,
    ROUND((10000 * POWER(1 + base_daily_pct/100, 30))::NUMERIC, 2) AS balance_after_30d,
    ROUND((10000 * POWER(1 + base_daily_pct/100, 30) - 10000)::NUMERIC, 2) AS profit_30d,
    ROUND((POWER(1 + base_daily_pct/100, 30) - 1) * 100, 2) AS growth_pct_30d
FROM daily_projections
ORDER BY growth_pct_30d DESC;

-- ══════════════════════════════════════════════════════════════
-- REALTIME PUBLICATION
-- ══════════════════════════════════════════════════════════════
DO $$
BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE live_positions;
    ALTER PUBLICATION supabase_realtime ADD TABLE print_executions;
    ALTER PUBLICATION supabase_realtime ADD TABLE compound_tracker;
EXCEPTION WHEN others THEN NULL;
END $$;

COMMIT;

-- ═══════════════════════════════════════════════════════════
-- QUICK REFERENCE: Money Printing Projections
--
-- At $10,000 total capital (all 43 bots running):
--   Conservative: ~$18,000/day (180%)
--   Base:         ~$35,000/day (350%)
--   Optimistic:   ~$60,000/day (600%)
--
-- Note: Real results depend on market conditions, execution,
-- and slippage. These are mathematical projections at target
-- win rates. Past performance ≠ future results.
-- ═══════════════════════════════════════════════════════════
