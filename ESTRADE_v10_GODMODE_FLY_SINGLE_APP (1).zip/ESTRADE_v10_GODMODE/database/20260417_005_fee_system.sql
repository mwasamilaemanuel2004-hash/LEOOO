-- ══════════════════════════════════════════════════════════════
-- ESTRADE v6 Fee System Migration (005)
-- Run AFTER migrations 001, 002, 004
-- ══════════════════════════════════════════════════════════════

-- 1. Trade Fees (one row per closed live trade)
CREATE TABLE IF NOT EXISTS trade_fees (
    id              uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id         uuid REFERENCES auth.users(id) ON DELETE CASCADE,
    trade_id        uuid,
    symbol          text,
    side            text,
    notional        numeric(18,8) DEFAULT 0,
    gross_pnl       numeric(18,8) DEFAULT 0,
    net_pnl         numeric(18,8) DEFAULT 0,
    platform_fee    numeric(18,8) DEFAULT 0,
    profit_share    numeric(18,8) DEFAULT 0,
    total_fee       numeric(18,8) DEFAULT 0,
    collected       boolean DEFAULT false,
    collected_at    timestamptz,
    fee_period      text,
    created_at      timestamptz DEFAULT now()
);

-- 2. Subscription Fees ($1/day accrued daily)
CREATE TABLE IF NOT EXISTS subscription_fees (
    id           uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id      uuid REFERENCES auth.users(id) ON DELETE CASCADE,
    amount       numeric(10,6) DEFAULT 1.00,
    fee_date     date DEFAULT current_date,
    collected    boolean DEFAULT false,
    collected_at timestamptz,
    period       text,
    created_at   timestamptz DEFAULT now(),
    UNIQUE(user_id, fee_date)
);

-- 3. Fee Collection Log
CREATE TABLE IF NOT EXISTS fee_collections (
    id               uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id          uuid REFERENCES auth.users(id) ON DELETE CASCADE,
    trigger          text,
    platform_fees    numeric(18,8) DEFAULT 0,
    profit_share     numeric(18,8) DEFAULT 0,
    subscription     numeric(18,8) DEFAULT 0,
    withdrawal_fee   numeric(18,8) DEFAULT 0,
    total_collected  numeric(18,8) DEFAULT 0,
    trade_count      int DEFAULT 0,
    collected_at     timestamptz DEFAULT now()
);

-- 4. Real-time aggregation VIEW
CREATE OR REPLACE VIEW v_user_fees AS
SELECT
    u.id AS user_id,
    COALESCE(tf.platform_fees, 0)  AS total_platform_fees,
    COALESCE(tf.profit_share,  0)  AS total_profit_share,
    COALESCE(sf.subscription,  0)  AS total_subscription,
    COALESCE(tf.platform_fees, 0) + COALESCE(tf.profit_share, 0)
        + COALESCE(sf.subscription, 0)    AS grand_total,
    COALESCE(tf.trade_count,   0)  AS uncollected_trades,
    COALESCE(sf.sub_days,      0)  AS uncollected_sub_days,
    COALESCE(DATE_PART('day', now() - tf.oldest_fee), 0) AS period_days
FROM auth.users u
LEFT JOIN (
    SELECT user_id,
           SUM(platform_fee)  AS platform_fees,
           SUM(profit_share)  AS profit_share,
           COUNT(*)           AS trade_count,
           MIN(created_at)    AS oldest_fee
    FROM trade_fees WHERE collected = false GROUP BY user_id
) tf ON tf.user_id = u.id
LEFT JOIN (
    SELECT user_id, SUM(amount) AS subscription, COUNT(*) AS sub_days
    FROM subscription_fees WHERE collected = false GROUP BY user_id
) sf ON sf.user_id = u.id;

-- 5. Atomic collection RPC
CREATE OR REPLACE FUNCTION collect_user_fees_v6(
    p_user_id uuid, p_platform_fees numeric, p_profit_share numeric,
    p_subscription numeric, p_withdrawal_fee numeric,
    p_total_amount numeric, p_wallet_id uuid
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_balance numeric; v_new_bal numeric; v_count int;
BEGIN
    SELECT balance INTO v_balance FROM wallets WHERE id = p_wallet_id FOR UPDATE;
    IF v_balance < p_total_amount THEN
        RETURN jsonb_build_object('success',false,'reason','INSUFFICIENT_BALANCE');
    END IF;
    v_new_bal := v_balance - p_total_amount;
    UPDATE wallets SET balance = v_new_bal WHERE id = p_wallet_id;
    UPDATE trade_fees SET collected=true, collected_at=now()
    WHERE user_id=p_user_id AND collected=false;
    GET DIAGNOSTICS v_count = ROW_COUNT;
    UPDATE subscription_fees SET collected=true, collected_at=now()
    WHERE user_id=p_user_id AND collected=false;
    INSERT INTO fee_collections(user_id,trigger,platform_fees,profit_share,subscription,withdrawal_fee,total_collected,trade_count)
    VALUES(p_user_id,'system',p_platform_fees,p_profit_share,p_subscription,p_withdrawal_fee,p_total_amount,v_count);
    INSERT INTO transactions(user_id,wallet_id,txn_type,amount,balance_after,description)
    VALUES(p_user_id,p_wallet_id,'fee_collection',-p_total_amount,v_new_bal,
      'Fees: platform $'||p_platform_fees||' profit_share $'||p_profit_share||' sub $'||p_subscription||' wd_fee $'||p_withdrawal_fee);
    RETURN jsonb_build_object('success',true,'collected',p_total_amount,'new_balance',v_new_bal,'trades_cleared',v_count);
END; $$;

-- 6. Auto-accrue trigger on trade close
CREATE OR REPLACE FUNCTION auto_accrue_trade_fee()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE vp numeric; vr numeric;
BEGIN
    IF NEW.status='closed' AND OLD.status='open' AND COALESCE(NEW.mode,'demo')='live' THEN
        vp := COALESCE(NEW.notional_value,0)*0.0005;
        vr := CASE WHEN COALESCE(NEW.net_pnl,0)>0 THEN NEW.net_pnl*0.20 ELSE 0 END;
        INSERT INTO trade_fees(user_id,trade_id,symbol,side,notional,gross_pnl,net_pnl,
                               platform_fee,profit_share,total_fee,collected,fee_period)
        VALUES(NEW.user_id,NEW.id,NEW.symbol,NEW.side,COALESCE(NEW.notional_value,0),
               COALESCE(NEW.gross_pnl,0),COALESCE(NEW.net_pnl,0),vp,vr,vp+vr,false,
               TO_CHAR(now(),'YYYY-MM'))
        ON CONFLICT DO NOTHING;
    END IF;
    RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS trg_auto_accrue_fee ON trades;
CREATE TRIGGER trg_auto_accrue_fee
    AFTER UPDATE OF status ON trades
    FOR EACH ROW EXECUTE FUNCTION auto_accrue_trade_fee();

-- 7. RLS
ALTER TABLE trade_fees        ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscription_fees ENABLE ROW LEVEL SECURITY;
ALTER TABLE fee_collections    ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own_trade_fees" ON trade_fees        FOR ALL USING (auth.uid()=user_id);
CREATE POLICY "own_sub_fees"   ON subscription_fees FOR ALL USING (auth.uid()=user_id);
CREATE POLICY "own_fee_coll"   ON fee_collections   FOR SELECT USING (auth.uid()=user_id);

-- 8. Performance Indexes
CREATE INDEX IF NOT EXISTS idx_tf_user_uncollected  ON trade_fees(user_id) WHERE collected=false;
CREATE INDEX IF NOT EXISTS idx_sf_user_uncollected  ON subscription_fees(user_id) WHERE collected=false;
CREATE INDEX IF NOT EXISTS idx_tf_period            ON trade_fees(fee_period,user_id);
CREATE INDEX IF NOT EXISTS idx_fc_user              ON fee_collections(user_id,collected_at DESC);
