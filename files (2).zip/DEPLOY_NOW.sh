#!/bin/bash
# ════════════════════════════════════════════════════════════════
# ESELITE AI v1.0 — ONE-COMMAND FULL DEPLOYMENT
# Run: chmod +x DEPLOY_NOW.sh && ./DEPLOY_NOW.sh
# ════════════════════════════════════════════════════════════════

echo "🚀 ESELITE AI DEPLOYING..."

# ── STEP 1: GitHub ───────────────────────────────────────────────
cd eselite
git remote add origin https://github.com/YOUR_USERNAME/eselite-ai.git 2>/dev/null || true
git branch -m main 2>/dev/null || true
git push -u origin main --force
echo "✅ GitHub: pushed"

# ── STEP 2: Vercel Frontend ──────────────────────────────────────
cd frontend
npx vercel --prod --yes 2>&1 | grep -E "Production|https"
echo "✅ Vercel: deployed"
cd ..

# ── STEP 3: Cloudflare Workers ───────────────────────────────────
# KV Namespaces already created via MCP:
#   CACHE:        968828953c7146f3bf5bf8e64bb246b2
#   SIGNALS:      864b1b97e204447f8312de1d66575fd2
#   RATE_LIMITER: 4ac2cc1651264bc5b5ac5fcba68b9d87
npx wrangler deploy workers/market-cache/index.ts --name eselite-market-cache 2>&1 | tail -3
echo "✅ Cloudflare Worker: deployed"

# ── STEP 4: Fly.io Bot Engine (24/7) ─────────────────────────────
fly auth login
fly launch --name eselite-api --dockerfile backend/Dockerfile --yes 2>/dev/null || fly deploy
fly secrets set \
  SUPABASE_URL="https://hclhdnhxddcjeyyuueac.supabase.co" \
  SUPABASE_SERVICE_KEY="GET_FROM_SUPABASE_DASHBOARD_SETTINGS_API" \
  BOT_ENGINE_SECRET="$(openssl rand -hex 32)"
fly deploy
echo "✅ Fly.io: deployed (24/7)"

# ── STEP 5: Summary ──────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║          ESELITE AI v1.0 ULTRA — LIVE!                   ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║  🌐 Dashboard:  https://eselite-ai.vercel.app            ║"
echo "║  🤖 API:        https://eselite-api.fly.dev              ║"
echo "║  ⚡ Worker:     https://eselite-market-cache.workers.dev ║"
echo "║  🗄️  Database:   hclhdnhxddcjeyyuueac.supabase.co        ║"
echo "║  📞 Support:    +255653712466                             ║"
echo "║  ✉️  Email:      admin@eselite.ai                         ║"
echo "╚══════════════════════════════════════════════════════════╝"
