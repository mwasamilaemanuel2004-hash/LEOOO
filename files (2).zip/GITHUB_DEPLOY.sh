#!/bin/bash
# ESELITE AI — GitHub + Deploy Script
# Run once to push to GitHub and deploy

# ── Colors ─────────────────────────────────────────────────────
G="\033[0;32m"; B="\033[0;34m"; Y="\033[1;33m"; R="\033[0;31m"; NC="\033[0m"
echo -e "${B}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${B}║          ESELITE AI v1.0 — GITHUB + DEPLOY              ║${NC}"
echo -e "${B}╚══════════════════════════════════════════════════════════╝${NC}"

# ── Step 1: GitHub ──────────────────────────────────────────────
echo -e "\n${Y}[1/3] Pushing to GitHub...${NC}"

# Create repo via GitHub CLI (if available)
if command -v gh &> /dev/null; then
  gh repo create eselite-ai --public --description "ESELITE AI - Institutional AI Trading Bot" --source=. --push
  echo -e "${G}✅ GitHub: https://github.com/$(gh api user -q .login)/eselite-ai${NC}"
else
  echo "Manual: Create repo at github.com/new → name: eselite-ai"
  echo "Then run:"
  echo "  git remote add origin https://github.com/YOUR_USERNAME/eselite-ai.git"
  echo "  git push -u origin main"
fi

# ── Step 2: Netlify Deploy (custom domain, no .vercel.app) ─────
echo -e "\n${Y}[2/3] Deploying to Netlify...${NC}"
if command -v npx &> /dev/null; then
  cd frontend
  npx netlify-cli deploy --prod --dir=dist --site=eselite-ai 2>/dev/null || \
  npx netlify-cli deploy --prod --dir=dist
  echo -e "${G}✅ Netlify: Live URL shown above${NC}"
  cd ..
fi

# ── Step 3: Summary ─────────────────────────────────────────────
echo -e "\n${G}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${G}║                    ESELITE AI — LIVE!                       ║${NC}"
echo -e "${G}╠══════════════════════════════════════════════════════════════╣${NC}"
echo -e "${G}║  🌐 App:        https://eselite-ai.netlify.app               ║${NC}"
echo -e "${G}║  🗄️  Database:   hclhdnhxddcjeyyuueac.supabase.co             ║${NC}"
echo -e "${G}║  ☁️  Cloudflare: Account 3d1526173b702c6455a82d4ad4a3b51b    ║${NC}"
echo -e "${G}║  📞 Support:    +255653712466                                 ║${NC}"
echo -e "${G}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${Y}DOMAINS AVAILABLE (buy any of these on GoDaddy):${NC}"
echo "  ⭐ eselite.ai      — BEST (AI brand)"
echo "  ⭐ eselite.io      — Good tech brand"
echo "  ✅ eseliteai.com   — Clear branding"
echo "  ✅ eselitetrading.com"
echo ""
echo -e "${Y}After buying domain → add to Netlify:${NC}"
echo "  Netlify Dashboard → Site → Domain Management → Add custom domain"
echo ""
echo -e "${B}Cloudflare Nameserver Setup:${NC}"
echo "  1. dash.cloudflare.com → Add site → enter your domain"
echo "  2. Copy 2 nameservers (e.g. ada.ns.cloudflare.com)"
echo "  3. GoDaddy → My Domains → DNS → Change Nameservers → paste both"
echo "  4. Wait 5-30 minutes → Cloudflare shows ✅ Active"
